extern void StrToUpper(char []);
