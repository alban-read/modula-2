/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xosIpts_H_
#define xosIpts_H_
#include "X2C.h"

extern void X2C_EnableIpts(void);

extern void X2C_DisableIpts(void);

extern void X2C_SaveIptHandler(unsigned long);

extern void X2C_RestoreIptHandler(unsigned long);

extern char X2C_SetIptHandler(unsigned long);


#endif /* xosIpts_H_ */
