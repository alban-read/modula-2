/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#ifndef xrcArythmetics_H_
#define xrcArythmetics_H_
#include "X2C.h"

extern long X2C_REM_F(long, long);

extern long X2C_QUO_F(long, long);

extern long X2C_MOD_F(long, long);

extern long X2C_DIV_F(long, long);

extern float X2C_DIVR_F(float, float);

extern double X2C_DIVL_F(double, double);

extern signed char X2C_ABS_INT8(signed char);

extern short X2C_ABS_INT16(short);

extern long X2C_ABS_INT32(long);


#endif /* xrcArythmetics_H_ */
