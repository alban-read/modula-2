/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosIpts.h"
#define xosIpts_C_

#line 6 "xosIpts.mod"

#line 5
extern void X2C_EnableIpts(void)
{
   #line 6
   X2C_PROC_INP();
   #line 7
   X2C_PROC_OUT();
} /* end X2C_EnableIpts() */

#line 10

#line 9
extern void X2C_DisableIpts(void)
{
   #line 10
   X2C_PROC_INP();
   #line 11
   X2C_PROC_OUT();
} /* end X2C_DisableIpts() */

#line 14

#line 13
extern void X2C_SaveIptHandler(unsigned long no)
{
   #line 14
   X2C_PROC_INP();
   #line 15
   X2C_PROC_OUT();
} /* end X2C_SaveIptHandler() */

#line 18

#line 17
extern void X2C_RestoreIptHandler(unsigned long no)
{
   #line 18
   X2C_PROC_INP();
   #line 19
   X2C_PROC_OUT();
} /* end X2C_RestoreIptHandler() */

#line 22

#line 21
extern char X2C_SetIptHandler(unsigned long no)
{
   char X2C_SetIptHandler_ret;
   #line 22
   X2C_PROC_INP();
   #line 23
   #line 23
   X2C_SetIptHandler_ret = 0;
   #line 24
   X2C_PROC_OUT();
   return X2C_SetIptHandler_ret;
} /* end X2C_SetIptHandler() */

#line 26
