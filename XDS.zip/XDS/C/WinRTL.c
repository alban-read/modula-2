/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include <WinRTL.h>
#define WinRTL_C_

#line 1117 "WinRTL.mod"
