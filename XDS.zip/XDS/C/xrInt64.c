/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrInt64.h"
#define xrInt64_C_

#line 10 "xrInt64.def"


#line 16 "xrInt64.mod"
#line 17
typedef unsigned long Arr[4];

#line 19
#define M 0x10000 

#line 19
#line 20
#define S 0x7FFF 

#line 20
#line 23

#line 22
extern void X2C_INTTO64(struct X2C_int64 * res, long val)
{
   #line 23
   X2C_PROC_INP();
   #line 24
   if (val<0l) {
      #line 25
      res->high = X2C_max_longcard;
   }
   else {
      #line 27
      res->high = 0ul;
   }
   #line 29
   res->low = (unsigned long)val;
   #line 30
   X2C_PROC_OUT();
} /* end X2C_INTTO64() */

#line 33

#line 32
extern void X2C_CARDTO64(struct X2C_int64 * res, unsigned long val)
{
   #line 33
   X2C_PROC_INP();
   #line 34
   res->high = 0ul;
   #line 34
   res->low = val;
   #line 35
   X2C_PROC_OUT();
} /* end X2C_CARDTO64() */

#line 38

#line 37
extern char X2C_IsNeg64(struct X2C_int64 a)
{
   char X2C_IsNeg64_ret;
   #line 38
   X2C_PROC_INP();
   #line 39
   #line 39
   X2C_IsNeg64_ret = a.high>2147483647ul;
   #line 40
   X2C_PROC_OUT();
   return X2C_IsNeg64_ret;
} /* end X2C_IsNeg64() */

#line 43

#line 42
static void toArr(Arr a, struct X2C_int64 val)
{
   #line 43
   X2C_PROC_INP();
   #line 44
   a[0u] = val.low&65535ul;
   #line 45
   a[1u] = val.low/65536ul;
   #line 46
   a[2u] = val.high&65535ul;
   #line 47
   a[3u] = val.high/65536ul;
   #line 48
   X2C_PROC_OUT();
} /* end toArr() */

#line 51

#line 50
static void to64(struct X2C_int64 * x, Arr a)
{
   #line 51
   X2C_PROC_INP();
   #line 52
   x->low = a[1u]*65536ul+a[0u];
   #line 53
   x->high = a[3u]*65536ul+a[2u];
   #line 54
   X2C_PROC_OUT();
} /* end to64() */

#line 58

#line 56
static void neg(Arr a)
{
   #line 57
   unsigned long i;
   #line 57
   unsigned long r;
   #line 58
   X2C_PROC_INP();
   #line 59
   for (i = 0ul; i<=3ul; i++) {
      #line 59
      a[i] = (65536ul-a[i])-1ul;
   } /* end for */
   #line 60
   r = 1ul;
   #line 60
   i = 0ul;
   #line 61
   while (i<4ul && r) {
      #line 62
      r += a[i];
      #line 62
      a[i] = r&65535ul;
      #line 62
      r = r/65536ul;
      #line 63
      ++i;
   }
   #line 65
   X2C_PROC_OUT();
} /* end neg() */

#line 69

#line 67
static char add(Arr res, Arr a, Arr b)
{
   #line 68
   unsigned long i;
   #line 68
   unsigned long r;
   char add_ret;
   #line 69
   X2C_PROC_INP();
   #line 70
   #line 70
   r = 0ul;
   #line 71
   for (i = 0ul; i<=3ul; i++) {
      #line 72
      r = a[i]+b[i]+r;
      #line 72
      res[i] = r&65535ul;
      #line 72
      r = r/65536ul;
   } /* end for */
   #line 74
   add_ret = r!=0ul;
   #line 75
   X2C_PROC_OUT();
   return add_ret;
} /* end add() */

#line 79

#line 77
static void mul(Arr res, unsigned long a, unsigned long b)
{
   #line 78
   unsigned long r;
   #line 78
   unsigned long b1;
   #line 78
   unsigned long b0;
   #line 78
   unsigned long a1;
   #line 78
   unsigned long a0;
   #line 79
   X2C_PROC_INP();
   #line 80
   a0 = a&65535ul;
   #line 80
   a1 = a/65536ul;
   #line 81
   b0 = b&65535ul;
   #line 81
   b1 = b/65536ul;
   #line 82
   r = a0*b0;
   #line 83
   res[0u] = r&65535ul;
   #line 83
   r = r/65536ul;
   #line 84
   r += a0*b1+b0*a1;
   #line 85
   res[1u] = r&65535ul;
   #line 85
   r = r/65536ul;
   #line 86
   r += a1*b1;
   #line 87
   res[2u] = r&65535ul;
   #line 88
   res[3u] = r/65536ul;
   #line 89
   X2C_PROC_OUT();
} /* end mul() */

#line 93

#line 91
extern char X2C_UnMinus64(struct X2C_int64 * res, struct X2C_int64 x)
{
   #line 92
   Arr a;
   #line 92
   char s;
   char X2C_UnMinus64_ret;
   #line 93
   X2C_PROC_INP();
   #line 94
   #line 94
   (X2C_SET_HINFO() toArr(a, x));
   #line 95
   s = a[3u]>32767ul;
   #line 96
   (X2C_SET_HINFO() neg(a));
   #line 97
   if (s==a[3u]>32767ul && (x.high || x.low)) {
      #line 97
      X2C_UnMinus64_ret = 1;
      goto label;
   }
   #line 98
   (X2C_SET_HINFO() to64(res, a));
   #line 99
   X2C_UnMinus64_ret = 0;
   label:;
   #line 100
   X2C_PROC_OUT();
   return X2C_UnMinus64_ret;
} /* end X2C_UnMinus64() */

#line 104

#line 102
extern char X2C_ADD64(struct X2C_int64 * res, struct X2C_int64 A, struct X2C_int64 B)
{
   #line 103
   Arr r;
   #line 103
   Arr b;
   #line 103
   Arr a;
   #line 103
   char cr;
   #line 103
   char sb;
   #line 103
   char sa;
   char X2C_ADD64_ret;
   #line 104
   X2C_PROC_INP();
   #line 105
   #line 105
   (X2C_SET_HINFO() toArr(a, A));
   #line 105
   (X2C_SET_HINFO() toArr(b, B));
   #line 106
   sa = a[3u]>32767ul;
   #line 106
   sb = b[3u]>32767ul;
   #line 107
   cr = (X2C_SET_HINFO() add(r, a, b));
   #line 108
   (X2C_SET_HINFO() to64(res, r));
   #line 109
   X2C_ADD64_ret = sa==sb && r[3u]>32767ul!=sa;
   #line 110
   X2C_PROC_OUT();
   return X2C_ADD64_ret;
} /* end X2C_ADD64() */

#line 113

#line 112
extern char X2C_64TOINT(long * res, struct X2C_int64 x)
{
   char X2C_64TOINT_ret;
   #line 113
   X2C_PROC_INP();
   #line 114
   #line 114
   *res = (long)x.low;
   #line 115
   X2C_64TOINT_ret = (x.high || x.low>=0x080000000ul) && (x.high!=X2C_max_longcard || x.low<0x080000000ul);
   #line 118
   X2C_PROC_OUT();
   return X2C_64TOINT_ret;
} /* end X2C_64TOINT() */

#line 121

#line 120
extern char X2C_64TOCARD(unsigned long * res, struct X2C_int64 x)
{
   char X2C_64TOCARD_ret;
   #line 121
   X2C_PROC_INP();
   #line 122
   #line 122
   *res = x.low;
   #line 122
   X2C_64TOCARD_ret = x.high!=0ul;
   #line 123
   X2C_PROC_OUT();
   return X2C_64TOCARD_ret;
} /* end X2C_64TOCARD() */

#line 127

#line 125
extern void X2C_MUL64(struct X2C_int64 * res, long a, unsigned long b)
{
   #line 126
   unsigned long x;
   #line 126
   char sig;
   #line 126
   Arr ra;
   #line 127
   X2C_PROC_INP();
   #line 128
   sig = a<0l;
   #line 129
   if (sig) {
      #line 130
      if (a==X2C_min_longint) {
         #line 130
         x = 0x080000000ul;
      }
      else {
         #line 131
         x = (unsigned long) -a;
      }
   }
   else {
      #line 134
      x = (unsigned long)a;
   }
   #line 136
   (X2C_SET_HINFO() mul(ra, x, b));
   #line 137
   if (sig) {
      #line 137
      (X2C_SET_HINFO() neg(ra));
   }
   #line 138
   (X2C_SET_HINFO() to64(res, ra));
   #line 139
   X2C_PROC_OUT();
} /* end X2C_MUL64() */

#line 143

#line 141
extern int X2C_CMP64(struct X2C_int64 a, struct X2C_int64 b)
{
   #line 142
   char bn;
   #line 142
   char an;
   int X2C_CMP64_ret;
   #line 143
   X2C_PROC_INP();
   #line 144
   #line 144
   an = a.high>2147483647ul;
   #line 145
   bn = b.high>2147483647ul;
   #line 146
   if (an && !bn) {
      #line 147
      X2C_CMP64_ret = -1;
      goto label;
   }
   #line 148
   if (bn && !an) {
      #line 149
      X2C_CMP64_ret = 1;
      goto label;
   }
   #line 150
   if (a.high>b.high) {
      #line 150
      X2C_CMP64_ret = 1;
      goto label;
   }
   #line 151
   if (a.high<b.high) {
      #line 151
      X2C_CMP64_ret = -1;
      goto label;
   }
   #line 152
   if (a.low>b.low) {
      #line 152
      X2C_CMP64_ret = 1;
      goto label;
   }
   #line 153
   if (a.low<b.low) {
      #line 153
      X2C_CMP64_ret = -1;
      goto label;
   }
   #line 155
   X2C_CMP64_ret = 0;
   label:;
   #line 156
   X2C_PROC_OUT();
   return X2C_CMP64_ret;
} /* end X2C_CMP64() */

#line 158
