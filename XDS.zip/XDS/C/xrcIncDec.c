/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcIncDec.h"
#define xrcIncDec_C_
#include "X2C.h"
#include "M2EXCEPTION.h"

#line 18 "xrcIncDec.mod"

#line 16
extern char X2C_INCC(char * x, unsigned char y, char min0, char max0)
{
   #line 17
   short i;
   #line 19
   #line 19
   i = (short)((long)(unsigned char)*x+(long)y);
   #line 20
   if ((long)i<(long)(unsigned char)min0 || (long)i>(long)(unsigned char)max0) {
      #line 21
      X2C_TRAP(1l);
   }
   #line 23
   *x = (char)i;
   #line 24
   return *x;
} /* end X2C_INCC() */

#line 29

#line 27
extern signed char X2C_INCS(signed char * x, signed char y, signed char min0, signed char max0)
{
   #line 28
   short i;
   #line 30
   #line 30
   i = (short)((long)*x+(long)y);
   #line 31
   if ((long)i<(long)min0 || (long)i>(long)max0) {
      #line 31
      X2C_TRAP(1l);
   }
   #line 32
   *x = (signed char)i;
   #line 33
   return *x;
} /* end X2C_INCS() */

#line 38

#line 36
extern short X2C_INCI(short * x, short y, short min0, short max0)
{
   #line 37
   long i;
   #line 39
   #line 39
   i = (long)*x+(long)y;
   #line 40
   if (i<(long)min0 || i>(long)max0) {
      #line 40
      X2C_TRAP(1l);
   }
   #line 41
   *x = (short)i;
   #line 42
   return *x;
} /* end X2C_INCI() */

#line 47

#line 45
extern long X2C_INC(long * x, long y, long min0, long max0)
{
   #line 46
   long i;
   #line 48
   #line 48
   if (y>0l) {
      #line 49
      if (X2C_max_longint-y<*x) {
         #line 49
         X2C_TRAP(1l);
      }
   }
   else if (X2C_min_longint-y>*x) {
      #line 51
      X2C_TRAP(1l);
   }
   #line 53
   i = *x+y;
   #line 54
   if (i<min0 || i>max0) {
      #line 54
      X2C_TRAP(1l);
   }
   #line 55
   *x = i;
   #line 56
   return *x;
} /* end X2C_INC() */

#line 61

#line 59
extern unsigned char X2C_INCUS(unsigned char * x, unsigned char y, unsigned char min0, unsigned char max0)
{
   #line 60
   unsigned short i;
   #line 62
   #line 62
   i = (unsigned short)((unsigned long)*x+(unsigned long)y);
   #line 63
   if ((unsigned long)i<(unsigned long)min0 || (unsigned long)i>(unsigned long)max0) {
      #line 63
      X2C_TRAP(1l);
   }
   #line 64
   *x = (unsigned char)i;
   #line 65
   return *x;
} /* end X2C_INCUS() */

#line 70

#line 68
extern unsigned short X2C_INCUI(unsigned short * x, unsigned short y, unsigned short min0, unsigned short max0)
{
   #line 69
   unsigned long i;
   #line 71
   #line 71
   i = (unsigned long)*x+(unsigned long)y;
   #line 72
   if (i<(unsigned long)min0 || i>(unsigned long)max0) {
      #line 72
      X2C_TRAP(1l);
   }
   #line 73
   *x = (unsigned short)i;
   #line 74
   return *x;
} /* end X2C_INCUI() */

#line 79

#line 77
extern unsigned long X2C_INCU(unsigned long * x, unsigned long y, unsigned long min0, unsigned long max0)
{
   #line 78
   unsigned long i;
   #line 80
   #line 80
   if (X2C_max_longcard-y<*x) {
      #line 80
      X2C_TRAP(1l);
   }
   #line 81
   i = *x+y;
   #line 82
   if (i<min0 || i>max0) {
      #line 82
      X2C_TRAP(1l);
   }
   #line 83
   *x = i;
   #line 84
   return *x;
} /* end X2C_INCU() */

#line 89

#line 87
extern char X2C_DECC(char * x, unsigned char y, char min0, char max0)
{
   #line 88
   short i;
   #line 90
   #line 90
   i = (short)((long)(unsigned char)*x-(long)y);
   #line 91
   if ((long)i<(long)(unsigned char)min0 || (long)i>(long)(unsigned char)max0) {
      #line 92
      X2C_TRAP(1l);
   }
   #line 94
   *x = (char)i;
   #line 95
   return *x;
} /* end X2C_DECC() */

#line 100

#line 98
extern signed char X2C_DECS(signed char * x, signed char y, signed char min0, signed char max0)
{
   #line 99
   short i;
   #line 101
   #line 101
   i = (short)((long)*x-(long)y);
   #line 102
   if ((long)i<(long)min0 || (long)i>(long)max0) {
      #line 102
      X2C_TRAP(1l);
   }
   #line 103
   *x = (signed char)i;
   #line 104
   return *x;
} /* end X2C_DECS() */

#line 109

#line 107
extern short X2C_DECI(short * x, short y, short min0, short max0)
{
   #line 108
   long i;
   #line 110
   #line 110
   i = (long)*x-(long)y;
   #line 111
   if (i<(long)min0 || i>(long)max0) {
      #line 111
      X2C_TRAP(1l);
   }
   #line 112
   *x = (short)i;
   #line 113
   return *x;
} /* end X2C_DECI() */

#line 117

#line 116
extern long X2C_DEC(long * x, long y, long min0, long max0)
{
   #line 118
   #line 118
   if (y<0l) {
      #line 119
      if (X2C_max_longint+y<*x) {
         #line 119
         X2C_TRAP(1l);
      }
   }
   else if (X2C_min_longint+y>*x) {
      #line 121
      X2C_TRAP(1l);
   }
   #line 123
   *x -= y;
   #line 124
   if (*x<min0 || *x>max0) {
      #line 124
      X2C_TRAP(1l);
   }
   #line 125
   return *x;
} /* end X2C_DEC() */

#line 129

#line 128
extern unsigned char X2C_DECUS(unsigned char * x, unsigned char y, unsigned char min0, unsigned char max0)
{
   #line 130
   #line 130
   if ((unsigned long)y>(unsigned long)*x) {
      #line 130
      X2C_TRAP(1l);
   }
   #line 131
   *x = (unsigned char)((unsigned long)*x-(unsigned long)y);
   #line 132
   if ((unsigned long)*x<(unsigned long)min0 || (unsigned long)*x>(unsigned long)max0) {
      #line 132
      X2C_TRAP(1l);
   }
   #line 133
   return *x;
} /* end X2C_DECUS() */

#line 137

#line 136
extern unsigned short X2C_DECUI(unsigned short * x, unsigned short y, unsigned short min0, unsigned short max0)
{
   #line 138
   #line 138
   if ((unsigned long)y>(unsigned long)*x) {
      #line 138
      X2C_TRAP(1l);
   }
   #line 139
   *x = (unsigned short)((unsigned long)*x-(unsigned long)y);
   #line 140
   if ((unsigned long)*x<(unsigned long)min0 || (unsigned long)*x>(unsigned long)max0) {
      #line 140
      X2C_TRAP(1l);
   }
   #line 141
   return *x;
} /* end X2C_DECUI() */

#line 146

#line 144
extern unsigned long X2C_DECU(unsigned long * x, unsigned long y, unsigned long min0, unsigned long max0)
{
   #line 145
   unsigned long i;
   #line 147
   #line 147
   if (y>*x) {
      #line 147
      X2C_TRAP(1l);
   }
   #line 148
   i = *x-y;
   #line 149
   if (i<min0 || i>max0) {
      #line 149
      X2C_TRAP(1l);
   }
   #line 150
   *x = i;
   #line 151
   return *x;
} /* end X2C_DECU() */

#line 154
