/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosBalls.h"
#define xosBalls_C_
#include "xrtsOS.h"
#include "xrnMman.h"

#line 15 "xosBalls.mod"
#define hardPageSize 4096

#line 15
#line 18
static unsigned long bSize;

#line 19
static X2C_ADDRESS heapBase;

#line 20
static unsigned long numBlocks;

#line 24

#line 23
extern X2C_ADDRESS X2C_initBalls(unsigned long nBlocks, unsigned long blockSize)
{
   X2C_ADDRESS X2C_initBalls_ret;
   #line 24
   X2C_PROC_INP();
   #line 25
   #line 25
   if (blockSize&4095ul) X2C_ASSERT(301ul);
   #line 26
   bSize = blockSize;
   #line 28
   heapBase = (X2C_SET_HINFO() mmap(0, nBlocks*bSize, 0ul, 34ul, -1l, 0ul));
   #line 34
   if (heapBase==(X2C_ADDRESS)-1u) X2C_ASSERT(302ul);
   #line 36
   X2C_initBalls_ret = heapBase;
   #line 37
   X2C_PROC_OUT();
   return X2C_initBalls_ret;
} /* end X2C_initBalls() */

#line 41

#line 40
extern X2C_ADDRESS X2C_allocBlock(X2C_ADDRESS adr)
{
   X2C_ADDRESS X2C_allocBlock_ret;
   #line 41
   X2C_PROC_INP();
   #line 42
   #line 42
   if ((X2C_SET_HINFO() mprotect(adr, bSize, 3ul))) {
      #line 46
      X2C_ASSERT(303ul);
   }
   #line 49
   X2C_allocBlock_ret = adr;
   #line 50
   X2C_PROC_OUT();
   return X2C_allocBlock_ret;
} /* end X2C_allocBlock() */

#line 54

#line 53
extern void X2C_freeBlock(X2C_ADDRESS adr)
{
   #line 54
   X2C_PROC_INP();
   #line 55
   if (*X2C_CAST(&adr,X2C_ADDRESS,unsigned long,unsigned long *)&4095ul) X2C_ASSERT(304ul);
   #line 56
   if ((X2C_SET_HINFO() mprotect(adr, bSize, 0ul))) {
      #line 59
      X2C_ASSERT(305ul);
   }
   #line 62
   X2C_PROC_OUT();
} /* end X2C_freeBlock() */

#line 66

#line 65
extern void X2C_freeAll(void)
{
   #line 66
   X2C_PROC_INP();
   #line 67
   if ((X2C_SET_HINFO() munmap(heapBase, numBlocks*bSize))) {
      #line 68
      X2C_ASSERT(306ul);
   }
   #line 71
   X2C_PROC_OUT();
} /* end X2C_freeAll() */

#line 75
