/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrExponents.h"
#define xrExponents_C_
#include "xmRTS.h"
#include "xPOSIX.h"

#line 20 "xrExponents.mod"

#line 19
static double c_abs(double re, double im)
{
   #line 21
   #line 21
   return sqrt(re*re+im*im);
} /* end c_abs() */

#line 25

#line 24
static double c_arg(double re, double im)
{
   #line 26
   #line 26
   if (re==0.0 && im==0.0) {
      #line 26
      return 0.0;
   }
   #line 27
   return atan2(im, re);
} /* end c_arg() */

#line 32

#line 30
extern double X2C_EXPRI(double base, long ex)
{
   #line 31
   double res;
   #line 33
   #line 33
   if (ex<0l || ex>8l) {
      #line 34
      return pow(base, (double)ex);
   }
   #line 36
   res = 1.0;
   #line 37
   while (ex>0l) {
      #line 37
      res = res*base;
      #line 37
      --ex;
   }
   #line 38
   return res;
} /* end X2C_EXPRI() */

#line 45
static X2C_COMPLEX _cnst = {1.0,0.0};
#line 43

#line 41
extern X2C_COMPLEX X2C_EXPCI(X2C_COMPLEX base, long ex)
{
   #line 42
   X2C_COMPLEX res;
   #line 44
   #line 44
   if (ex<0l || ex>8l) {
      #line 44
      return X2C_EXPCR(base, (double)ex);
   }
   #line 45
   res = _cnst;
   #line 46
   while (ex>0l) {
      #line 46
      res = CPLX_MUL(res, base);
      #line 46
      --ex;
   }
   #line 47
   return res;
} /* end X2C_EXPCI() */

#line 54
static X2C_LONGCOMPLEX _cnst1 = {1.0,0.0};
#line 52

#line 50
extern X2C_LONGCOMPLEX X2C_EXPLI(X2C_LONGCOMPLEX base, long ex)
{
   #line 51
   X2C_LONGCOMPLEX res;
   #line 53
   #line 53
   if (ex<0l || ex>8l) {
      #line 53
      return X2C_EXPLR(base, (double)ex);
   }
   #line 54
   res = _cnst1;
   #line 55
   while (ex>0l) {
      #line 55
      res = CPLX_LMUL(res, base);
      #line 55
      --ex;
   }
   #line 56
   return res;
} /* end X2C_EXPLI() */

#line 63
static X2C_COMPLEX _cnst0 = {0.0,0.0};
#line 61

#line 59
extern X2C_COMPLEX X2C_EXPCR(X2C_COMPLEX base, double ex)
{
   #line 60
   float x;
   #line 60
   double y;
   X2C_COMPLEX tmp;
   #line 62
   #line 62
   if ((base.re==0.0f && base.im==0.0f) && ex>0.0) {
      #line 63
      return _cnst0;
   }
   #line 65
   x = (float)pow(c_abs((double)base.re, (double)base.im), ex);
   #line 66
   y = ex*c_arg((double)base.re, (double)base.im);
   #line 67
   return (tmp.re = x*(float)cos(y),tmp.im = x*(float)sin(y),tmp);
} /* end X2C_EXPCR() */

#line 74
static X2C_LONGCOMPLEX _cnst2 = {0.0,0.0};
#line 72

#line 70
extern X2C_LONGCOMPLEX X2C_EXPLR(X2C_LONGCOMPLEX base, double ex)
{
   #line 71
   double y;
   #line 71
   double x;
   X2C_LONGCOMPLEX tmp;
   #line 73
   #line 73
   if ((base.re==0.0 && base.im==0.0) && ex>0.0) {
      #line 74
      return _cnst2;
   }
   #line 76
   x = pow(c_abs(base.re, base.im), ex);
   #line 77
   y = ex*c_arg(base.re, base.im);
   #line 78
   return (tmp.re = x*cos(y),tmp.im = x*sin(y),tmp);
} /* end X2C_EXPLR() */

#line 81
