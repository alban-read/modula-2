/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrThreads.h"
#define xrThreads_C_
#include "xmRTS.h"

#line 354 "xrThreads.mod"
static X2C_Coroutine current;

#line 357

#line 356
extern void X2C_SetCurrent(X2C_Coroutine c)
{
   #line 358
   current = c;
} /* end X2C_SetCurrent() */

#line 362

#line 361
extern X2C_Coroutine X2C_GetCurrent(void)
{
   #line 363
   #line 363
   return current;
} /* end X2C_GetCurrent() */

#line 367

#line 366
extern long X2C_InitThreads(void)
{
   #line 368
   #line 368
   current = 0;
   #line 369
   return 0l;
} /* end X2C_InitThreads() */

#line 374

#line 372
extern void X2C_PrepareToGC(void)
{
   #line 373
   X2C_Coroutine c;
   #line 375
   c = current;
   #line 376
   do {
      #line 377
      X2C_CopyJmpBuf(c);
      #line 378
      c = c->fwd;
   } while (c!=current);
} /* end X2C_PrepareToGC() */

#line 383

#line 382
extern void X2C_FreeAfterGC(void)
{
} /* end X2C_FreeAfterGC() */

#line 389
