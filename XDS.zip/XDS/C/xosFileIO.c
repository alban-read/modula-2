/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosFileIO.h"
#define xosFileIO_C_
#include "xrtsOS.h"
#include "xPOSIX.h"

#line 10 "xosFileIO.mod"
typedef FILE * File;

#line 14

#line 12
extern int X2C_FileOpenRead(X2C_OSFILE * f, char name[])
{
   #line 13
   File t;
   int X2C_FileOpenRead_ret;
   #line 14
   X2C_PROC_INP();
   #line 15
   #line 15
   t = (File)(X2C_SET_HINFO() fopen(name, "r"));
   #line 16
   if (t) {
      #line 16
      *f = (X2C_OSFILE)t;
      #line 16
      X2C_FileOpenRead_ret = 1;
   }
   else {
      #line 17
      X2C_FileOpenRead_ret = 0;
   }
   #line 19
   X2C_PROC_OUT();
   return X2C_FileOpenRead_ret;
} /* end X2C_FileOpenRead() */

#line 23

#line 21
extern int X2C_FileClose(X2C_OSFILE f)
{
   #line 22
   File cf;
   int X2C_FileClose_ret;
   #line 23
   X2C_PROC_INP();
   #line 24
   #line 24
   cf = (File)f;
   #line 25
   if ((X2C_SET_HINFO() fclose(X2C_CHKNIL(File,cf)))==0) {
      #line 25
      X2C_FileClose_ret = 1;
   }
   else {
      #line 26
      X2C_FileClose_ret = 0;
   }
   #line 28
   X2C_PROC_OUT();
   return X2C_FileClose_ret;
} /* end X2C_FileClose() */

#line 32

#line 30
extern int X2C_FileSeek(X2C_OSFILE f, X2C_WORD ofs, int org)
{
   #line 31
   File cf;
   int X2C_FileSeek_ret;
   #line 32
   X2C_PROC_INP();
   #line 33
   #line 33
   cf = (File)f;
   #line 34
   if ((X2C_SET_HINFO() fseek(X2C_CHKNIL(File,cf), *(long *)ofs, org))==0) {
      #line 34
      X2C_FileSeek_ret = 1;
   }
   else {
      #line 35
      X2C_FileSeek_ret = 0;
   }
   #line 37
   X2C_PROC_OUT();
   return X2C_FileSeek_ret;
} /* end X2C_FileSeek() */

#line 41

#line 39
extern int X2C_FileOpenWrite(X2C_OSFILE * f, char name[])
{
   #line 40
   File t;
   int X2C_FileOpenWrite_ret;
   #line 41
   X2C_PROC_INP();
   #line 42
   #line 42
   t = (File)(X2C_SET_HINFO() fopen(name, "rw"));
   #line 43
   if (t) {
      #line 43
      *f = (X2C_OSFILE)t;
      #line 43
      X2C_FileOpenWrite_ret = 1;
   }
   else {
      #line 44
      X2C_FileOpenWrite_ret = 0;
   }
   #line 46
   X2C_PROC_OUT();
   return X2C_FileOpenWrite_ret;
} /* end X2C_FileOpenWrite() */

#line 50

#line 48
extern int X2C_FileOpenRW(X2C_OSFILE * f, char name[])
{
   #line 49
   File t;
   int X2C_FileOpenRW_ret;
   #line 50
   X2C_PROC_INP();
   #line 51
   #line 51
   t = (File)(X2C_SET_HINFO() fopen(name, "r+"));
   #line 52
   if (t) {
      #line 52
      *f = (X2C_OSFILE)t;
      #line 52
      X2C_FileOpenRW_ret = 1;
   }
   else {
      #line 53
      X2C_FileOpenRW_ret = 0;
   }
   #line 55
   X2C_PROC_OUT();
   return X2C_FileOpenRW_ret;
} /* end X2C_FileOpenRW() */

#line 59

#line 57
extern int X2C_FileRead(X2C_OSFILE f, X2C_ADDRESS buf, unsigned long * len)
{
   #line 58
   File cf;
   int X2C_FileRead_ret;
   #line 59
   X2C_PROC_INP();
   #line 60
   #line 60
   cf = (File)f;
   #line 61
   if ((X2C_SET_HINFO() fread(buf, *len, 1u, X2C_CHKNIL(File,cf)))==*len) {
      #line 61
      X2C_FileRead_ret = 1;
   }
   else {
      #line 62
      X2C_FileRead_ret = 0;
   }
   #line 64
   X2C_PROC_OUT();
   return X2C_FileRead_ret;
} /* end X2C_FileRead() */

#line 68

#line 66
extern int X2C_FileWrite(X2C_OSFILE f, X2C_ADDRESS buf, unsigned long * len)
{
   #line 67
   File cf;
   int X2C_FileWrite_ret;
   #line 68
   X2C_PROC_INP();
   #line 69
   #line 69
   cf = (File)f;
   #line 70
   if ((X2C_SET_HINFO() fwrite(buf, *len, 1u, X2C_CHKNIL(File,cf)))==*len) {
      #line 70
      X2C_FileWrite_ret = 1;
   }
   else {
      #line 71
      X2C_FileWrite_ret = 0;
   }
   #line 73
   X2C_PROC_OUT();
   return X2C_FileWrite_ret;
} /* end X2C_FileWrite() */

#line 76

#line 75
extern void X2C_StdOut(char s[], unsigned long len)
{
   #line 76
   X2C_PROC_INP();
   #line 77
   (X2C_SET_HINFO() fwrite((char *)s, 1u, len, X2C_CHKNIL(FILE *,stdout)));
   #line 78
   X2C_PROC_OUT();
} /* end X2C_StdOut() */

#line 81

#line 80
extern void X2C_StdOutFlush(void)
{
   #line 81
   X2C_PROC_INP();
   #line 82
   X2C_PROC_OUT();
} /* end X2C_StdOutFlush() */

#line 84
