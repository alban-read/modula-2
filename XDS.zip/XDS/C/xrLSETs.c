/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrLSETs.h"
#define xrLSETs_C_
#include "xmRTS.h"
#include "X2C.h"
#include "M2EXCEPTION.h"

#line 23 "xrLSETs.mod"

#line 21
extern LSET X2C_AND(LSET res, LSET a, LSET b, unsigned short length)
{
   #line 22
   LSET c;
   #line 24
   #line 24
   c = res;
   #line 25
   while (length) { length--; *c++ = *a++ & *b++; }
   #line 26
   return res;
} /* end X2C_AND() */

#line 31

#line 29
extern LSET X2C_OR(LSET res, LSET a, LSET b, unsigned short length)
{
   #line 30
   LSET c;
   #line 32
   #line 32
   c = res;
   #line 33
   while (length) { length--; *c++ = *a++ | *b++; }
   #line 34
   return res;
} /* end X2C_OR() */

#line 39

#line 37
extern LSET X2C_XOR(LSET res, LSET a, LSET b, unsigned short length)
{
   #line 38
   LSET c;
   #line 40
   #line 40
   c = res;
   #line 41
   while (length) { length--; *c++ = *a++ ^ *b++; }
   #line 42
   return res;
} /* end X2C_XOR() */

#line 47

#line 45
extern LSET X2C_BIC(LSET res, LSET a, LSET b, unsigned short length)
{
   #line 46
   LSET c;
   #line 48
   #line 48
   c = res;
   #line 49
   while (length) { length--; *c++ = *a++ & ~( *b++ ); }
   #line 50
   return res;
} /* end X2C_BIC() */

#line 55

#line 53
extern LSET X2C_COMPLEMENT(LSET res, LSET a, unsigned short length)
{
   #line 54
   LSET c;
   #line 56
   #line 56
   c = res;
   #line 57
   while (length) { length--; *c++ = ~( *a++ ); }
   #line 58
   return res;
} /* end X2C_COMPLEMENT() */

#line 63

#line 61
extern char X2C_SET_EQU(LSET a, LSET b, unsigned short bits)
{
   #line 62
   X2C_LSET_BASE mask;
   #line 64
   #line 64
   while (bits >= X2C_LSET_SIZE) {
   #line 65
     if ( *a++ != *b++ ) return 0;
   #line 66
     bits -= X2C_LSET_SIZE;
   #line 67
   }
   #line 68
   if (bits == 0) return 1;
   #line 69
   mask = (1<<bits) - 1;
   #line 70
   return ( *a & mask ) == ( *b & mask );
   #line 71
   return 0;
} /* end X2C_SET_EQU() */

#line 76

#line 74
extern char X2C_SET_LEQ(LSET a, LSET b, unsigned short bits)
{
   #line 75
   X2C_LSET_BASE mask;
   #line 77
   #line 77
   while (bits >= X2C_LSET_SIZE) {
   #line 78
     if (( *a++ & ~*b++ ) != 0) return 0;
   #line 79
     bits -= X2C_LSET_SIZE;
   #line 80
   }
   #line 81
   if (bits == 0) return 1;
   #line 82
   mask = (1 << bits) - 1;
   #line 83
   return ((( *a & mask ) & (~( *b & mask ))) == 0);
   #line 84
   return 0;
} /* end X2C_SET_LEQ() */

#line 88

#line 87
extern LSET X2C_INCL(LSET set, unsigned long i, unsigned short bits)
{
   #line 89
   #line 89
   if (i>=(unsigned long)bits) {
      #line 89
      X2C_TRAP(1l);
   }
   #line 90
   set[(int)i/X2C_LSET_SIZE] |= 1L << ((int)i%X2C_LSET_SIZE);
   #line 91
   return set;
} /* end X2C_INCL() */

#line 95

#line 94
extern LSET X2C_EXCL(LSET set, unsigned long i, unsigned short bits)
{
   #line 96
   #line 96
   if (i>=(unsigned long)bits) {
      #line 96
      X2C_TRAP(1l);
   }
   #line 97
   set[(int)i/X2C_LSET_SIZE] &= ~(1L << ((int)i%X2C_LSET_SIZE));
   #line 98
   return set;
} /* end X2C_EXCL() */

#line 102

#line 101
extern LSET X2C_LONGSET(LSET set, unsigned long a, unsigned long b, unsigned short bits)
{
   #line 103
   #line 103
   if ((a>b || a>=(unsigned long)bits) || b>=(unsigned long)bits) {
      #line 103
      X2C_TRAP(1l);
   }
   #line 104
   while (a <= b) { set[(int)a/X2C_LSET_SIZE] |= 1L << ((int)a%X2C_LSET_SIZE); ++a; }
   #line 105
   return set;
} /* end X2C_LONGSET() */

#line 109

#line 108
extern char X2C_INL(unsigned long i, unsigned short bits, LSET set)
{
   #line 110
   #line 110
   if (i<(unsigned long)bits) {
      #line 111
      return (set[(int)i/X2C_LSET_SIZE] & (1L << ((int)i%X2C_LSET_SIZE))) != 0;
   }
   #line 113
   return 0;
} /* end X2C_INL() */

#line 118

#line 116
extern LSET X2C_ROTL(LSET res, LSET a, short length, long n)
{
   #line 117
   short j;
   #line 117
   short i;
   #line 119
   #line 119
   i = 0;
   #line 119
   j = 0;
   #line 120
   memset(res,0,(length+X2C_LSET_SIZE-1)/X2C_LSET_SIZE*(X2C_LSET_SIZE/8));
   #line 121
   if (n>=0l) {
      #line 122
      j=(short)(n % length);
      #line 123
      for (i=0; i<length; i++)
      #line 124
        if (a[i/X2C_LSET_SIZE] & (1<<(i%X2C_LSET_SIZE)))
      #line 125
            res[(i+j)%length/X2C_LSET_SIZE]|=1<<((i+j)%length%X2C_LSET_SIZE);
   }
   else {
      #line 127
      j=(short)(-n % length);
      #line 128
      for (i=0; i<length; i++)
      #line 129
        if (a[(i+j)%length/X2C_LSET_SIZE] & (1<<((i+j)%length%X2C_LSET_SIZE)))
      #line 130
            res[i/X2C_LSET_SIZE]|=1<<(i%X2C_LSET_SIZE);
   }
   #line 132
   return res;
} /* end X2C_ROTL() */

#line 137

#line 135
extern LSET X2C_LSHL(LSET res, LSET a, short length, long n)
{
   #line 136
   short j;
   #line 136
   short i;
   #line 138
   #line 138
   i = 0;
   #line 138
   j = 0;
   #line 139
   memset(res,0,(length+X2C_LSET_SIZE-1)/X2C_LSET_SIZE*(X2C_LSET_SIZE/8));
   #line 140
   if (n>=0l) {
      #line 141
      for (i=0; i+n<length; i++)
      #line 142
        if (a[i/X2C_LSET_SIZE] & (1<<(i%X2C_LSET_SIZE)))
      #line 143
            res[(i+n)/X2C_LSET_SIZE]|=1<<((i+n)%X2C_LSET_SIZE);
   }
   else {
      #line 145
      for (i=-n; i<length; i++)
      #line 146
        if (a[i/X2C_LSET_SIZE] & (1<<(i%X2C_LSET_SIZE)))
      #line 147
            res[(i+n)/X2C_LSET_SIZE]|=1<<((i+n)%X2C_LSET_SIZE);
   }
   #line 149
   return res;
} /* end X2C_LSHL() */

#line 152
