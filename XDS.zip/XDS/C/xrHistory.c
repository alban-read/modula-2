/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrHistory.h"
#define xrHistory_C_
#include "xmRTS.h"
#include "xPOSIX.h"

#line 20 "xrHistory.mod"
#define tag_first 0

#line 20
#line 21
#define tag_second 1

#line 21
#line 24
static X2C_Profile profile;

#line 25
static long total_time;

#line 118

#line 115
extern void X2C_show_history(void)
{
   #line 116
   int i;
   #line 117
   X2C_Coroutine current;
   #line 120
   struct X2C_Coroutine_STR * anonym;
   #line 119
   current = X2C_GetCurrent();
   #line 120
   { /* with */
      struct X2C_Coroutine_STR * anonym = current;
      #line 121
      if ((long)anonym->his_cnt>0l && (long)anonym->his_cnt<=254l) {
         #line 122
         anonym->his[(long)anonym->his_cnt-1l].fln = (short)X2C_hline;
      }
      #line 124
      if ((long)anonym->his_cnt>255l) {
         #line 125
         printf("History stack was truncated - not enough room.\n");
         #line 126
         anonym->his_cnt = 256;
      }
      #line 128
      while ((long)anonym->his_cnt>0l) {
         #line 129
         --anonym->his_cnt;
         #line 130
         i = (int)anonym->his[anonym->his_cnt].fln;
         #line 131
         if (anonym->his[anonym->his_cnt].fnm==0) {
            #line 132
            printf("???\n");
         }
         else {
            #line 134
            printf("%-18.18s %4d\n", anonym->his[anonym->his_cnt].fnm, i);
         }
      }
   }
} /* end X2C_show_history() */

#line 144

#line 142
extern void X2C_PROC_INP_F(char file[], long line)
{
   #line 143
   X2C_Coroutine current;
   #line 146
   struct X2C_Coroutine_STR * anonym;
   #line 145
   current = X2C_GetCurrent();
   #line 146
   { /* with */
      struct X2C_Coroutine_STR * anonym = current;
      #line 147
      if ((long)anonym->his_cnt>0l && (long)anonym->his_cnt<=256l) {
         #line 148
         anonym->his[(long)anonym->his_cnt-1l].fln = (short)X2C_hline;
      }
      #line 150
      if ((long)anonym->his_cnt<=255l) {
         #line 151
         anonym->his[anonym->his_cnt].fnm = (X2C_pCHAR)file;
         #line 152
         anonym->his[anonym->his_cnt].prf = 0;
         #line 153
         anonym->his[anonym->his_cnt].fln = (short)line;
         #line 154
         anonym->his[anonym->his_cnt].tags = 0u;
         #line 155
         X2C_hline = line;
      }
      #line 157
      ++anonym->his_cnt;
   }
} /* end X2C_PROC_INP_F() */

#line 165

#line 162
extern void X2C_PROC_PRF_F(char file[], long line, struct X2C_Profile_STR * p)
{
   #line 164
   X2C_Coroutine current;
   #line 167
   struct X2C_Coroutine_STR * anonym;
   #line 172
   struct X2C_his_rec * anonym0;
   #line 166
   current = X2C_GetCurrent();
   #line 167
   { /* with */
      struct X2C_Coroutine_STR * anonym = current;
      #line 168
      if ((long)anonym->his_cnt>0l && (long)anonym->his_cnt<=256l) {
         #line 169
         anonym->his[(long)anonym->his_cnt-1l].fln = (short)X2C_hline;
      }
      #line 171
      if ((long)anonym->his_cnt<=255l) {
         #line 172
         { /* with */
            struct X2C_his_rec * anonym0 = &anonym->his[anonym->his_cnt];
            #line 173
            anonym0->fnm = (X2C_pCHAR)file;
            #line 174
            anonym0->prf = p;
            #line 175
            anonym0->fln = (short)line;
            #line 176
            anonym0->tags = 0u;
            #line 177
            if ((0x1u & p->tags)) {
               #line 177
               anonym0->tags |= 0x2u;
            }
            else {
               #line 178
               p->tags |= 0x1u;
            }
         }
         #line 181
         X2C_hline = line;
      }
      #line 183
      ++anonym->his_cnt;
   }
   #line 185
   if (p->count==0l) {
      #line 186
      if (profile==0) {
         #line 186
         X2C_Profiler();
      }
      #line 187
      p->next = profile;
      #line 188
      profile = p;
   }
   #line 190
   ++p->count;
} /* end X2C_PROC_PRF_F() */

#line 197

#line 194
extern void X2C_Profiler_clock(void)
{
   #line 195
   long i;
   #line 196
   X2C_Coroutine current;
   #line 199
   struct X2C_Coroutine_STR * anonym;
   #line 202
   struct X2C_his_rec * anonym0;
   #line 198
   current = X2C_GetCurrent();
   #line 199
   { /* with */
      struct X2C_Coroutine_STR * anonym = current;
      #line 200
      i = 0l;
      #line 201
      while (i<(long)anonym->his_cnt && i<=255l) {
         #line 202
         { /* with */
            struct X2C_his_rec * anonym0 = &anonym->his[i];
            #line 203
            if (anonym0->prf && (0x2u & anonym0->tags)==0) {
               #line 203
               ++anonym0->prf->total;
            }
         }
         #line 205
         ++i;
      }
      #line 207
      if ((long)anonym->his_cnt<=256l && anonym->his[(long)anonym->his_cnt-1l].prf) {
         #line 208
         ++anonym->his[(long)anonym->his_cnt-1l].prf->time0;
      }
   }
   #line 211
   ++total_time;
} /* end X2C_Profiler_clock() */

#line 217

#line 215
extern void X2C_PROC_OUT_F(void)
{
   #line 216
   X2C_Coroutine current;
   #line 219
   struct X2C_Coroutine_STR * anonym;
   #line 222
   struct X2C_his_rec * anonym0;
   #line 218
   current = X2C_GetCurrent();
   #line 219
   { /* with */
      struct X2C_Coroutine_STR * anonym = current;
      #line 220
      --anonym->his_cnt;
      #line 221
      if ((long)anonym->his_cnt<=255l) {
         #line 222
         { /* with */
            struct X2C_his_rec * anonym0 = &anonym->his[anonym->his_cnt];
            #line 223
            if (anonym0->prf && (0x2u & anonym0->tags)==0) {
               #line 224
               anonym0->prf->tags &= ~0x1u;
            }
         }
      }
      #line 228
      if ((long)anonym->his_cnt>0l && (long)anonym->his_cnt<=254l) {
         #line 229
         X2C_hline = (long)anonym->his[(long)anonym->his_cnt-1l].fln;
      }
   }
} /* end X2C_PROC_OUT_F() */

#line 237

#line 235
extern void X2C_HIS_SAVE(short * sv)
{
   #line 236
   X2C_Coroutine current;
   #line 238
   current = X2C_GetCurrent();
   #line 239
   *sv = current->his_cnt;
} /* end X2C_HIS_SAVE() */

#line 245

#line 243
extern void X2C_HIS_RESTORE(short sv)
{
   #line 244
   X2C_Coroutine current;
   #line 247
   struct X2C_Coroutine_STR * anonym;
   #line 246
   current = X2C_GetCurrent();
   #line 247
   { /* with */
      struct X2C_Coroutine_STR * anonym = current;
      #line 248
      if ((long)anonym->his_cnt>0l && (long)anonym->his_cnt<=254l) {
         #line 249
         anonym->his[(long)anonym->his_cnt-1l].fln = (short)X2C_hline;
      }
      #line 251
      anonym->his_cnt = sv;
      #line 252
      if ((long)anonym->his_cnt>0l && (long)anonym->his_cnt<=254l) {
         #line 253
         X2C_hline = (long)anonym->his[(long)anonym->his_cnt-1l].fln;
      }
   }
} /* end X2C_HIS_RESTORE() */

#line 266

#line 264
extern void X2C_show_profile(void)
{
   #line 265
   X2C_Profile r;
   #line 265
   X2C_Profile q;
   #line 265
   X2C_Profile s;
   #line 265
   X2C_Profile prf;
   #line 265
   float sum;
   #line 267
   prf = profile;
   #line 268
   if (prf) {
      #line 269
      sum = (float)total_time;
      #line 270
      printf("Execution profile:\n");
      #line 271
      r = 0;
      #line 272
      while (prf) {
         #line 273
         s = prf;
         #line 273
         prf = prf->next;
         #line 274
         if (r==0) {
            #line 275
            r = s;
            #line 275
            s->next = 0;
         }
         else if (r->total<s->total) {
            #line 277
            s->next = r;
            #line 277
            r = s;
         }
         else {
            #line 279
            q = r;
            #line 280
            while (q->next && q->next->total>s->total) {
               #line 280
               q = q->next;
            }
            #line 281
            s->next = q->next;
            #line 281
            q->next = s;
         }
      }
      #line 284
      if (sum==0.0f) {
         #line 284
         sum = 1.0f;
      }
      #line 285
      do {
         #line 286
         printf("%-32.32s %10ld %6.2f %6.2f\n", r->name, r->count, (double)(X2C_DIVR((float)r->time0*100.0f,sum)), (double)(X2C_DIVR((float)r->total*100.0f,sum)));
         #line 291
         r = r->next;
      } while (r);
   }
} /* end X2C_show_profile() */

#line 297

#line 296
extern void X2C_scanStackHistory(X2C_ADDRESS from, X2C_ADDRESS to, char exact)
{
} /* end X2C_scanStackHistory() */

#line 301
