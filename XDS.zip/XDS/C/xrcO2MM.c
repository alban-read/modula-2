/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcO2MM.h"
#define xrcO2MM_C_
#include "xmRTS.h"
#include "M2EXCEPTION.h"
#include "xrMM.h"
#include "X2C.h"

#line 50 "xrcO2MM.mod"
#define AdrLss X2C_adr_lss

#line 50
#line 51
#define AdrGtr X2C_adr_gtr

#line 51
#line 54
#define LINK_SZ sizeof(struct X2C_LINK_STR)

#line 54
#line 58

#line 56
extern X2C_pVOID X2C_GUARDP_F(X2C_pVOID p, X2C_TD td)
{
   #line 57
   X2C_LINK ln;
   X2C_pVOID X2C_GUARDP_F_ret;
   #line 58
   X2C_PROC_INP();
   #line 59
   #line 59
   if (p==0) {
      #line 59
      (X2C_SET_HINFO() X2C_TRAP_F(3l));
   }
   #line 64
   ln = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)p-(long)sizeof(struct X2C_LINK_STR));
   #line 65
   if (ln->_.td->res!=0x093678150ul) {
      #line 65
      (X2C_SET_HINFO() X2C_ASSERT_F(102ul));
   }
   #line 66
   if (ln->_.td->base[td->level]!=td) {
      #line 66
      (X2C_SET_HINFO() X2C_TRAP_F((long)X2C_guardException));
   }
   #line 67
   X2C_GUARDP_F_ret = p;
   #line 68
   X2C_PROC_OUT();
   return X2C_GUARDP_F_ret;
} /* end X2C_GUARDP_F() */

#line 71

#line 70
extern X2C_TD X2C_GUARDV_F(X2C_TD vt, X2C_TD td)
{
   X2C_TD X2C_GUARDV_F_ret;
   #line 71
   X2C_PROC_INP();
   #line 72
   #line 72
   if (vt->base[td->level]!=td) {
      #line 72
      (X2C_SET_HINFO() X2C_TRAP_F((long)X2C_guardException));
   }
   #line 73
   X2C_GUARDV_F_ret = vt;
   #line 74
   X2C_PROC_OUT();
   return X2C_GUARDV_F_ret;
} /* end X2C_GUARDV_F() */

#line 78

#line 76
extern X2C_pVOID X2C_GUARDPE_F(X2C_pVOID p, X2C_TD td)
{
   #line 77
   X2C_LINK ln;
   X2C_pVOID X2C_GUARDPE_F_ret;
   #line 78
   X2C_PROC_INP();
   #line 79
   #line 79
   if (p==0) {
      #line 79
      (X2C_SET_HINFO() X2C_TRAP_F(3l));
   }
   #line 84
   ln = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)p-(long)sizeof(struct X2C_LINK_STR));
   #line 85
   if (ln->_.td!=td) {
      #line 85
      (X2C_SET_HINFO() X2C_TRAP_F((long)X2C_guardException));
   }
   #line 86
   X2C_GUARDPE_F_ret = p;
   #line 87
   X2C_PROC_OUT();
   return X2C_GUARDPE_F_ret;
} /* end X2C_GUARDPE_F() */

#line 90

#line 89
extern X2C_TD X2C_GUARDVE_F(X2C_TD vt, X2C_TD td)
{
   X2C_TD X2C_GUARDVE_F_ret;
   #line 90
   X2C_PROC_INP();
   #line 91
   #line 91
   if (vt!=td) {
      #line 91
      (X2C_SET_HINFO() X2C_TRAP_F((long)X2C_guardException));
   }
   #line 92
   X2C_GUARDVE_F_ret = vt;
   #line 93
   X2C_PROC_OUT();
   return X2C_GUARDVE_F_ret;
} /* end X2C_GUARDVE_F() */

#line 95
