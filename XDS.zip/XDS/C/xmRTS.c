/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xmRTS.h"
#define xmRTS_C_
#include "xrsetjmp.h"

#line 52 "xmRTS.def"


#line 61


#line 92


#line 100


#line 121


#line 129


#line 139


#line 187


#line 206
X2C_XSource X2C_rtsSource;
#line 207
X2C_XSource X2C_assertSrc;
#line 208
X2C_MD X2C_MODULES;
#line 209
long X2C_hline;
#line 212
char XDSLIB_INITIALIZATION_FAILED;
#line 230
#line 231
#line 234
#line 238
#line 240
#line 244
#line 247
#line 249
#line 252
#line 254
#line 257
#line 259
#line 262
#line 264
#line 267
#line 270
#line 272
#line 274
#line 276
#line 279
#line 282
#line 285
#line 288
#line 290
#line 293
#line 297
#line 301
#line 302
#line 303
#line 304
#line 305
#line 306
#line 308
#line 310
#line 312
#line 314
#line 316
#line 320
#line 322
#line 324
#line 326
#line 328
#line 330
#line 333
#line 336
#line 338
#line 340
#line 342
#line 344
#line 346
#line 348
#line 350
#line 353
#line 354
#line 355
#line 356
#line 359
#line 361
#line 363
#line 365
#line 368
#line 370
#line 382
#line 385
#line 388
#line 394
#line 397
#line 403
#line 406
#line 412
#line 420
#line 423
#line 426
#line 427
#line 431
#line 434
#line 436
#line 438
#line 440
#line 442
#line 445
#line 448
#line 464
unsigned long X2C_objects;
#line 466
unsigned long X2C_busymem;
#line 467
unsigned long X2C_busylheap;
#line 468
unsigned long X2C_smallbusy;
#line 469
unsigned long X2C_normalbusy;
#line 470
unsigned long X2C_largebusy;
#line 472
unsigned long X2C_usedmem;
#line 473
unsigned long X2C_smallused;
#line 474
unsigned long X2C_normalused;
#line 476
unsigned long X2C_usedlheap;
#line 478
unsigned long X2C_maxmem;
#line 479
unsigned long X2C_threshold;
#line 480
X2C_TD x2c_td_null;
#line 481
X2C_TD x2c_td_ptr;
#line 482
char X2C_fs_init;
#line 484
unsigned long X2C_MaxGCTimePercent;
#line 485
char X2C_GCThrashWarning;
#line 488
#line 516
#line 517
#line 520
#line 521
#line 524
#line 525
#line 528
#line 529
#line 532
#line 533
#line 536
#line 537
#line 538
#line 539
#line 542
#line 544
#line 547
#line 550
#line 551
#line 552
#line 553
#line 554
#line 555
#line 558
#line 559
#line 560
#line 561
#line 562
#line 563
#line 564
#line 567
#line 569
#line 571
#line 573
#line 576
#line 578
#line 580
#line 582
#line 584
#line 586
#line 588
#line 591
#line 593
#line 595
#line 597
#line 599
#line 601
#line 603
#line 606
#line 609
#line 611
#line 613
#line 616
#line 618
#line 621
#line 625
#line 626
#line 627
#line 628
#line 630
#line 19 "xmRTS.mod"
#line 22

#line 21
extern void X2C_INIT_RTS(void)
{
} /* end X2C_INIT_RTS() */

#line 27
extern void X2C_MODULEXE(X2C_MD, X2C_ADDRESS);

#line 27
#line 31

#line 29
extern void X2C_MODULE(X2C_MD md)
{
   #line 32
   X2C_MODULEXE(md, 0);
} /* end X2C_MODULE() */

#line 44
