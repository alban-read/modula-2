/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcACMPLX.h"
#define xrcACMPLX_C_
#include "X2C.h"
#include "M2EXCEPTION.h"

#line 16 "xrcACMPLX.mod"

#line 15
extern int CPLX_CMP(X2C_COMPLEX x, X2C_COMPLEX y)
{
   #line 17
   #line 17
   if (x.re==y.re && x.im==y.im) {
      #line 17
      return 0;
   }
   #line 18
   return 1;
} /* end CPLX_CMP() */

#line 22

#line 21
extern X2C_COMPLEX CPLX_ADD(X2C_COMPLEX x, X2C_COMPLEX y)
{
   X2C_COMPLEX tmp;
   #line 23
   #line 23
   return (tmp.re = x.re+y.re,tmp.im = x.im+y.im,tmp);
} /* end CPLX_ADD() */

#line 27

#line 26
extern X2C_COMPLEX CPLX_SUB(X2C_COMPLEX x, X2C_COMPLEX y)
{
   X2C_COMPLEX tmp;
   #line 28
   #line 28
   return (tmp.re = x.re-y.re,tmp.im = x.im-y.im,tmp);
} /* end CPLX_SUB() */

#line 32

#line 31
extern X2C_COMPLEX CPLX_MUL(X2C_COMPLEX x, X2C_COMPLEX y)
{
   X2C_COMPLEX tmp;
   #line 33
   #line 33
   return (tmp.re = x.re*y.re-x.im*y.im,tmp.im = x.re*y.im+x.im*y.re,tmp);
} /* end CPLX_MUL() */

#line 38

#line 36
extern X2C_COMPLEX CPLX_DIV(X2C_COMPLEX x, X2C_COMPLEX y)
{
   #line 37
   float d;
   X2C_COMPLEX tmp;
   #line 39
   #line 39
   d = y.re*y.re+y.im*y.im;
   #line 40
   if (d==0.0f) {
      #line 40
      X2C_TRAP(10l);
   }
   #line 41
   return (tmp.re = X2C_DIVR(x.re*y.re+x.im*y.im,d),tmp.im = X2C_DIVR(x.im*y.re-x.re*y.im,d),tmp);
} /* end CPLX_DIV() */

#line 45

#line 44
extern X2C_COMPLEX CPLX_NEG(X2C_COMPLEX x)
{
   X2C_COMPLEX tmp;
   #line 46
   #line 46
   return (tmp.re = -x.re,tmp.im = -x.im,tmp);
} /* end CPLX_NEG() */

#line 50

#line 49
extern int CPLX_LCMP(X2C_LONGCOMPLEX x, X2C_LONGCOMPLEX y)
{
   #line 51
   #line 51
   if (x.re==y.re && x.im==y.im) {
      #line 51
      return 0;
   }
   #line 52
   return 1;
} /* end CPLX_LCMP() */

#line 56

#line 55
extern X2C_LONGCOMPLEX CPLX_LADD(X2C_LONGCOMPLEX x, X2C_LONGCOMPLEX y)
{
   X2C_LONGCOMPLEX tmp;
   #line 57
   #line 57
   return (tmp.re = x.re+y.re,tmp.im = x.im+y.im,tmp);
} /* end CPLX_LADD() */

#line 61

#line 60
extern X2C_LONGCOMPLEX CPLX_LSUB(X2C_LONGCOMPLEX x, X2C_LONGCOMPLEX y)
{
   X2C_LONGCOMPLEX tmp;
   #line 62
   #line 62
   return (tmp.re = x.re-y.re,tmp.im = x.im-y.im,tmp);
} /* end CPLX_LSUB() */

#line 66

#line 65
extern X2C_LONGCOMPLEX CPLX_LMUL(X2C_LONGCOMPLEX x, X2C_LONGCOMPLEX y)
{
   X2C_LONGCOMPLEX tmp;
   #line 67
   #line 67
   return (tmp.re = x.re*y.re-x.im*y.im,tmp.im = x.re*y.im+x.im*y.re,tmp);
} /* end CPLX_LMUL() */

#line 72

#line 70
extern X2C_LONGCOMPLEX CPLX_LDIV(X2C_LONGCOMPLEX x, X2C_LONGCOMPLEX y)
{
   #line 71
   double d;
   X2C_LONGCOMPLEX tmp;
   #line 73
   #line 73
   d = y.re*y.re+y.im*y.im;
   #line 74
   if (d==0.0) {
      #line 74
      X2C_TRAP(10l);
   }
   #line 75
   return (tmp.re = X2C_DIVL(x.re*y.re+x.im*y.im,d),tmp.im = X2C_DIVL(x.im*y.re-x.re*y.im,d),tmp);
} /* end CPLX_LDIV() */

#line 79

#line 78
extern X2C_LONGCOMPLEX CPLX_LNEG(X2C_LONGCOMPLEX x)
{
   X2C_LONGCOMPLEX tmp;
   #line 80
   #line 80
   return (tmp.re = -x.re,tmp.im = -x.im,tmp);
} /* end CPLX_LNEG() */

#line 84

#line 83
extern X2C_LONGCOMPLEX CPLX_L(X2C_COMPLEX x)
{
   X2C_LONGCOMPLEX tmp;
   #line 85
   #line 85
   return (tmp.re = (double)x.re,tmp.im = (double)x.im,tmp);
} /* end CPLX_L() */

#line 90
