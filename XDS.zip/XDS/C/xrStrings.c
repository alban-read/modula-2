/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrStrings.h"
#define xrStrings_C_
#include "xmRTS.h"

#line 17 "xrStrings.mod"

#line 16
extern char X2C_CAP(char x)
{
   #line 18
   #line 18
   if ((unsigned char)x>='a' && (unsigned char)x<='z') {
      #line 18
      x = (char)(((unsigned long)(unsigned char)x+65ul)-97ul);
   }
   #line 19
   return x;
} /* end X2C_CAP() */

#line 25

#line 22
extern X2C_pVOID X2C_COPY(X2C_pVOID s, size_t s_len, X2C_pVOID d, size_t d_len)
{
   #line 24
   X2C_pCHAR y;
   #line 24
   X2C_pCHAR x;
   #line 24
   size_t i;
   #line 26
   #line 26
   x = (X2C_pCHAR)s;
   #line 27
   y = (X2C_pCHAR)d;
   #line 28
   if (s_len>=d_len) {
      #line 28
      s_len = d_len-1u;
   }
   #line 29
   i = 0u;
   #line 30
   while (i<s_len && *x) {
      #line 31
      *y = *x;
      #line 32
      x = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)x+(long)1ul);
      #line 33
      y = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)y+(long)1ul);
      #line 34
      ++i;
   }
   #line 36
   *y = 0;
   #line 37
   return d;
} /* end X2C_COPY() */

#line 48

#line 46
extern size_t X2C_LENGTH(X2C_pVOID s, size_t s_len)
{
   #line 47
   X2C_pCHAR x;
   #line 47
   size_t i;
   #line 49
   #line 49
   x = (X2C_pCHAR)s;
   #line 50
   i = 0u;
   #line 51
   while (i<s_len && *x) {
      #line 52
      x = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)x+(long)1ul);
      #line 53
      ++i;
   }
   #line 55
   return i;
} /* end X2C_LENGTH() */

#line 60
