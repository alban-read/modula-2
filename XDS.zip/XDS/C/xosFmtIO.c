/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosFmtIO.h"
#define xosFmtIO_C_
#include "xrtsOS.h"

#line 12 "xosFmtIO.mod"
#define spaces "        "

#line 12
#line 15

#line 14
static void outs(char s[], unsigned long len)
{
   #line 15
   X2C_PROC_INP();
   #line 16
   #line 16
   if (len==0ul) {
      #line 16
      goto label;
   }
   #line 17
   (X2C_SET_HINFO() X2C_StdOut(s, len));
   label:;
   #line 18
   X2C_PROC_OUT();
} /* end outs() */

#line 22

#line 20
extern void X2C_StdOutS(char s[], unsigned long w)
{
   #line 21
   unsigned long l;
   #line 22
   X2C_PROC_INP();
   #line 23
   l = 0ul;
   #line 23
   while (s[l]) {
      #line 23
      X2C_INCU(&l,1ul,0ul,X2C_max_longcard);
   }
   #line 24
   (X2C_SET_HINFO() outs(s, l));
   #line 25
   if (w>l) {
      #line 26
      while (w-l>8ul) {
         #line 26
         (X2C_SET_HINFO() outs("        ", 8ul));
         #line 26
         X2C_INCU(&l,8ul,0ul,X2C_max_longcard);
      }
      #line 27
      if (w>l) {
         #line 27
         (X2C_SET_HINFO() outs("        ", w-l));
      }
   }
   #line 29
   X2C_PROC_OUT();
} /* end X2C_StdOutS() */

#line 33

#line 31
extern void X2C_HexToStr(char s[], unsigned long * pos, unsigned long no)
{
   #line 32
   unsigned long i;
   #line 32
   unsigned long d;
   #line 33
   X2C_PROC_INP();
   #line 34
   X2C_INCU(pos,8ul,0ul,X2C_max_longcard);
   #line 35
   for (i = 0ul; i<=7ul; i++) {
      #line 36
      d = no&15ul;
      #line 37
      no = no/16ul;
      #line 38
      X2C_DECU(pos,1ul,0ul,X2C_max_longcard);
      #line 39
      if (d>9ul) {
         #line 40
         s[*pos] = (char)X2C_CHKUL((65ul+d)-10ul,0ul,255ul);
      }
      else {
         #line 42
         s[*pos] = (char)X2C_CHKUL(48ul+d,0ul,255ul);
      }
   } /* end for */
   #line 45
   X2C_PROC_OUT();
} /* end X2C_HexToStr() */

#line 49

#line 47
extern void X2C_StdOutH(unsigned long no, unsigned long w)
{
   #line 48
   char buf[12];
   #line 48
   unsigned long pos;
   #line 49
   X2C_PROC_INP();
   #line 50
   pos = 0ul;
   #line 51
   (X2C_SET_HINFO() X2C_HexToStr(buf, &pos, no));
   #line 52
   if (w>8ul) {
      #line 53
      while (w>16ul) {
         #line 53
         (X2C_SET_HINFO() outs("        ", 8ul));
         #line 53
         X2C_DECU(&w,8ul,0ul,X2C_max_longcard);
      }
      #line 54
      if (w>8ul) {
         #line 54
         (X2C_SET_HINFO() outs("        ", w-8ul));
      }
   }
   #line 56
   (X2C_SET_HINFO() outs(buf, 8ul));
   #line 57
   X2C_PROC_OUT();
} /* end X2C_StdOutH() */

#line 61

#line 59
extern void X2C_DecToStr(char s[], unsigned long * pos, unsigned long no)
{
   #line 60
   unsigned long i;
   #line 60
   unsigned long l;
   #line 61
   X2C_PROC_INP();
   #line 62
   i = 1000000000ul;
   #line 62
   l = 10ul;
   #line 63
   while (i>no) {
      #line 63
      i = i/10ul;
      #line 63
      X2C_DECU(&l,1ul,0ul,X2C_max_longcard);
   }
   #line 64
   if (l==0ul) {
      #line 64
      l = 1ul;
   }
   #line 65
   X2C_INCU(pos,l,0ul,X2C_max_longcard);
   #line 66
   i = *pos;
   #line 67
   while (l>0ul) {
      #line 68
      X2C_DECU(&i,1ul,0ul,X2C_max_longcard);
      #line 69
      s[i] = (char)X2C_CHKUL(48ul+no%10ul,0ul,255ul);
      #line 70
      no = no/10ul;
      #line 71
      X2C_DECU(&l,1ul,0ul,X2C_max_longcard);
   }
   #line 73
   if (no) X2C_ASSERT(0);
   #line 74
   X2C_PROC_OUT();
} /* end X2C_DecToStr() */

#line 78

#line 76
extern void X2C_StdOutD(unsigned long no, unsigned long w)
{
   #line 77
   char buf[12];
   #line 77
   unsigned long pos;
   #line 78
   X2C_PROC_INP();
   #line 79
   pos = 0ul;
   #line 80
   (X2C_SET_HINFO() X2C_DecToStr(buf, &pos, no));
   #line 81
   if (w>pos) {
      #line 82
      while (w-pos>8ul) {
         #line 82
         (X2C_SET_HINFO() outs("        ", 8ul));
         #line 82
         X2C_DECU(&w,8ul,0ul,X2C_max_longcard);
      }
      #line 83
      if (w>pos) {
         #line 83
         (X2C_SET_HINFO() outs("        ", w-pos));
      }
   }
   #line 85
   (X2C_SET_HINFO() outs(buf, pos));
   #line 86
   X2C_PROC_OUT();
} /* end X2C_StdOutD() */

#line 88
