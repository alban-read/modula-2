/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosExec.h"
#define xosExec_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "xlibOS.h"
#include "X2C.h"

#line 8 "xosExec.mod"
#line 9
#line 16

#line 11
extern long X2C_Execute(X2C_pCHAR cmd, X2C_pCHAR args, int overlay, unsigned long * exitcode)
{
   #line 13
   xPOSIX_PCHAR argv[256];
   #line 14
   long i;
   #line 15
   long rc;
   long X2C_Execute_ret;
   #line 16
   X2C_PROC_INP();
   #line 17
   #line 17
   i = 1l;
   #line 18
   for (;;) {
      #line 19
      while ((unsigned char)(*X2C_CHKNIL(X2C_pCHAR,args))<=' ') {
         #line 20
         if (*args==0) {
            #line 20
            goto loop_exit;
         }
         #line 21
         args = (X2C_pCHAR)(X2C_ADDRESS)((char *)X2C_CHKNIL(X2C_ADDRESS,args)+(long)1ul);
      }
      #line 23
      argv[X2C_CHKINX(i,256u)] = (xPOSIX_PCHAR)args;
      #line 23
      X2C_INC(&i,1l,X2C_min_longint,X2C_max_longint);
      #line 24
      while ((unsigned char)(*X2C_CHKNIL(X2C_pCHAR,args))>' ') {
         #line 24
         args = (X2C_pCHAR)(X2C_ADDRESS)((char *)X2C_CHKNIL(X2C_ADDRESS,args)+(long)1ul);
      }
      #line 25
      if (*args==0) {
         #line 25
         break;
      }
      #line 26
      *args = 0;
      #line 26
      args = (X2C_pCHAR)(X2C_ADDRESS)((char *)X2C_CHKNIL(X2C_ADDRESS,args)+(long)1ul);
   }
   loop_exit:;
   #line 28
   argv[X2C_CHKINX(i,256u)] = 0;
   #line 29
   argv[0u] = (xPOSIX_PCHAR)cmd;
   #line 30
   if (overlay) {
      #line 31
      #if defined(_msdos)
      #line 32
      rc = (X2C_SET_HINFO() spawnv(P_WAIT, cmd, argv));
      #line 33
      #else
      #line 34
      rc = (X2C_SET_HINFO() execv(cmd, argv));
      #line 35
      #endif
   }
   else {
      #line 37
      rc = (X2C_SET_HINFO() spawnv(P_WAIT, cmd, argv));
   }
   #line 39
   if (rc<0l) {
      #line 40
      X2C_Execute_ret = errno;
   }
   else {
      #line 42
      *exitcode = (unsigned long)X2C_CHKL(rc,0l,X2C_max_longint);
      #line 43
      X2C_Execute_ret = 0l;
   }
   #line 45
   X2C_PROC_OUT();
   return X2C_Execute_ret;
} /* end X2C_Execute() */

#line 48

#line 47
extern long X2C_ExecuteNoWindow(X2C_pCHAR cmd, X2C_pCHAR args, int overlay, unsigned long * exitcode)
{
   long X2C_ExecuteNoWindow_ret;
   #line 48
   X2C_PROC_INP();
   #line 49
   #line 49
   X2C_ExecuteNoWindow_ret = (X2C_SET_HINFO() X2C_Execute(cmd, args, overlay, exitcode));
   #line 50
   X2C_PROC_OUT();
   return X2C_ExecuteNoWindow_ret;
} /* end X2C_ExecuteNoWindow() */

#line 56

#line 54
extern long X2C_Command(X2C_pCHAR cmd, unsigned long * exitcode)
{
   #line 55
   long rc;
   long X2C_Command_ret;
   #line 56
   X2C_PROC_INP();
   #line 57
   #line 57
   rc = (X2C_SET_HINFO() system(cmd));
   #line 58
   if (rc<0l) {
      #line 59
      X2C_Command_ret = errno;
   }
   else {
      #line 61
      *exitcode = (unsigned long)X2C_CHKL(rc,0l,X2C_max_longint);
      #line 62
      X2C_Command_ret = 0l;
   }
   #line 64
   X2C_PROC_OUT();
   return X2C_Command_ret;
} /* end X2C_Command() */

#line 66
