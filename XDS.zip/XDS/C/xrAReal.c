/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrAReal.h"
#define xrAReal_C_
#include "X2C.h"
#include "M2EXCEPTION.h"

#line 22 "xrAReal.mod"

#line 20
extern long X2C_ENTIER(double x)
{
   #line 21
   long i;
   #line 23
   #line 23
   if (x<(-2.147483648E+9) || x>2.147483647E+9) {
      #line 24
      X2C_TRAP(1l);
   }
   #line 26
   i=(long)x;
   #line 27
   if ((double)i>x) {
      #line 27
      --i;
   }
   #line 28
   return i;
} /* end X2C_ENTIER() */

#line 33

#line 31
extern long X2C_TRUNCI(double x, long min0, long max0)
{
   #line 32
   long i;
   #line 34
   #line 34
   if (x<(double)min0 || x>(double)max0) {
      #line 35
      X2C_TRAP(1l);
   }
   #line 37
   i=(long)x;
   #line 38
   if (x>0.0) {
      #line 39
      if ((double)i>x) {
         #line 39
         --i;
      }
   }
   else if ((double)i<x) {
      #line 41
      ++i;
   }
   #line 43
   return i;
} /* end X2C_TRUNCI() */

#line 48

#line 46
extern unsigned long X2C_TRUNCC(double x, unsigned long min0, unsigned long max0)
{
   #line 47
   unsigned long i;
   #line 49
   #line 49
   if (x<(double)min0 || x>(double)max0) {
      #line 50
      X2C_TRAP(1l);
   }
   #line 52
   i=(unsigned long)x;
   #line 53
   if ((double)i>x) {
      #line 53
      --i;
   }
   #line 54
   return i;
} /* end X2C_TRUNCC() */

#line 70
