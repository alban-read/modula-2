/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosEnv.h"
#define xosEnv_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "X2C.h"

#line 8 "xosEnv.mod"
typedef char * PSTR;

#line 12

#line 10
extern unsigned long X2C_EnvStringLength(X2C_pCHAR name)
{
   #line 11
   X2C_pCHAR p;
   unsigned long X2C_EnvStringLength_ret;
   #line 12
   X2C_PROC_INP();
   #line 13
   #line 13
   p = (X2C_pCHAR)(X2C_SET_HINFO() getenv(name));
   #line 14
   if (p==0) {
      #line 14
      X2C_EnvStringLength_ret = 0ul;
      goto label;
   }
   #line 15
   X2C_EnvStringLength_ret = (X2C_SET_HINFO() strlen(p));
   label:;
   #line 16
   X2C_PROC_OUT();
   return X2C_EnvStringLength_ret;
} /* end X2C_EnvStringLength() */

#line 22

#line 18
extern void X2C_EnvString(X2C_pCHAR name, X2C_pCHAR buf, unsigned long blen)
{
   #line 19
   X2C_pCHAR p;
   #line 20
   PSTR t;
   #line 20
   PSTR f;
   #line 21
   unsigned long i;
   #line 22
   X2C_PROC_INP();
   #line 23
   #line 23
   p = (X2C_pCHAR)(X2C_SET_HINFO() getenv(name));
   #line 24
   if (p==0) {
      #line 24
      goto label;
   }
   #line 25
   f = (PSTR)p;
   #line 26
   t = (PSTR)buf;
   #line 27
   i = 0ul;
   #line 28
   while (i<blen && X2C_CHKNIL(PSTR,f)[i]) {
      #line 29
      X2C_CHKNIL(PSTR,t)[i] = X2C_CHKNIL(PSTR,f)[i];
      #line 30
      X2C_INCU(&i,1ul,0ul,X2C_max_longcard);
   }
   #line 32
   if (i<blen) {
      #line 32
      X2C_CHKNIL(PSTR,t)[i] = 0;
   }
   label:;
   #line 33
   X2C_PROC_OUT();
} /* end X2C_EnvString() */

#line 35
static char EmptyName[1] = "";

#line 38

#line 37
extern X2C_pCHAR X2C_GetProgramName(void)
{
   X2C_pCHAR X2C_GetProgramName_ret;
   #line 38
   X2C_PROC_INP();
   #line 39
   #line 39
   if (X2C_argc==0) {
      #line 40
      X2C_GetProgramName_ret = EmptyName;
   }
   else {
      #line 42
      X2C_GetProgramName_ret = (X2C_pCHAR)(*X2C_CHKNIL(char * *,X2C_argv));
   }
   #line 44
   X2C_PROC_OUT();
   return X2C_GetProgramName_ret;
} /* end X2C_GetProgramName() */

#line 46
