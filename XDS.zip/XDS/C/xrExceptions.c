/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrExceptions.h"
#define xrExceptions_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "xrsetjmp.h"
#include "X2C.h"
#include "xrtsOS.h"
#include "M2EXCEPTION.h"

#line 32 "xrExceptions.mod"
#define st_normal 0

#line 32
#line 33
#define st_exceptional 1

#line 33
#line 34
#define st_off 2

#line 34
#line 35
#define st_reraise 3

#line 35
#line 39

#line 37
extern void X2C_XInitHandler(X2C_XHandler x)
{
   #line 38
   X2C_Coroutine current;
   #line 40
   current = X2C_GetCurrent();
   #line 41
   x->state = 0;
   #line 42
   x->source = 0;
   #line 43
   x->next = current->handler;
   #line 45
   X2C_HIS_SAVE(&x->history);
   #line 47
   current->handler = x;
} /* end X2C_XInitHandler() */

#line 52

#line 50
extern void X2C_XOFF(void)
{
   #line 51
   X2C_Coroutine current;
   #line 53
   current = X2C_GetCurrent();
   #line 54
   current->handler->state = 2;
} /* end X2C_XOFF() */

#line 59

#line 57
extern void X2C_XON(void)
{
   #line 58
   X2C_Coroutine current;
   #line 60
   current = X2C_GetCurrent();
   #line 61
   current->handler->state = 3;
} /* end X2C_XON() */

#line 67

#line 64
extern void X2C_XRETRY(void)
{
   #line 65
   X2C_Coroutine current;
   #line 66
   X2C_XHandler x;
   #line 68
   current = X2C_GetCurrent();
   #line 69
   x = current->handler;
   #line 70
   x->state = 0;
   #line 72
   X2C_HIS_RESTORE(x->history);
   #line 79
   x->source = 0;
   #line 80
   longjmp(x->buf, 1);
} /* end X2C_XRETRY() */

#line 84
static struct X2C_XSource_STR sysSourceRec;

#line 84
static struct X2C_XSource_STR assertSourceRec;

#line 87

#line 86
extern void X2C_init_exceptions(void)
{
   #line 89
   struct X2C_XSource_STR * anonym;
   #line 97
   struct X2C_XSource_STR * anonym0;
   #line 88
   X2C_rtsSource = &sysSourceRec;
   #line 89
   { /* with */
      struct X2C_XSource_STR * anonym = X2C_rtsSource;
      #line 90
      anonym->number = 0ul;
      #line 91
      anonym->message[0u] = 0;
   }
   #line 96
   X2C_assertSrc = &assertSourceRec;
   #line 97
   { /* with */
      struct X2C_XSource_STR * anonym0 = X2C_assertSrc;
      #line 98
      anonym0->number = 0ul;
      #line 99
      anonym0->message[0u] = 0;
   }
} /* end X2C_init_exceptions() */

#line 109

#line 106
static void dectostr(char s[], unsigned long s_len, unsigned long * pos, unsigned long no)
{
   #line 107
   unsigned long i;
   #line 107
   unsigned long l;
   #line 108
   unsigned long x;
   #line 110
   l = 0ul;
   #line 110
   x = no;
   #line 111
   while (x>0ul) {
      #line 111
      x = x/10ul;
      #line 111
      ++l;
   }
   #line 112
   if (l==0ul) {
      #line 112
      l = 1ul;
   }
   #line 113
   *pos += l;
   #line 114
   i = *pos;
   #line 115
   while (l>0ul) {
      #line 116
      --i;
      #line 117
      s[i] = (char)(48ul+no%10ul);
      #line 118
      no = no/10ul;
      #line 119
      --l;
   }
} /* end dectostr() */

#line 129

#line 127
static void app(char d[], unsigned long d_len, unsigned long M, unsigned long * pos, char s[], unsigned long s_len)
{
   #line 128
   unsigned long i;
   #line 130
   i = 0ul;
   #line 131
   while (*pos<M && s[i]) {
      #line 132
      d[*pos] = s[i];
      #line 132
      ++*pos;
      #line 132
      ++i;
   }
} /* end app() */

#line 138

#line 136
static void form_msg(X2C_Coroutine cur, X2C_XSource source)
{
   #line 137
   unsigned long pos;
   #line 139
   pos = 0ul;
   #line 140
   app(cur->his_msg, 1024ul, 1024ul, &pos, "#RTS: unhandled exception #", 28ul);
   #line 141
   X2C_DecToStr(cur->his_msg, &pos, source->number);
   #line 142
   if (source->message[0u]) {
      #line 143
      app(cur->his_msg, 1024ul, 1024ul, &pos, ": ", 3ul);
      #line 144
      app(cur->his_msg, 1024ul, 1024ul, &pos, source->message, 1024ul);
   }
   #line 146
   if (pos>=1024ul) {
      #line 146
      pos = 1023ul;
   }
   #line 147
   cur->his_msg[pos] = 0;
} /* end form_msg() */

#line 150

#line 123
static void doRaise(X2C_XSource source)
{
   #line 124
   X2C_XHandler x;
   #line 125
   X2C_Coroutine current;
   #line 151
   current = X2C_GetCurrent();
   #line 152
   x = current->handler;
   #line 153
   while (x && x->state) {
      #line 153
      x = x->next;
   }
   #line 154
   current->handler = x;
   #line 155
   if (x==0) {
      #line 156
      X2C_StdOut("\n#RTS: unhandled exception #", 28ul);
      #line 157
      X2C_StdOutD(source->number, 0ul);
      #line 158
      if (source->message[0u]) {
         #line 159
         X2C_StdOut(": ", 2ul);
         #line 160
         X2C_StdOut(source->message, X2C_LENGTH(source->message,1024ul));
      }
      #line 162
      X2C_StdOutN();
      #line 163
      form_msg(current, source);
      #line 164
      X2C_show_history();
      #line 165
      X2C_StdOutFlush();
      #line 169
      X2C_ABORT();
   }
   else {
      #line 171
      x->source = source;
      #line 172
      x->state = 1;
   }
   #line 175
   X2C_HIS_RESTORE(x->history);
   #line 177
   longjmp(x->buf, 2);
} /* end doRaise() */

#line 184

#line 180
extern void X2C_doRaise(X2C_XSource source)
{
   #line 189
   doRaise(source);
} /* end X2C_doRaise() */

#line 197

#line 192
extern void X2C_XREMOVE(void)
{
   #line 194
   X2C_XHandler x;
   #line 195
   X2C_XSource s;
   #line 196
   X2C_Coroutine current;
   #line 198
   current = X2C_GetCurrent();
   #line 199
   x = current->handler;
   #line 200
   if (x==0) {
      #line 200
      X2C_TRAP_F((long)X2C_internalError);
   }
   #line 201
   if ((long)x->state==3l) {
      #line 202
      s = x->source;
      #line 203
      current->handler = x->next;
      #line 204
      doRaise(s);
   }
   else {
      #line 211
      current->handler = x->next;
   }
} /* end X2C_XREMOVE() */

#line 216

#line 215
static void trap_message(char msg[], unsigned long msg_len, unsigned long no)
{
   #line 217
   switch (no) {
   case 0ul:
      #line 219
      X2C_COPY("invalid index",14ul,msg,msg_len);
      break;
   case 1ul:
      #line 221
      X2C_COPY("expression out of bounds",25ul,msg,msg_len);
      break;
   case 2ul:
      #line 223
      X2C_COPY("invalid case in CASE statement",31ul,msg,msg_len);
      break;
   case 3ul:
      #line 225
      X2C_COPY("invalid location",17ul,msg,msg_len);
      break;
   case 4ul:
      #line 227
      X2C_COPY("function without RETURN statement",34ul,msg,msg_len);
      break;
   case 5ul:
      #line 229
      X2C_COPY("whole overflow",15ul,msg,msg_len);
      break;
   case 6ul:
      #line 231
      X2C_COPY("zero or negative divisor",25ul,msg,msg_len);
      break;
   case 7ul:
      #line 233
      X2C_COPY("real overflow",14ul,msg,msg_len);
      break;
   case 8ul:
      #line 235
      X2C_COPY("float division by zero",23ul,msg,msg_len);
      break;
   case 9ul:
      #line 237
      X2C_COPY("complex overflow",17ul,msg,msg_len);
      break;
   case 10ul:
      #line 239
      X2C_COPY("complex division by zero",25ul,msg,msg_len);
      break;
   case 11ul:
      #line 241
      X2C_COPY("protection error",17ul,msg,msg_len);
      break;
   case 12ul:
      #line 243
      X2C_COPY("SYSTEM exception",17ul,msg,msg_len);
      break;
   case 13ul:
      #line 245
      X2C_COPY("COROUTINE exception",20ul,msg,msg_len);
      break;
   case 14ul:
      #line 247
      X2C_COPY("EXCEPTIONS exception",21ul,msg,msg_len);
      break;
   default:;
      #line 250
      if (no==X2C_assertException) {
         #line 251
         X2C_COPY("ASSERT",7ul,msg,msg_len);
      }
      else if (no==X2C_guardException) {
         #line 253
         X2C_COPY("type guard check",17ul,msg,msg_len);
      }
      else if (no==X2C_noMemoryException) {
         #line 257
         X2C_COPY("out of heap space",18ul,msg,msg_len);
      }
      else if (no==X2C_unreachDLL) {
         #line 259
         X2C_COPY("call to unloaded DLL",21ul,msg,msg_len);
      }
      else if (no==X2C_internalError) {
         #line 261
         X2C_COPY("RTS internal error",19ul,msg,msg_len);
      }
      else if (no==X2C_castError) {
         #line 263
         X2C_COPY("invalid type cast",18ul,msg,msg_len);
      }
      else if (no==X2C_UserBreak) {
         #line 265
         X2C_COPY("USER BREAK",11ul,msg,msg_len);
      }
      else if (no==X2C_stack_overflow) {
         #line 267
         X2C_COPY("stack overflow",15ul,msg,msg_len);
      }
      else {
         #line 269
         msg[0ul] = 0;
      }
      break;
   } /* end switch */
} /* end trap_message() */

#line 277

#line 274
extern void X2C_TRAP_F(long no)
{
   #line 275
   unsigned long pos;
   #line 290
   struct X2C_XSource_STR * anonym;
   #line 282
   if (X2C_rtsSource==0) {
      #line 283
      X2C_init_exceptions();
   }
   #line 288
   trap_message(X2C_rtsSource->message, 1024ul, (unsigned long)no);
   #line 289
   if (X2C_rtsSource->message[0u]==0) {
      #line 290
      { /* with */
         struct X2C_XSource_STR * anonym = X2C_rtsSource;
         #line 291
         X2C_COPY("TRAP(",6ul,anonym->message,1024u);
         #line 292
         pos = 5ul;
         #line 293
         dectostr(anonym->message, 1024ul, &pos, (unsigned long)no);
         #line 294
         anonym->message[pos] = ')';
         #line 295
         anonym->message[pos+1ul] = 0;
      }
   }
   #line 298
   X2C_rtsSource->number = (unsigned long)no;
   #line 299
   doRaise(X2C_rtsSource);
} /* end X2C_TRAP_F() */

#line 304

#line 302
static void append(char d[], unsigned long M, unsigned long * pos, char s[])
{
   #line 303
   unsigned long i;
   #line 305
   i = 0ul;
   #line 306
   while (*pos<M && s[i]) {
      #line 307
      d[*pos] = s[i];
      #line 307
      ++*pos;
      #line 307
      ++i;
   }
} /* end append() */

#line 319

#line 314
extern void X2C_TRAP_FC(long no, X2C_pCHAR file, unsigned long line)
{
   #line 316
   unsigned long pos;
   #line 317
   char ls[16];
   #line 339
   struct X2C_XSource_STR * anonym;
   #line 324
   if (X2C_rtsSource==0) {
      #line 325
      X2C_init_exceptions();
   }
   #line 330
   pos = 0ul;
   #line 331
   dectostr(ls, 16ul, &pos, line);
   #line 331
   ls[pos] = 0;
   #line 332
   trap_message(X2C_rtsSource->message, 1024ul, (unsigned long)no);
   #line 333
   pos = 0ul;
   #line 334
   while (X2C_rtsSource->message[pos]) {
      #line 335
      ++pos;
   }
   #line 338
   if (X2C_rtsSource->message[0u]==0) {
      #line 339
      { /* with */
         struct X2C_XSource_STR * anonym = X2C_rtsSource;
         #line 340
         X2C_COPY("TRAP(",6ul,anonym->message,1024u);
         #line 341
         pos = 5ul;
         #line 342
         dectostr(anonym->message, 1024ul, &pos, (unsigned long)no);
         #line 343
         anonym->message[pos] = ')';
         #line 344
         anonym->message[pos+1ul] = 0;
         #line 345
         ++pos;
      }
   }
   #line 348
   if (file) {
      #line 349
      append(X2C_rtsSource->message, 1023ul, &pos, " at line ");
      #line 350
      append(X2C_rtsSource->message, 1023ul, &pos, ls);
      #line 351
      append(X2C_rtsSource->message, 1023ul, &pos, " of ");
      #line 352
      append(X2C_rtsSource->message, 1023ul, &pos, file);
      #line 353
      if (pos>=1024ul) {
         #line 353
         pos = 1023ul;
      }
      #line 354
      X2C_rtsSource->message[pos] = 0;
   }
   #line 356
   X2C_rtsSource->number = (unsigned long)no;
   #line 357
   doRaise(X2C_rtsSource);
} /* end X2C_TRAP_FC() */

#line 367

#line 364
extern void X2C_ASSERT_F(unsigned long no)
{
   #line 365
   unsigned long pos;
   #line 378
   struct X2C_XSource_STR * anonym;
   #line 372
   if (X2C_assertSrc==0) {
      #line 373
      X2C_init_exceptions();
   }
   #line 378
   { /* with */
      struct X2C_XSource_STR * anonym = X2C_assertSrc;
      #line 379
      X2C_COPY("ASSERT(FALSE, ",15ul,anonym->message,1024u);
      #line 380
      pos = 14ul;
      #line 381
      dectostr(anonym->message, 1024ul, &pos, no);
      #line 382
      anonym->message[pos] = ')';
      #line 383
      anonym->message[pos+1ul] = 0;
      #line 384
      anonym->number = no;
   }
   #line 386
   doRaise(X2C_assertSrc);
} /* end X2C_ASSERT_F() */

#line 422

#line 417
extern void X2C_ASSERT_FC(unsigned long code, X2C_pCHAR file, unsigned long line)
{
   #line 419
   unsigned long pos;
   #line 420
   char ls[16];
   #line 420
   char cs[16];
   #line 427
   if (X2C_assertSrc==0) {
      #line 428
      X2C_init_exceptions();
   }
   #line 433
   pos = 0ul;
   #line 434
   dectostr(cs, 16ul, &pos, code);
   #line 434
   cs[pos] = 0;
   #line 434
   pos = 0ul;
   #line 435
   dectostr(ls, 16ul, &pos, line);
   #line 435
   ls[pos] = 0;
   #line 435
   pos = 0ul;
   #line 436
   append(X2C_assertSrc->message, 1023ul, &pos, "ASSERT(FALSE,");
   #line 437
   append(X2C_assertSrc->message, 1023ul, &pos, cs);
   #line 438
   append(X2C_assertSrc->message, 1023ul, &pos, ") at line ");
   #line 439
   append(X2C_assertSrc->message, 1023ul, &pos, ls);
   #line 440
   append(X2C_assertSrc->message, 1023ul, &pos, " of ");
   #line 441
   append(X2C_assertSrc->message, 1023ul, &pos, file);
   #line 442
   if (pos>=1024ul) {
      #line 442
      pos = 1023ul;
   }
   #line 443
   X2C_assertSrc->message[pos] = 0;
   #line 444
   X2C_assertSrc->number = code;
   #line 445
   doRaise(X2C_assertSrc);
} /* end X2C_ASSERT_FC() */

#line 448
