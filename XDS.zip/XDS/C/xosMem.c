/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosMem.h"
#define xosMem_C_
#include "xPOSIX.h"

#line 9 "xosMem.mod"

#line 8
extern X2C_ADDRESS X2C_AllocMem(unsigned long size)
{
   X2C_ADDRESS X2C_AllocMem_ret;
   #line 9
   X2C_PROC_INP();
   #line 10
   #line 10
   X2C_AllocMem_ret = (X2C_SET_HINFO() malloc(size));
   #line 11
   X2C_PROC_OUT();
   return X2C_AllocMem_ret;
} /* end X2C_AllocMem() */

#line 14

#line 13
extern void X2C_InitMem(void)
{
   #line 14
   X2C_PROC_INP();
   #line 15
   X2C_PROC_OUT();
} /* end X2C_InitMem() */

#line 18

#line 17
extern unsigned long X2C_GetAvailablePhysicalMemory(void)
{
   unsigned long X2C_GetAvailablePhysicalMemor0;
   #line 18
   X2C_PROC_INP();
   #line 19
   #line 19
   X2C_GetAvailablePhysicalMemor0 = X2C_max_longcard;
   #line 20
   X2C_PROC_OUT();
   return X2C_GetAvailablePhysicalMemor0;
} /* end X2C_GetAvailablePhysicalMemory() */

#line 22
