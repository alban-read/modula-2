/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcRTS.h"
#define xrcRTS_C_
#include "xmRTS.h"
#include "xPOSIX.h"
#include "M2EXCEPTION.h"
#include "X2C.h"

#line 28 "xrcRTS.mod"

#line 27
extern char X2C_IN(unsigned long i, unsigned short bits, unsigned long set)
{
   #line 29
   #line 29
   if (i<(unsigned long)bits) {
      #line 29
      return (((1L << (int)i) & set) != 0);
   }
   #line 30
   return 0;
} /* end X2C_IN() */

#line 34

#line 33
extern unsigned long X2C_SET(unsigned long a, unsigned long b, unsigned short bits)
{
   #line 35
   #line 35
   if ((a>b || a>=(unsigned long)bits) || b>=(unsigned long)bits) {
      #line 35
      X2C_TRAP(1l);
   }
   #line 36
   return ((X2C_SET32) ((2L<<(int)b) - (1L<<(int)a)));
   #line 38
   return 0ul;
} /* end X2C_SET() */

#line 43

#line 41
extern void X2C_PCOPY(X2C_pVOID * p, size_t size)
{
   #line 42
   X2C_ADDRESS a;
   #line 44
   X2C_ALLOCATE(&a, size);
   #line 45
   if (a==0) {
      #line 45
      X2C_TRAP((long)X2C_noMemoryException);
   }
   #line 46
   memcpy(a, (X2C_ADDRESS)*p, size);
   #line 47
   *p = (X2C_pVOID)a;
} /* end X2C_PCOPY() */

#line 52

#line 50
extern void X2C_PFREE(X2C_pVOID p)
{
   #line 51
   X2C_ADDRESS a;
   #line 53
   a = (X2C_ADDRESS)p;
   #line 54
   X2C_DEALLOCATE(&a);
} /* end X2C_PFREE() */

#line 59

#line 57
extern short X2C_PROT(void)
{
   #line 58
   X2C_Coroutine current;
   #line 60
   #line 60
   current = X2C_GetCurrent();
   #line 61
   return current->prot;
} /* end X2C_PROT() */

#line 64
