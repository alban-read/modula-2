/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcArythmetics.h"
#define xrcArythmetics_C_
#include "X2C.h"
#include "M2EXCEPTION.h"

#line 16 "xrcArythmetics.mod"

#line 15
extern long X2C_REM_F(long a, long b)
{
   #line 17
   #line 17
   if (b==0l) {
      #line 17
      X2C_TRAP(6l);
   }
   #line 18
   if (a>=0l) {
      #line 19
      if (b>0l) {
         #line 20
         return (a%b);
      }
      else {
         #line 22
         return (a%(-b));
      }
   }
   else if (b>0l) {
      #line 26
      return (-((-a)%b));
   }
   else {
      #line 28
      return (-(-a)%(-b));
   }
   #line 31
   return 0l;
} /* end X2C_REM_F() */

#line 35

#line 34
extern long X2C_QUO_F(long a, long b)
{
   #line 36
   #line 36
   if (b==0l) {
      #line 36
      X2C_TRAP(6l);
   }
   #line 37
   if (a>=0l) {
      #line 38
      if (b>0l) {
         #line 39
         return (a/b);
      }
      else {
         #line 41
         return (-(a/(-b)));
      }
   }
   else if (b>0l) {
      #line 45
      return (-((-a)/b));
   }
   else {
      #line 47
      return ((-a)/(-b));
   }
   #line 50
   return 0l;
} /* end X2C_QUO_F() */

#line 55

#line 53
extern long X2C_MOD_F(long a, long b)
{
   #line 54
   long c;
   #line 56
   #line 56
   if (b<=0l) {
      #line 56
      X2C_TRAP(6l);
   }
   #line 57
   c = (a % b);
   #line 58
   if (a<0l && c<0l) {
      #line 59
      c += b;
   }
   #line 61
   return c;
} /* end X2C_MOD_F() */

#line 66

#line 64
extern long X2C_DIV_F(long a, long b)
{
   #line 65
   long c;
   #line 67
   #line 67
   if (b<=0l) {
      #line 67
      X2C_TRAP(6l);
   }
   #line 68
   c = (a/b);
   #line 69
   if (a<0l && c*b>a) {
      #line 69
      --c;
   }
   #line 70
   return c;
} /* end X2C_DIV_F() */

#line 74

#line 73
extern float X2C_DIVR_F(float a, float b)
{
   #line 75
   #line 75
   if (b==0.0f) {
      #line 75
      X2C_TRAP(8l);
   }
   else {
      #line 77
      return (a/b);
   }
   #line 79
   return 0.0f;
} /* end X2C_DIVR_F() */

#line 83

#line 82
extern double X2C_DIVL_F(double a, double b)
{
   #line 84
   #line 84
   if (b==0.0) {
      #line 84
      X2C_TRAP(8l);
   }
   else {
      #line 86
      return (a/b);
   }
   #line 88
   return 0.0;
} /* end X2C_DIVL_F() */

#line 93

#line 92
extern signed char X2C_ABS_INT8(signed char x)
{
   #line 94
   #line 94
   if ((long)x>=0l) {
      #line 94
      return x;
   }
   #line 95
   if ((long)x==-128l) {
      #line 95
      X2C_TRAP(1l);
   }
   #line 96
   return -x;
} /* end X2C_ABS_INT8() */

#line 100

#line 99
extern short X2C_ABS_INT16(short x)
{
   #line 101
   #line 101
   if ((long)x>=0l) {
      #line 101
      return x;
   }
   #line 102
   if ((long)x==-32768l) {
      #line 102
      X2C_TRAP(1l);
   }
   #line 103
   return -x;
} /* end X2C_ABS_INT16() */

#line 107

#line 106
extern long X2C_ABS_INT32(long x)
{
   #line 108
   #line 108
   if (x>=0l) {
      #line 108
      return x;
   }
   #line 109
   if (x==X2C_min_longint) {
      #line 109
      X2C_TRAP(1l);
   }
   #line 110
   return -x;
} /* end X2C_ABS_INT32() */

#line 113
