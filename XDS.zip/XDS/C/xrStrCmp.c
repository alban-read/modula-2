/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrStrCmp.h"
#define xrStrCmp_C_
#include "xmRTS.h"

#line 19 "xrStrCmp.mod"

#line 16
extern int X2C_STRCMP_PROC(X2C_pVOID x, size_t alen, X2C_pVOID y, size_t blen)
{
   #line 18
   X2C_pCHAR b;
   #line 18
   X2C_pCHAR a;
   #line 18
   size_t m;
   #line 18
   size_t i;
   #line 20
   #line 20
   a = (X2C_pCHAR)x;
   #line 21
   b = (X2C_pCHAR)y;
   #line 22
   m = alen;
   #line 23
   if (m>blen) {
      #line 23
      m = blen;
   }
   #line 24
   i = 0u;
   #line 25
   while ((i<m && *a) && *a==*b) {
      #line 26
      a = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)a+(long)1ul);
      #line 27
      b = (X2C_pCHAR)(X2C_ADDRESS)((char *)(X2C_ADDRESS)b+(long)1ul);
      #line 28
      ++i;
   }
   #line 30
   if (i>=m) {
      #line 31
      if (i<alen && *a==0) {
         #line 31
         alen = i;
      }
      #line 32
      if (i<blen && *b==0) {
         #line 32
         blen = i;
      }
      #line 33
      if (alen<blen) {
         #line 33
         return -1;
      }
      #line 34
      if (alen>blen) {
         #line 34
         return 1;
      }
      #line 35
      return 0;
   }
   #line 37
   if ((unsigned char)(*a)<(unsigned char)(*b)) {
      #line 37
      return -1;
   }
   #line 38
   if ((unsigned char)(*a)>(unsigned char)(*b)) {
      #line 38
      return 1;
   }
   #line 39
   return 0;
} /* end X2C_STRCMP_PROC() */

#line 42
