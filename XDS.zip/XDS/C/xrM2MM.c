/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrM2MM.h"
#define xrM2MM_C_
#include "xmRTS.h"
#include "xrMM.h"

#line 69 "xrM2MM.mod"
#line 72
#define LINK_SZ sizeof(struct X2C_LINK_STR)

#line 72
#line 73
#define GAP_SIZE 128

#line 73
#line 78

#line 75
extern void X2C_ALLOCATE(X2C_ADDRESS * a, size_t size)
{
   #line 77
   X2C_LINK l;
   #line 78
   X2C_PROC_INP();
   #line 79
   #line 79
   *a = 0;
   #line 80
   if (size==0u) {
      #line 80
      goto label;
   }
   #line 81
   (X2C_SET_HINFO() xrMM_allocate(&l, size, 0));
   #line 82
   if (l==0) {
      #line 82
      goto label;
   }
   #line 83
   l->_0.tags |= 0x8000ul;
   #line 84
   l->_.td = x2c_td_null;
   #line 85
   *a = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sizeof(struct X2C_LINK_STR));
   #line 86
   if ((l->_0.tags&0xFFE00000ul)==0ul) {
      #line 87
      xrMM_expusedmem += (X2C_SET_HINFO() xrMM_getLargeObjBlock(l))->fsum;
   }
   else {
      #line 89
      xrMM_expusedmem += (X2C_SET_HINFO() xrMM_getHpObjSize(l));
   }
   label:;
   #line 92
   X2C_PROC_OUT();
} /* end X2C_ALLOCATE() */

#line 96

#line 94
extern void X2C_DEALLOCATE(X2C_ADDRESS * a)
{
   #line 95
   X2C_LINK l;
   #line 95
   xrMM_Block x;
   #line 95
   unsigned long sz;
   #line 96
   X2C_PROC_INP();
   #line 97
   #line 97
   if (*a==0) {
      #line 97
      goto label;
   }
   #line 98
   l = (X2C_LINK)(X2C_ADDRESS)((char *)*a-(long)sizeof(struct X2C_LINK_STR));
   #line 99
   if (l->_.td->res!=0x093678150ul) {
      #line 99
      (X2C_SET_HINFO() X2C_ASSERT_F(100ul));
   }
   #line 100
   if ((0x8000ul & l->_0.tags)) {
      #line 101
      if ((l->_0.tags&0xFFE00000ul)==0ul) {
         #line 102
         x = (X2C_SET_HINFO() xrMM_getLargeObjBlock(l));
         #line 104
         if (x->magic!=305419896ul) {
            #line 104
            (X2C_SET_HINFO() X2C_ASSERT_F(101ul));
         }
         #line 105
         sz = x->fsum;
         #line 106
         (X2C_SET_HINFO() xrMM_free_block(x));
      }
      else {
         #line 108
         sz = (X2C_SET_HINFO() xrMM_getHpObjSize(l));
         #line 109
         (X2C_SET_HINFO() xrMM_dealloc(l));
      }
      #line 111
      xrMM_expusedmem -= sz;
      #line 112
      X2C_usedmem -= sz;
      #line 113
      --X2C_objects;
   }
   else {
      #line 115
      l->_0.tags &= ~0x4000ul;
   }
   #line 117
   *a = 0;
   label:;
   #line 118
   X2C_PROC_OUT();
} /* end X2C_DEALLOCATE() */

#line 125

#line 120
extern void X2C_DYNALLOCATE(X2C_ADDRESS * a, size_t size, size_t lens[], size_t dims)
{
   #line 124
   xrMM_Dynarr desc;
   #line 125
   X2C_PROC_INP();
   #line 126
   *a = 0;
   #line 128
   (X2C_SET_HINFO() X2C_ALLOCATE((X2C_ADDRESS *) &desc, (X2C_SET_HINFO() xrMM_DynarrDescSize(dims))));
   #line 129
   if (desc) {
      #line 130
      (X2C_SET_HINFO() X2C_InitDesc(desc, &size, lens, dims));
      #line 131
      (X2C_SET_HINFO() X2C_ALLOCATE(&desc->a, size));
      #line 132
      if (desc->a==0) {
         #line 132
         (X2C_SET_HINFO() X2C_DEALLOCATE((X2C_ADDRESS *) &desc));
      }
      else {
         #line 132
         *a = (X2C_ADDRESS)desc;
      }
   }
   #line 134
   X2C_PROC_OUT();
} /* end X2C_DYNALLOCATE() */

#line 138

#line 136
extern void X2C_DYNDEALLOCATE(X2C_ADDRESS * a)
{
   #line 137
   xrMM_Dynarr d;
   #line 138
   X2C_PROC_INP();
   #line 139
   if (*a) {
      #line 140
      d = (xrMM_Dynarr)*a;
      #line 141
      (X2C_SET_HINFO() X2C_DEALLOCATE(&d->a));
      #line 142
      (X2C_SET_HINFO() X2C_DEALLOCATE(a));
   }
   #line 144
   X2C_PROC_OUT();
} /* end X2C_DYNDEALLOCATE() */

#line 146
static X2C_ADDRESS get_addr(size_t, X2C_ADDRESS *, size_t, size_t [], size_t);

#line 151
typedef X2C_ADDRESS * PTR_TO_ADDR;

#line 155

#line 146
static X2C_ADDRESS get_addr(size_t dim, X2C_ADDRESS * free_addr, size_t size, size_t lens[], size_t dims)
{
   #line 152
   unsigned long i;
   #line 153
   X2C_ADDRESS addr;
   #line 154
   PTR_TO_ADDR tmp_ptr;
   unsigned long tmp;
   X2C_ADDRESS get_addr_ret;
   #line 155
   X2C_PROC_INP();
   #line 156
   #line 156
   addr = *free_addr;
   #line 157
   if (dim+1u==dims) {
      #line 158
      *free_addr = (X2C_ADDRESS)((char *)*free_addr+(long)(size*lens[dim]));
   }
   else {
      #line 160
      *free_addr = (X2C_ADDRESS)((char *)*free_addr+(long)(lens[dim]*4u));
      #line 161
      tmp = lens[dim]-1u;
      i = 0ul;
      if (i<=tmp) for (;; i++) {
         #line 162
         tmp_ptr = (PTR_TO_ADDR)(X2C_ADDRESS)((char *)addr+(long)(i*4ul));
         #line 163
         *tmp_ptr = (X2C_SET_HINFO() get_addr(dim+1u, free_addr, size, lens, dims));
         if (i==tmp) break;
      } /* end for */
   }
   #line 166
   get_addr_ret = addr;
   #line 167
   X2C_PROC_OUT();
   return get_addr_ret;
} /* end get_addr() */

#line 177

#line 170
extern void X2C_DYNCALLOCATE(X2C_ADDRESS * a, size_t size, size_t lens[], size_t dims)
{
   #line 174
   unsigned long i;
   #line 175
   size_t full_size;
   #line 176
   X2C_ADDRESS addr;
   #line 176
   X2C_ADDRESS free_addr;
   unsigned long tmp;
   #line 177
   X2C_PROC_INP();
   #line 178
   full_size = size*lens[dims-1u];
   #line 179
   tmp = dims;
   i = 2ul;
   if (i<=tmp) for (;; i++) {
      #line 179
      full_size = (full_size+4u)*lens[dims-i];
      if (i==tmp) break;
   } /* end for */
   #line 180
   (X2C_SET_HINFO() X2C_ALLOCATE(a, full_size));
   #line 181
   if (*a) {
      #line 182
      free_addr = *a;
      #line 183
      addr = (X2C_SET_HINFO() get_addr(0u, &free_addr, size, lens, dims));
   }
   #line 186
   X2C_PROC_OUT();
} /* end X2C_DYNCALLOCATE() */

#line 189

#line 188
extern void X2C_DYNCDEALLOCATE(X2C_ADDRESS * a)
{
   #line 189
   X2C_PROC_INP();
   #line 190
   if (*a) {
      #line 190
      (X2C_SET_HINFO() X2C_DEALLOCATE(a));
   }
   #line 191
   X2C_PROC_OUT();
} /* end X2C_DYNCDEALLOCATE() */

#line 194
