/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosFmtNL.h"
#define xosFmtNL_C_
#include "xPOSIX.h"

#line 9 "xosFmtNL.mod"

#line 8
extern void X2C_StdOutN(void)
{
   #line 9
   X2C_PROC_INP();
   #line 10
   printf("\n");
   #line 11
   X2C_PROC_OUT();
} /* end X2C_StdOutN() */

#line 13
