/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcChecks.h"
#define xrcChecks_C_
#include "xmRTS.h"
#include "M2EXCEPTION.h"

#line 20 "xrcChecks.mod"
#line 21
#line 22
#line 23
#line 26

#line 25
extern unsigned short X2C_CHKINX_F(unsigned long i, unsigned short length)
{
   #line 27
   #line 27
   if (i>=(unsigned long)length) {
      #line 27
      X2C_TRAP_F(0l);
   }
   #line 28
   return (unsigned short)i;
} /* end X2C_CHKINX_F() */

#line 32

#line 31
extern unsigned long X2C_CHKINXL_F(unsigned long i, unsigned long length)
{
   #line 33
   #line 33
   if (i>=length) {
      #line 33
      X2C_TRAP_F(0l);
   }
   #line 34
   return i;
} /* end X2C_CHKINXL_F() */

#line 38

#line 37
extern short X2C_CHKS_F(short i)
{
   #line 39
   #line 39
   if ((long)i<0l) {
      #line 39
      X2C_TRAP_F(1l);
   }
   #line 40
   return i;
} /* end X2C_CHKS_F() */

#line 44

#line 43
extern long X2C_CHKSL_F(long i)
{
   #line 45
   #line 45
   if (i<0l) {
      #line 45
      X2C_TRAP_F(1l);
   }
   #line 46
   return i;
} /* end X2C_CHKSL_F() */

#line 50

#line 49
extern short X2C_CHK_F(short a, short min0, short max0)
{
   #line 51
   #line 51
   if ((long)a<(long)min0 || (long)a>(long)max0) {
      #line 51
      X2C_TRAP_F(1l);
   }
   #line 52
   return a;
} /* end X2C_CHK_F() */

#line 56

#line 55
extern long X2C_CHKL_F(long a, long min0, long max0)
{
   #line 57
   #line 57
   if (a<min0 || a>max0) {
      #line 57
      X2C_TRAP_F(1l);
   }
   #line 58
   return a;
} /* end X2C_CHKL_F() */

#line 62

#line 61
extern unsigned short X2C_CHKU_F(unsigned short a, unsigned short min0, unsigned short max0)
{
   #line 63
   #line 63
   if ((unsigned long)a<(unsigned long)min0 || (unsigned long)a>(unsigned long)max0) {
      #line 63
      X2C_TRAP_F(1l);
   }
   #line 64
   return a;
} /* end X2C_CHKU_F() */

#line 68

#line 67
extern unsigned long X2C_CHKUL_F(unsigned long a, unsigned long min0, unsigned long max0)
{
   #line 69
   #line 69
   if (a<min0 || a>max0) {
      #line 69
      X2C_TRAP_F(1l);
   }
   #line 70
   return a;
} /* end X2C_CHKUL_F() */

#line 74

#line 73
extern X2C_pVOID X2C_CHKNIL_F(X2C_pVOID p)
{
   #line 75
   #line 75
   if (p==0) {
      #line 75
      X2C_TRAP_F(3l);
   }
   #line 76
   return p;
} /* end X2C_CHKNIL_F() */

#line 80

#line 79
extern X2C_PROC X2C_CHKPROC_F(X2C_PROC p)
{
   #line 81
   #line 81
   if (p==0) {
      #line 81
      X2C_TRAP_F(3l);
   }
   #line 82
   return p;
} /* end X2C_CHKPROC_F() */

#line 85
