/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrSETs.h"
#define xrSETs_C_

#line 17 "xrSETs.mod"

#line 16
extern long X2C_ASH(long a, long b)
{
   #line 18
   #line 18
   return (b >= 0) ? (a << b) : (a >> (-b));
   #line 19
   return 0l;
} /* end X2C_ASH() */

#line 24

#line 22
extern unsigned long X2C_ROT(unsigned long a, short length, long n)
{
   #line 23
   unsigned long m;
   #line 25
   #line 25
   m = 0ul;
   #line 26
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   #line 27
   if (n>0l) {
      #line 28
      n=n % length;
      #line 29
      return ((a << n) | (a >> (length - n))) & m;
   }
   else {
      #line 31
      n= -n % length;
      #line 32
      return ((a >> n) | (a << (length - n))) & m;
   }
   #line 34
   return 0ul;
} /* end X2C_ROT() */

#line 39

#line 37
extern unsigned long X2C_LSH(unsigned long a, short length, long n)
{
   #line 38
   unsigned long m;
   #line 40
   #line 40
   m = 0ul;
   #line 41
   m = (length==32) ? 0xFFFFFFFFl : (1l << length)-1;
   #line 42
   if (n>0l) {
      #line 43
      if (n>=(long)length) {
         #line 43
         return 0ul;
      }
      #line 44
      return (a << n) & m;
   }
   else {
      #line 46
      if (n<=(long) -length) {
         #line 46
         return 0ul;
      }
      #line 47
      return (a >> -n) & m;
   }
   #line 49
   return 0ul;
} /* end X2C_LSH() */

#line 52
