/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrO2MM.h"
#define xrO2MM_C_
#include "xmRTS.h"
#include "xrMM.h"
#include "TERMINATION.h"
#include "xosMalloc.h"
#include "xosMem.h"
#include "xrBlockManager.h"
#include "X2C.h"
#include "Printf.h"
#include "xrtsOS.h"
#include "COROUTINES.h"
#include "TimeConv.h"

#line 42 "xrO2MM.def"
unsigned long MutatorPeriod;
#line 43
unsigned long GCPeriod;
#line 45
#line 94 "xrO2MM.mod"
#line 95
#line 96
#line 97
typedef X2C_ADDRESS * ADDR_REF;

#line 97
#line 98
#line 99
#line 101
#line 102
#line 103
#line 104
#line 107
struct DestructDesc;

#line 105
typedef struct DestructDesc * Destruct;

#line 107

struct DestructDesc {
   X2C_DPROC proc;
   X2C_ADDRESS adr;
   Destruct next;
};

#line 114
typedef X2C_ADDRESS * OFFS;

#line 117
#define LINK_SZ sizeof(struct X2C_LINK_STR)

#line 117
#line 118
#define GAP_SIZE 128

#line 118
#line 121
#define AdrLss X2C_adr_lss

#line 121
#line 122
#define AdrGtr X2C_adr_gtr

#line 122
#line 141
static X2C_TD dynarrs[8];

#line 142
static Destruct destruct;

#line 144
static X2C_ADDRESS TAG_END;

#line 145
static X2C_ADDRESS TAG_ARR;

#line 145
#line 146
static X2C_ADDRESS TAG_REC;

#line 146
#line 148
static unsigned long ADR_ALIGMENT;

#line 148
#line 151
static COROUTINES_COROUTINE CollectPrs;

#line 151
#line 161
static X2C_ADDRESS dyn_offs[2];

#line 161
#line 162
static char prs_wsp[21072];

#line 162
#line 171

#line 170
static void InsufficientMemory(void)
{
   #line 171
   X2C_PROC_INP();
   #line 173
   (X2C_SET_HINFO() X2C_TRAP((long)X2C_noMemoryException));
   #line 174
   X2C_PROC_OUT();
} /* end InsufficientMemory() */

#line 182
static unsigned long SZ_MASK = 0x3FF8ul;

#line 182
#line 186

#line 185
static unsigned long getHpObjSize(X2C_LINK obj)
{
   unsigned long getHpObjSize_ret;
   #line 186
   X2C_PROC_INP();
   #line 187
   #line 187
   getHpObjSize_ret = (unsigned long)((unsigned long)obj->_0.size&0x3FF8ul);
   #line 188
   X2C_PROC_OUT();
   return getHpObjSize_ret;
} /* end getHpObjSize() */

#line 193

#line 192
static void stampObjAsFree(X2C_LINK obj, unsigned long size)
{
   #line 193
   X2C_PROC_INP();
   #line 196
   obj->_0.size = (unsigned long)(obj->_0.tags&0xFFE00000ul|0x20000ul)+size;
   #line 197
   X2C_PROC_OUT();
} /* end stampObjAsFree() */

#line 341

#line 338
extern void X2C_NEW(X2C_TD type, X2C_ADDRESS * a, size_t size, char sys)
{
   #line 340
   X2C_LINK l;
   #line 341
   X2C_PROC_INP();
   #line 342
   #line 342
   if (size==0u) {
      #line 342
      *a = 0;
      #line 342
      goto label;
   }
   #line 343
   if (size%type->size) X2C_ASSERT(100ul);
   #line 344
   (X2C_SET_HINFO() xrMM_allocate(&l, size, type!=x2c_td_null));
   #line 345
   if (l==0) {
      #line 345
      (X2C_SET_HINFO() InsufficientMemory());
   }
   #line 351
   l->_.td = type;
   #line 352
   *a = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sizeof(struct X2C_LINK_STR));
   #line 354
   l->_0.tags &= ~0x8000ul;
   #line 355
   if (sys) {
      #line 355
      l->_0.tags |= 0x4000ul;
   }
   label:;
   #line 363
   X2C_PROC_OUT();
} /* end X2C_NEW() */

#line 375

#line 366
extern void X2C_NEW_OPEN(X2C_TD type, X2C_ADDRESS * a, size_t size, size_t lens[], size_t dims, char sys)
{
   #line 374
   X2C_TD dtype;
   #line 374
   xrMM_Dynarr desc;
   #line 375
   X2C_PROC_INP();
   #line 380
   *a = 0;
   #line 381
   if (dims>8u) X2C_ASSERT(101ul);
   #line 382
   dtype = dynarrs[dims-1u];
   #line 388
   (X2C_SET_HINFO() X2C_NEW(dtype, (X2C_ADDRESS *) &desc, dtype->size, sys));
   #line 395
   (X2C_SET_HINFO() X2C_InitDesc(desc, &size, lens, dims));
   #line 401
   (X2C_SET_HINFO() X2C_NEW(type, &desc->a, size, sys));
   #line 408
   *a = (X2C_ADDRESS)desc;
   #line 413
   X2C_PROC_OUT();
} /* end X2C_NEW_OPEN() */

#line 422

#line 416
extern void X2C_DISPOSE(X2C_ADDRESS * a)
{
   #line 418
   X2C_LINK l;
   #line 419
   unsigned long i;
   #line 420
   xrMM_Dynarr desc;
   #line 422
   X2C_PROC_INP();
   #line 423
   #line 423
   if (*a==0) {
      #line 423
      goto label;
   }
   #line 424
   l = (X2C_LINK)(X2C_ADDRESS)((char *)*a-(long)sizeof(struct X2C_LINK_STR));
   #line 425
   if (l->_.td->res!=0x093678150ul) {
      #line 425
      (X2C_SET_HINFO() X2C_ASSERT_F(100ul));
   }
   #line 426
   i = 0ul;
   #line 427
   while (i<8ul && l->_.td!=dynarrs[i]) {
      #line 427
      ++i;
   }
   #line 453
   l->_0.tags &= ~0x4000ul;
   #line 454
   if (i<8ul) {
      #line 455
      desc = (xrMM_Dynarr)*a;
      #line 456
      l = (X2C_LINK)(X2C_ADDRESS)((char *)desc->a-(long)sizeof(struct X2C_LINK_STR));
      #line 457
      if (l->_.td->res!=0x093678150ul) {
         #line 457
         (X2C_SET_HINFO() X2C_ASSERT_F(101ul));
      }
      #line 458
      l->_0.tags &= ~0x4000ul;
   }
   #line 461
   l = 0;
   #line 462
   *a = 0;
   label:;
   #line 463
   X2C_PROC_OUT();
} /* end X2C_DISPOSE() */

#line 467

#line 465
extern void X2C_DESTRUCTOR(X2C_ADDRESS a, X2C_DPROC p)
{
   #line 466
   Destruct d;
   #line 466
   X2C_LINK ln;
   #line 467
   X2C_PROC_INP();
   #line 468
   if (a==0) {
      #line 468
      (X2C_SET_HINFO() X2C_ASSERT_F(102ul));
   }
   #line 469
   if (p==0) {
      #line 469
      (X2C_SET_HINFO() X2C_ASSERT_F(103ul));
   }
   #line 470
   ln = (X2C_LINK)(X2C_ADDRESS)((char *)a-(long)sizeof(struct X2C_LINK_STR));
   #line 474
   if ((ln->_0.tags&0xC000ul)!=0ul) {
      #line 474
      (X2C_SET_HINFO() X2C_ASSERT_F(104ul));
   }
   #line 476
   if (ln->_.td->res!=0x093678150ul) {
      #line 476
      (X2C_SET_HINFO() X2C_ASSERT_F(105ul));
   }
   #line 477
   (X2C_SET_HINFO() X2C_NEW(x2c_td_null, (X2C_ADDRESS *) &d, sizeof(Destruct)+sizeof(struct X2C_LINK_STR), 0));
   #line 478
   d->adr = a;
   #line 479
   d->proc = p;
   #line 481
   d->next = destruct;
   #line 482
   destruct = d;
   #line 484
   X2C_PROC_OUT();
} /* end X2C_DESTRUCTOR() */

#line 487

#line 486
static void FinalOne(Destruct d)
{
   struct X2C_XHandler_STR anonym;
   #line 487
   X2C_PROC_INP();
   #line 489
   if (X2C_XTRY(&anonym)) {
      #line 488
      (X2C_SET_HINFO() d->proc(d->adr));
      X2C_XOFF();
   }
   else {
      #line 490
      #line 490
   }
   #line 491
   X2C_XREMOVE();
   #line 491
   X2C_PROC_OUT();
} /* end FinalOne() */

#line 493
static void FinalAll(void);

#line 495

#line 493
static void FinalAll(void)
{
   #line 494
   Destruct n;
   #line 495
   X2C_PROC_INP();
   #line 496
   while (destruct) {
      #line 497
      n = destruct->next;
      #line 498
      (X2C_SET_HINFO() FinalOne(destruct));
      #line 499
      destruct = n;
   }
   #line 501
   X2C_PROC_OUT();
} /* end FinalAll() */

#line 507
static X2C_TD marked;

#line 507
#line 507
static X2C_TD tail;

#line 507
#line 513

#line 510
static unsigned long getObjectSize(X2C_LINK l)
{
   #line 511
   unsigned long sz;
   #line 512
   xrMM_Block b;
   unsigned long getObjectSize_ret;
   #line 513
   X2C_PROC_INP();
   #line 514
   #line 514
   sz = (X2C_SET_HINFO() getHpObjSize(l));
   #line 515
   if (sz==0ul) {
      #line 516
      b = (X2C_SET_HINFO() xrMM_getLargeObjBlock(l));
      #line 517
      if ((unsigned long)b->root!=21ul) X2C_ASSERT(0);
      #line 518
      getObjectSize_ret = b->size;
   }
   else {
      #line 520
      getObjectSize_ret = sz;
   }
   #line 522
   X2C_PROC_OUT();
   return getObjectSize_ret;
} /* end getObjectSize() */

#line 528
#define Kb 1024

#line 528
#line 531
static char countingClosureInProgress;

#line 531
#line 532
static unsigned long anchorWeight;

#line 532
#line 533
static unsigned long totalWeightOfSmallAnchors;

#line 533
#line 534
static char printBuffer[1024];

#line 534
#line 535
static char hasModuleAnchors;

#line 535
#line 536
static char hasDestructorAnchors;

#line 536
#line 537
static char hasStackAnchors;

#line 537
#line 540
typedef char * pSTR;

#line 540
#line 547

#line 546
static void printAnchorTraceCaption(void)
{
   X2C_SEQ tmp[1];
   #line 547
   X2C_PROC_INP();
   #line 548
   (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, "\\n*********************** GC ANCHORS TRACE ***********************\\n", 69ul, 0, 0ul));
   #line 550
   (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   #line 552
   (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- EXPLICITLY ALLOCATED\\n", 34ul, (tmp[0].val = (xrMM_expusedmem/1024ul), (char *)tmp), sizeof(X2C_SEQ)));
   #line 553
   (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   #line 554
   X2C_PROC_OUT();
} /* end printAnchorTraceCaption() */

#line 1348
static void Closure(void);

#line 560

#line 557
static void printModuleAnchorWeight(char anchorType[], unsigned long anchorType_len, X2C_ADDRESS adr, X2C_pCHAR moduleName)
{
   X2C_SEQ tmp[6];
   #line 560
   X2C_PROC_INP();
   #line 561
   (X2C_SET_HINFO() Closure());
   #line 562
   if (anchorWeight>=xrMM_anchorWeightThreshold) {
      #line 563
      if (!hasModuleAnchors) {
         #line 564
         hasModuleAnchors = 1;
         #line 565
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, "\\n\\n", 5ul, 0, 0ul));
         #line 566
         (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
      }
      #line 569
      (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- %s %s <A:%x>\\n", 26ul, (tmp[0].val = (anchorWeight/1024ul), tmp[1].adr = (pSTR)moduleName, tmp[2].adr = anchorType, tmp[3].val = 0, tmp[4].val = anchorType_len-1, tmp[5].adr = adr,
                (char *)tmp), 6ul*sizeof(X2C_SEQ)));
      #line 572
      (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   }
   else {
      #line 574
      totalWeightOfSmallAnchors += anchorWeight;
   }
   #line 576
   X2C_PROC_OUT();
} /* end printModuleAnchorWeight() */

#line 582

#line 579
static void printDestructorAnchorWeight(X2C_ADDRESS obj)
{
   #line 581
   X2C_TD type;
   X2C_SEQ tmp[4];
   #line 582
   X2C_PROC_INP();
   #line 583
   (X2C_SET_HINFO() Closure());
   #line 584
   if (anchorWeight>=xrMM_anchorWeightThreshold) {
      #line 585
      if (!hasDestructorAnchors) {
         #line 586
         hasDestructorAnchors = 1;
         #line 587
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, "\\n\\n", 5ul, 0, 0ul));
         #line 588
         (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
      }
      #line 591
      type = ((X2C_LINK)(X2C_ADDRESS)((char *)obj-(long)sizeof(struct X2C_LINK_STR)))->_.td;
      #line 592
      if (type->module && type->module->name) {
         #line 593
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- DESTRUCTOR OF OBJ %xH (type %s.%s)\\n", 48ul, (tmp[0].val = (anchorWeight/1024ul), tmp[1].adr = obj, tmp[2].adr = (pSTR)type->module->name, tmp[3].adr = (pSTR)type->name,
                (char *)tmp), 4ul*sizeof(X2C_SEQ)));
      }
      else {
         #line 596
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- DESTRUCTOR OF OBJ %xH (type %s)\\n", 45ul, (tmp[0].val = (anchorWeight/1024ul), tmp[1].adr = obj, tmp[2].adr = (pSTR)type->name, (char *)tmp), 3ul*sizeof(X2C_SEQ)));
      }
      #line 600
      (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   }
   else {
      #line 602
      totalWeightOfSmallAnchors += anchorWeight;
   }
   #line 604
   X2C_PROC_OUT();
} /* end printDestructorAnchorWeight() */

#line 610

#line 607
static void printStackAnchorWeight(X2C_ADDRESS obj)
{
   #line 609
   X2C_TD type;
   X2C_SEQ tmp[4];
   #line 610
   X2C_PROC_INP();
   #line 611
   (X2C_SET_HINFO() Closure());
   #line 612
   if (anchorWeight>=xrMM_anchorWeightThreshold) {
      #line 613
      if (!hasStackAnchors) {
         #line 614
         hasStackAnchors = 1;
         #line 615
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, "\\n\\n", 5ul, 0, 0ul));
         #line 616
         (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
      }
      #line 619
      type = ((X2C_LINK)(X2C_ADDRESS)((char *)obj-(long)sizeof(struct X2C_LINK_STR)))->_.td;
      #line 620
      if (type->module && type->module->name) {
         #line 621
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- STACK REF TO %xH (type %s.%s)\\n", 43ul, (tmp[0].val = (anchorWeight/1024ul), tmp[1].adr = obj, tmp[2].adr = (pSTR)type->module->name, tmp[3].adr = (pSTR)type->name, (char *)tmp),
                4ul*sizeof(X2C_SEQ)));
      }
      else {
         #line 624
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- STACK REF TO %xH (type %s)\\n", 40ul, (tmp[0].val = (anchorWeight/1024ul), tmp[1].adr = obj, tmp[2].adr = (pSTR)type->name, (char *)tmp), 3ul*sizeof(X2C_SEQ)));
      }
      #line 628
      (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   }
   else {
      #line 630
      totalWeightOfSmallAnchors += anchorWeight;
   }
   #line 632
   X2C_PROC_OUT();
} /* end printStackAnchorWeight() */

#line 636

#line 635
static void printSmallAnchorsWeight(void)
{
   X2C_SEQ tmp[2];
   #line 636
   X2C_PROC_INP();
   #line 637
   if (totalWeightOfSmallAnchors>0ul) {
      #line 638
      (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, "\\n %8d Kb <- Total size of small (< %d bytes) anchors\\n", 56ul, (tmp[0].val = (totalWeightOfSmallAnchors/1024ul), tmp[1].val = xrMM_anchorWeightThreshold, (char *)tmp), 2ul*sizeof(X2C_SEQ)));
      #line 641
      (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   }
   #line 643
   X2C_PROC_OUT();
} /* end printSmallAnchorsWeight() */

#line 856
static void AppendObject(ADDR_REF);

#line 651

#line 646
static void printLargeObjects(void)
{
   #line 648
   xrMM_Block fb;
   #line 648
   xrMM_Block b;
   #line 649
   X2C_LINK l;
   #line 650
   X2C_ADDRESS o;
   X2C_SEQ tmp[5];
   #line 651
   X2C_PROC_INP();
   #line 652
   countingClosureInProgress = 1;
   #line 654
   (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, "\\nHANGING LARGE OBJECTS:\\n", 27ul, 0, 0ul));
   #line 655
   (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   #line 657
   fb = xrMM_f_blocks[21u];
   #line 658
   b = fb->next;
   #line 659
   while (b!=fb) {
      #line 660
      l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(b));
      #line 661
      o = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sizeof(struct X2C_LINK_STR));
      #line 663
      anchorWeight = 0ul;
      #line 664
      (X2C_SET_HINFO() AppendObject(&o));
      #line 665
      (X2C_SET_HINFO() Closure());
      #line 667
      if (l->_.td->module && l->_.td->module->name) {
         #line 670
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- LARGE OBJ %xH (type:%s.%s, size:%d)\\n", 49ul, (tmp[0].val = (anchorWeight/1024ul), tmp[1].adr = o, tmp[2].adr = (pSTR)l->_.td->module->name, tmp[3].adr = (pSTR)l->_.td->name,
                tmp[4].val = b->size, (char *)tmp), 5ul*sizeof(X2C_SEQ)));
      }
      else {
         #line 673
         (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb <- LARGE OBJ %xH (type:%s, size:%d)\\n", 46ul, (tmp[0].val = (anchorWeight/1024ul), tmp[1].adr = o, tmp[2].adr = (pSTR)l->_.td->name, tmp[3].val = b->size, (char *)tmp),
                4ul*sizeof(X2C_SEQ)));
      }
      #line 677
      (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
      #line 679
      b = b->next;
   }
   #line 682
   countingClosureInProgress = 0;
   #line 683
   X2C_PROC_OUT();
} /* end printLargeObjects() */

#line 689
typedef void ( *HeapIterator_P)(X2C_LINK);

#line 689
#line 694
static unsigned long xrO2MM_liveObjTags = 0x1C000ul;

#line 699

#line 696
static void iterateBlocks(HeapIterator_P callback, xrMM_Block blocks[], unsigned long blocks_len)
{
   #line 697
   unsigned long i;
   #line 697
   xrMM_Block x;
   #line 697
   xrMM_Block root;
   #line 698
   X2C_LINK l;
   #line 698
   unsigned long size;
   #line 698
   unsigned long sz;
   #line 699
   X2C_PROC_INP();
   #line 700
   root = blocks[0ul];
   #line 700
   x = root->next;
   #line 701
   while (x!=root) {
      #line 702
      l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
      #line 703
      sz = 0ul;
      #line 704
      for (;;) {
         #line 705
         if ((0x1C000ul&l->_0.tags)!=0ul) {
            #line 706
            if (l->_.td==0) X2C_ASSERT(0);
            #line 707
            (X2C_SET_HINFO() callback(l));
         }
         #line 709
         size = (X2C_SET_HINFO() getHpObjSize(l));
         #line 710
         if (size==0ul) X2C_ASSERT(0);
         #line 712
         l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)size);
         #line 713
         sz += size;
         #line 714
         if (sz>=16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) {
            #line 714
            break;
         }
      }
      #line 716
      x = x->next;
   }
   #line 719
   for (i = 1ul; i<=20ul; i++) {
      #line 720
      root = blocks[i];
      #line 720
      x = root->next;
      #line 721
      size = i*sizeof(struct X2C_LINK_STR);
      #line 722
      while (x!=root) {
         #line 723
         l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
         #line 724
         while ((X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)l, x->mem))) {
            #line 725
            if ((0x1C000ul&l->_0.tags)!=0ul) {
               #line 726
               (X2C_SET_HINFO() callback(l));
            }
            #line 728
            l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)size);
         }
         #line 730
         x = x->next;
      }
   } /* end for */
   #line 734
   root = blocks[21ul];
   #line 734
   x = root->next;
   #line 735
   while (x!=root) {
      #line 736
      l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
      #line 737
      if ((0x1C000ul&l->_0.tags)!=0ul) {
         #line 738
         (X2C_SET_HINFO() callback(l));
      }
      #line 740
      x = x->next;
   }
   #line 742
   X2C_PROC_OUT();
} /* end iterateBlocks() */

#line 744

#line 691
static void iterateHeap(HeapIterator_P callback)
{
   #line 744
   X2C_PROC_INP();
   #line 745
   (X2C_SET_HINFO() iterateBlocks(callback, xrMM_f_blocks, 22ul));
   #line 746
   (X2C_SET_HINFO() iterateBlocks(callback, xrMM_b_blocks, 22ul));
   #line 747
   X2C_PROC_OUT();
} /* end iterateHeap() */

#line 752
#define HeapProfile_MAX 16384

#line 752
#line 755
struct HeapProfile_Rec;

#line 755

struct HeapProfile_Rec {
   X2C_TD type;
   unsigned long size;
};

#line 761
static struct HeapProfile_Rec HeapProfile_types[16384];

#line 761
#line 762
static long HeapProfile_NTypes;

#line 762
#line 763
static long HeapProfile_lastType;

#line 763
#line 767

#line 766
static void HeapProfile_reset(void)
{
   #line 767
   X2C_PROC_INP();
   #line 768
   HeapProfile_NTypes = 0l;
   #line 769
   HeapProfile_lastType = 0l;
   #line 771
   HeapProfile_types[HeapProfile_lastType].type = 0;
   #line 772
   HeapProfile_types[HeapProfile_lastType].size = 0ul;
   #line 773
   X2C_PROC_OUT();
} /* end HeapProfile_reset() */

#line 776
static void HeapProfile_recordObject(X2C_LINK);

#line 782

#line 776
static void HeapProfile_recordObject(X2C_LINK l)
{
   #line 778
   X2C_TD type;
   #line 779
   size_t size;
   #line 780
   long i;
   #line 782
   X2C_PROC_INP();
   #line 783
   type = l->_.td;
   #line 784
   size = (X2C_SET_HINFO() getObjectSize(l));
   #line 786
   if (HeapProfile_types[HeapProfile_lastType].type==type) {
      #line 787
      i = HeapProfile_lastType;
   }
   else {
      #line 789
      i = 0l;
      #line 790
      for (;;) {
         #line 791
         if (i==HeapProfile_NTypes) {
            #line 792
            if (i>=16384l) X2C_ASSERT(919192ul);
            #line 793
            HeapProfile_types[i].type = type;
            #line 794
            HeapProfile_types[i].size = 0ul;
            #line 795
            ++HeapProfile_NTypes;
            #line 796
            break;
         }
         #line 799
         if (HeapProfile_types[i].type==type) {
            #line 800
            break;
         }
         #line 803
         ++i;
      }
   }
   #line 807
   HeapProfile_types[i].size += size;
   #line 808
   HeapProfile_lastType = i;
   #line 809
   X2C_PROC_OUT();
} /* end HeapProfile_recordObject() */

#line 816

#line 812
static void HeapProfile_print(void)
{
   #line 814
   long i;
   #line 815
   unsigned long otherSize;
   long tmp;
   X2C_SEQ tmp0[3];
   #line 816
   X2C_PROC_INP();
   #line 817
   (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, "\\n\\nHEAP TRACE:\\n", 18ul, 0, 0ul));
   #line 818
   (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   #line 820
   otherSize = 0ul;
   #line 822
   tmp = HeapProfile_NTypes-1l;
   i = 0l;
   if (i<=tmp) for (;; i++) {
      #line 823
      if (HeapProfile_types[i].size>=xrMM_heapTracingThreshold) {
         #line 824
         if (HeapProfile_types[i].type->module && HeapProfile_types[i].type->module->name) {
            #line 827
            (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb - %s.%s\\n", 18ul, (tmp0[0].val = (HeapProfile_types[i].size/1024ul), tmp0[1].adr = (pSTR)HeapProfile_types[i].type->module->name,
                tmp0[2].adr = (pSTR)HeapProfile_types[i].type->name, (char *)tmp0), 3ul*sizeof(X2C_SEQ)));
         }
         else {
            #line 829
            (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb - %s\\n", 15ul, (tmp0[0].val = (HeapProfile_types[i].size/1024ul), tmp0[1].adr = (pSTR)HeapProfile_types[i].type->name, (char *)tmp0), 2ul*sizeof(X2C_SEQ)));
         }
         #line 831
         (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
      }
      else {
         #line 833
         otherSize += HeapProfile_types[i].size;
      }
      if (i==tmp) break;
   } /* end for */
   #line 837
   if (otherSize>0ul) {
      #line 838
      (X2C_SET_HINFO() Printf_sprintf(printBuffer, 1024ul, " %8d Kb - OTHER (< %d bytes)\\n", 31ul, (tmp0[0].val = (otherSize/1024ul), tmp0[1].val = xrMM_heapTracingThreshold, (char *)tmp0), 2ul*sizeof(X2C_SEQ)));
      #line 839
      (X2C_SET_HINFO() X2C_StdOutS(printBuffer, 0ul));
   }
   #line 841
   X2C_PROC_OUT();
} /* end HeapProfile_print() */

#line 845

#line 844
static void printHeapTrace(void)
{
   #line 845
   X2C_PROC_INP();
   #line 846
   (X2C_SET_HINFO() HeapProfile_reset());
   #line 848
   (X2C_SET_HINFO() iterateHeap(HeapProfile_recordObject));
   #line 850
   (X2C_SET_HINFO() HeapProfile_print());
   #line 851
   X2C_PROC_OUT();
} /* end printHeapTrace() */

#line 859

#line 856
static void AppendObject(ADDR_REF ref)
{
   #line 858
   X2C_LINK l;
   #line 858
   X2C_TD t;
   #line 858
   X2C_ADDRESS a;
   #line 859
   X2C_PROC_INP();
   #line 860
   #line 860
   if (ref==0) X2C_ASSERT(106ul);
   #line 861
   a = *ref;
   #line 862
   if (a==0) {
      #line 862
      goto label;
   }
   #line 863
   if (!(X2C_SET_HINFO() X2C_adr_gtr(a, xrMM_blk_min))) X2C_ASSERT(107ul);
   #line 864
   if (!(X2C_SET_HINFO() X2C_adr_lss(a, xrMM_blk_max))) X2C_ASSERT(108ul);
   #line 865
   l = (X2C_LINK)(X2C_ADDRESS)((char *)a-(long)sizeof(struct X2C_LINK_STR));
   #line 866
   if ((0x40000ul & l->_0.tags)) {
      #line 867
      l = l->_.next;
      #line 868
      a = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sizeof(struct X2C_LINK_STR));
      #line 869
      *ref = a;
   }
   #line 873
   if ((l->_0.tags&0x18000ul)==0ul) {
      #line 874
      l->_0.tags |= 0x10000ul;
      #line 876
      if (countingClosureInProgress) {
         #line 877
         anchorWeight += (X2C_SET_HINFO() getObjectSize(l));
      }
      #line 880
      t = l->_.td;
      #line 881
      if (t->res!=0x093678150ul) {
         #line 881
         (X2C_SET_HINFO() X2C_ASSERT_F(109ul));
      }
      #line 882
      if (t!=x2c_td_null) {
         #line 883
         if (t->link) {
            #line 884
            t->tail->_.td = (X2C_TD)l;
         }
         else {
            #line 886
            t->link = l;
            #line 887
            if (marked==0) {
               #line 887
               marked = t;
            }
            else {
               #line 887
               tail->succ = t;
            }
            #line 888
            tail = t;
            #line 888
            t->succ = 0;
         }
         #line 890
         t->tail = l;
         #line 891
         l->_.next = 0;
      }
   }
   label:;
   #line 894
   X2C_PROC_OUT();
} /* end AppendObject() */

#line 896
static void ScanRecord(X2C_ADDRESS, OFFS);

#line 901

#line 896
static void ScanRecord(X2C_ADDRESS base, OFFS desc)
{
   #line 898
   X2C_TD type;
   #line 899
   X2C_ADDRESS x;
   #line 899
   X2C_ADDRESS cur;
   #line 899
   X2C_ADDRESS last;
   #line 900
   unsigned long i;
   #line 901
   X2C_PROC_INP();
   #line 902
   if (base==0) X2C_ASSERT(110ul);
   #line 904
   x = desc[0u];
   #line 904
   i = 1ul;
   #line 905
   while (x!=TAG_END) {
      #line 907
      if (x==TAG_ARR) {
         #line 908
         last = (X2C_ADDRESS)((char *)base+(long)(desc[i]-X2C_BASE));
         #line 908
         ++i;
         #line 909
         x = desc[i];
         #line 909
         ++i;
         #line 910
         if (x==TAG_ARR) X2C_ASSERT(111ul);
         #line 911
         if (x==TAG_REC) {
            #line 912
            type = (X2C_TD)desc[i];
            #line 912
            ++i;
            #line 913
            if (type->res!=0x093678150ul) {
               #line 913
               (X2C_SET_HINFO() X2C_ASSERT_F(112ul));
            }
            #line 914
            cur = (X2C_ADDRESS)((char *)base+(long)(desc[i]-X2C_BASE));
            #line 914
            ++i;
            #line 915
            for (;;) {
               #line 916
               (X2C_SET_HINFO() ScanRecord(cur, (OFFS)type->offs));
               #line 917
               if (cur==last) {
                  #line 917
                  break;
               }
               #line 918
               cur = (X2C_ADDRESS)((char *)cur+(long)type->size);
            }
         }
         else {
            #line 921
            cur = (X2C_ADDRESS)((char *)base+(long)(x-X2C_BASE));
            #line 922
            for (;;) {
               #line 923
               (X2C_SET_HINFO() AppendObject((ADDR_REF)cur));
               #line 924
               if (cur==last) {
                  #line 924
                  break;
               }
               #line 925
               cur = (X2C_ADDRESS)((char *)cur+(long)sizeof(X2C_ADDRESS));
            }
         }
      }
      else if (x==TAG_REC) {
         #line 929
         type = (X2C_TD)desc[i];
         #line 929
         ++i;
         #line 930
         if (type->res!=0x093678150ul) {
            #line 930
            (X2C_SET_HINFO() X2C_ASSERT_F(113ul));
         }
         #line 931
         (X2C_SET_HINFO() ScanRecord((X2C_ADDRESS)((char *)base+(long)(desc[i]-X2C_BASE)), (OFFS)type->offs));
         #line 932
         ++i;
      }
      else {
         #line 935
         (X2C_SET_HINFO() AppendObject((ADDR_REF)(X2C_ADDRESS)((char *)base+(long)(x-X2C_BASE))));
      }
      #line 937
      x = desc[i];
      #line 937
      ++i;
   }
   #line 939
   X2C_PROC_OUT();
} /* end ScanRecord() */

#line 944

#line 942
static Destruct MarkDestructors(void)
{
   #line 943
   Destruct m;
   #line 943
   Destruct l;
   #line 943
   Destruct r;
   #line 943
   Destruct d;
   #line 943
   X2C_LINK d_link;
   #line 943
   X2C_LINK ln;
   Destruct MarkDestructors_ret;
   #line 944
   X2C_PROC_INP();
   #line 945
   #line 945
   if (xrMM_anchorTracing) {
      #line 946
      countingClosureInProgress = 1;
      #line 947
      hasDestructorAnchors = 0;
   }
   #line 950
   d = destruct;
   #line 950
   l = 0;
   #line 950
   r = 0;
   #line 951
   while (d) {
      #line 952
      d_link = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)d-(long)sizeof(struct X2C_LINK_STR));
      #line 953
      d_link->_0.tags |= 0x10000ul;
      #line 955
      ln = (X2C_LINK)(X2C_ADDRESS)((char *)d->adr-(long)sizeof(struct X2C_LINK_STR));
      #line 956
      if ((ln->_0.tags&0xC000ul)!=0ul) {
         #line 956
         (X2C_SET_HINFO() X2C_ASSERT_F(119ul));
      }
      #line 958
      if ((0x10000ul & ln->_0.tags)) {
         #line 959
         l = d;
         #line 959
         d = d->next;
      }
      else {
         #line 961
         m = d;
         #line 961
         d = d->next;
         #line 962
         if (l==0) {
            #line 962
            destruct = d;
         }
         else {
            #line 962
            l->next = d;
         }
         #line 963
         m->next = r;
         #line 963
         r = m;
         #line 965
         anchorWeight = 0ul;
         #line 966
         (X2C_SET_HINFO() AppendObject(&m->adr));
         #line 967
         if (xrMM_anchorTracing) {
            #line 968
            (X2C_SET_HINFO() printDestructorAnchorWeight(m->adr));
         }
      }
   }
   #line 973
   if (xrMM_anchorTracing) {
      #line 974
      countingClosureInProgress = 0;
   }
   #line 976
   MarkDestructors_ret = r;
   #line 977
   X2C_PROC_OUT();
   return MarkDestructors_ret;
} /* end MarkDestructors() */

#line 982

#line 980
static void AdjustRef(ADDR_REF ref)
{
   #line 981
   X2C_LINK l;
   #line 982
   X2C_PROC_INP();
   #line 983
   #line 983
   if (*ref==0) {
      #line 983
      goto label;
   }
   #line 984
   l = (X2C_LINK)(X2C_ADDRESS)((char *)*ref-(long)sizeof(struct X2C_LINK_STR));
   #line 985
   if ((0x40000ul & l->_0.tags)) {
      #line 986
      *ref = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l->_.next+(long)sizeof(struct X2C_LINK_STR));
   }
   label:;
   #line 988
   X2C_PROC_OUT();
} /* end AdjustRef() */

#line 994

#line 991
static void AdjustRTStructures(void)
{
   #line 992
   Destruct d;
   #line 994
   X2C_PROC_INP();
   #line 995
   if (destruct) {
      #line 997
      (X2C_SET_HINFO() AdjustRef((ADDR_REF) &destruct));
      #line 998
      d = destruct;
      #line 999
      while (d) {
         #line 1000
         (X2C_SET_HINFO() AdjustRef((ADDR_REF) &d->next));
         #line 1001
         (X2C_SET_HINFO() AdjustRef(&d->adr));
         #line 1002
         d = d->next;
      }
   }
   #line 1005
   X2C_PROC_OUT();
} /* end AdjustRTStructures() */

#line 1008
static void SortPtrs(X2C_ADDRESS [], unsigned long, long, long);

#line 1010

#line 1008
static void SortPtrs(X2C_ADDRESS buf[], unsigned long buf_len, long l, long r)
{
   #line 1009
   long j;
   #line 1009
   long i;
   #line 1009
   X2C_ADDRESS w;
   #line 1009
   X2C_ADDRESS x;
   #line 1010
   X2C_PROC_INP();
   #line 1011
   i = l;
   #line 1011
   j = r;
   #line 1011
   x = buf[X2C_DIV(l+r,2l)];
   #line 1012
   do {
      #line 1013
      while ((X2C_SET_HINFO() X2C_adr_lss(buf[i], x))) {
         #line 1013
         ++i;
      }
      #line 1014
      while ((X2C_SET_HINFO() X2C_adr_gtr(buf[j], x))) {
         #line 1014
         --j;
      }
      #line 1015
      if (i<=j) {
         #line 1016
         w = buf[i];
         #line 1016
         buf[i] = buf[j];
         #line 1016
         buf[j] = w;
         #line 1017
         ++i;
         #line 1017
         --j;
      }
   } while (i<=j);
   #line 1020
   if (l<j) {
      #line 1020
      (X2C_SET_HINFO() SortPtrs(buf, buf_len, l, j));
   }
   #line 1021
   if (i<r) {
      #line 1021
      (X2C_SET_HINFO() SortPtrs(buf, buf_len, i, r));
   }
   #line 1022
   X2C_PROC_OUT();
} /* end SortPtrs() */

#line 1029

#line 1027
static void Sort(X2C_ADDRESS * max0, X2C_ADDRESS * min0, xrMM_Block * head, X2C_ADDRESS buf[], unsigned long buf_len, unsigned long no)
{
   #line 1028
   xrMM_Block b;
   #line 1028
   xrMM_Block h;
   #line 1028
   xrMM_Block l;
   #line 1028
   unsigned long i;
   #line 1028
   X2C_ADDRESS be;
   unsigned long tmp;
   #line 1029
   X2C_PROC_INP();
   #line 1030
   (X2C_SET_HINFO() SortPtrs(buf, buf_len, 0l, (long)(no-1ul)));
   #line 1031
   h = 0;
   #line 1031
   l = *head;
   #line 1032
   tmp = no-1ul;
   i = 0ul;
   if (i<=tmp) for (;; i++) {
      #line 1033
      b = (xrMM_Block)buf[i];
      #line 1034
      while (l && (X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)l, (X2C_ADDRESS)b))) {
         #line 1034
         h = l;
         #line 1034
         l = l->snxt;
      }
      #line 1035
      if (h==0) {
         #line 1035
         *head = b;
      }
      else {
         #line 1035
         h->snxt = b;
      }
      #line 1036
      h = b;
      #line 1036
      b->snxt = l;
      if (i==tmp) break;
   } /* end for */
   #line 1038
   l = (xrMM_Block)buf[no-1ul];
   #line 1039
   be = (X2C_ADDRESS)((char *)(X2C_SET_HINFO() xrMM_getLastBlockAdr1(l))-(long)1l);
   #line 1040
   if (*min0==0 || (X2C_SET_HINFO() X2C_adr_lss(buf[0ul], *min0))) {
      #line 1040
      *min0 = buf[0ul];
   }
   #line 1041
   if (*max0==0 || (X2C_SET_HINFO() X2C_adr_gtr(be, *max0))) {
      #line 1041
      *max0 = be;
   }
   #line 1042
   X2C_PROC_OUT();
} /* end Sort() */

#line 1045

#line 1024
static void SortBlocks(xrMM_Block blocks[], unsigned long blocks_len, xrMM_Block * head, X2C_ADDRESS * min0, X2C_ADDRESS * max0)
{
   #line 1044
   xrMM_Block b;
   #line 1044
   xrMM_Block e;
   #line 1044
   unsigned long j;
   #line 1044
   unsigned long i;
   #line 1044
   X2C_ADDRESS buf[256];
   unsigned long tmp;
   #line 1045
   X2C_PROC_INP();
   #line 1046
   j = 0ul;
   #line 1047
   tmp = blocks_len-1;
   i = 0ul;
   if (i<=tmp) for (;; i++) {
      #line 1048
      b = blocks[i]->next;
      #line 1049
      e = blocks[i];
      #line 1050
      while (b!=e) {
         #line 1051
         if (j>255ul) {
            #line 1051
            (X2C_SET_HINFO() Sort(max0, min0, head, buf, 256ul, j));
            #line 1051
            j = 0ul;
         }
         #line 1052
         buf[j] = (X2C_ADDRESS)b;
         #line 1052
         ++j;
         #line 1052
         b = b->next;
      }
      if (i==tmp) break;
   } /* end for */
   #line 1055
   if (j>0ul) {
      #line 1055
      (X2C_SET_HINFO() Sort(max0, min0, head, buf, 256ul, j));
      #line 1055
      j = 0ul;
   }
   #line 1056
   X2C_PROC_OUT();
} /* end SortBlocks() */

#line 1068

#line 1058
static void CheckPtrs(xrMM_Block head, X2C_ADDRESS buf[], unsigned long buf_len, unsigned long no)
{
   #line 1064
   X2C_ADDRESS obj;
   #line 1065
   X2C_ADDRESS end;
   #line 1066
   unsigned long sz;
   #line 1066
   unsigned long i;
   #line 1067
   X2C_LINK n;
   #line 1067
   X2C_LINK l;
   #line 1068
   X2C_PROC_INP();
   #line 1069
   if (no<=0ul) X2C_ASSERT(120ul);
   #line 1070
   (X2C_SET_HINFO() SortPtrs(buf, buf_len, 0l, (long)(no-1ul)));
   #line 1071
   i = 0ul;
   #line 1072
   if (head->magic!=305419896ul) {
      #line 1072
      (X2C_SET_HINFO() X2C_ASSERT_F(121ul));
   }
   #line 1073
   if (X2C_IN((long)head->root,32,0x200001ul)) {
      #line 1074
      end = (X2C_SET_HINFO() xrMM_getLastBlockAdr1(head));
   }
   else {
      #line 1076
      end = head->mem;
   }
   #line 1078
   for (;;) {
      #line 1079
      if (!(i==no-1ul || !(X2C_SET_HINFO() X2C_adr_gtr(buf[i], buf[i+1ul])))) X2C_ASSERT(122ul);
      #line 1080
      if ((X2C_SET_HINFO() X2C_adr_lss(buf[i], (X2C_ADDRESS)((char *)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(head))+(long)(long)sizeof(struct X2C_LINK_STR))))) {
         #line 1082
         ++i;
         #line 1083
         if (i==no) {
            #line 1083
            break;
         }
      }
      else if (!(X2C_SET_HINFO() X2C_adr_lss(buf[i], end))) {
         #line 1085
         head = head->snxt;
         #line 1086
         if (head==0) {
            #line 1086
            break;
         }
         #line 1087
         if (head->magic!=305419896ul) {
            #line 1087
            (X2C_SET_HINFO() X2C_ASSERT_F(123ul));
         }
         #line 1088
         if (X2C_IN((long)head->root,32,0x200001ul)) {
            #line 1089
            end = (X2C_SET_HINFO() xrMM_getLastBlockAdr1(head));
         }
         else {
            #line 1091
            end = head->mem;
         }
      }
      else if ((unsigned long)head->root==21ul) {
         #line 1094
         l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(head));
         #line 1095
         obj = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sizeof(struct X2C_LINK_STR));
         #line 1096
         if ((0x4ul & l->_0.tags)==0) {
            #line 1097
            anchorWeight = 0ul;
            #line 1098
            (X2C_SET_HINFO() AppendObject(&obj));
            #line 1099
            l->_0.tags |= 0x80000ul;
            #line 1100
            if (xrMM_anchorTracing) {
               #line 1101
               (X2C_SET_HINFO() printStackAnchorWeight(obj));
            }
         }
         #line 1104
         ++i;
         #line 1105
         if (i==no) {
            #line 1105
            break;
         }
      }
      else {
         #line 1107
         l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(head));
         #line 1109
         if (head->root) {
            #line 1110
            sz = (unsigned long)head->root*sizeof(struct X2C_LINK_STR);
            #line 1111
            for (;;) {
               #line 1112
               for (;;) {
                  #line 1113
                  if (!(X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)l, end))) X2C_ASSERT(124ul);
                  #line 1114
                  if (!(((0x20000ul & l->_0.tags) || (l->_0.tags&0x50000ul)!=0ul) || l->_.td->res==0x093678150ul)) X2C_ASSERT(125ul);
                  #line 1117
                  n = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sz);
                  #line 1118
                  if ((X2C_SET_HINFO() X2C_adr_lss(buf[i], (X2C_ADDRESS)n))) {
                     #line 1118
                     break;
                  }
                  #line 1119
                  l = n;
               }
               #line 1121
               obj = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sizeof(struct X2C_LINK_STR));
               #line 1124
               if ((0x60000ul&l->_0.tags)==0ul && !(X2C_SET_HINFO() X2C_adr_lss(buf[i], obj))) {
                  #line 1125
                  anchorWeight = 0ul;
                  #line 1126
                  (X2C_SET_HINFO() AppendObject(&obj));
                  #line 1127
                  l->_0.tags |= 0x80000ul;
                  #line 1128
                  if (xrMM_anchorTracing) {
                     #line 1129
                     (X2C_SET_HINFO() printStackAnchorWeight(obj));
                  }
               }
               #line 1132
               if (i+1ul<no && (X2C_SET_HINFO() X2C_adr_lss(buf[i+1ul], end))) {
                  #line 1132
                  ++i;
               }
               else {
                  #line 1132
                  break;
               }
            }
         }
         else {
            #line 1135
            for (;;) {
               #line 1136
               for (;;) {
                  #line 1137
                  if (!(X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)l, end))) X2C_ASSERT(124ul);
                  #line 1138
                  sz = (X2C_SET_HINFO() getHpObjSize(l));
                  #line 1139
                  if (!(((0x20000ul & l->_0.tags) || (l->_0.tags&0x50000ul)!=0ul) || l->_.td->res==0x093678150ul)) X2C_ASSERT(125ul);
                  #line 1143
                  n = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sz);
                  #line 1144
                  if ((X2C_SET_HINFO() X2C_adr_lss(buf[i], (X2C_ADDRESS)n))) {
                     #line 1144
                     break;
                  }
                  #line 1145
                  l = n;
               }
               #line 1147
               obj = (X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sizeof(struct X2C_LINK_STR));
               #line 1150
               if ((0x60000ul&l->_0.tags)==0ul && !(X2C_SET_HINFO() X2C_adr_lss(buf[i], obj))) {
                  #line 1151
                  anchorWeight = 0ul;
                  #line 1152
                  (X2C_SET_HINFO() AppendObject(&obj));
                  #line 1153
                  l->_0.tags |= 0x80000ul;
                  #line 1154
                  if (xrMM_anchorTracing) {
                     #line 1155
                     (X2C_SET_HINFO() printStackAnchorWeight(obj));
                  }
               }
               #line 1158
               if (i+1ul<no && (X2C_SET_HINFO() X2C_adr_lss(buf[i+1ul], end))) {
                  #line 1158
                  ++i;
               }
               else {
                  #line 1158
                  break;
               }
            }
         }
         #line 1161
         ++i;
         #line 1162
         if (i==no) {
            #line 1162
            break;
         }
      }
   }
   #line 1165
   X2C_PROC_OUT();
} /* end CheckPtrs() */

#line 1173

#line 1167
static void ScanStack(xrMM_Block head, X2C_ADDRESS min0, X2C_ADDRESS max0, ADDR_REF fr, ADDR_REF to)
{
   #line 1172
   X2C_ADDRESS buf[256];
   #line 1172
   ADDR_REF r;
   #line 1172
   unsigned long i;
   #line 1173
   X2C_PROC_INP();
   #line 1174
   if (sizeof(X2C_ADDRESS)>ADR_ALIGMENT) {
      #line 1175
      to = (ADDR_REF)(X2C_ADDRESS)((char *)(X2C_ADDRESS)to-(long)(sizeof(X2C_ADDRESS)-ADR_ALIGMENT));
   }
   else {
      #line 1177
      to = (ADDR_REF)(X2C_ADDRESS)((char *)(X2C_ADDRESS)to-(long)(ADR_ALIGMENT-sizeof(X2C_ADDRESS)));
   }
   #line 1179
   while (!(X2C_SET_HINFO() X2C_adr_gtr((X2C_ADDRESS)fr, (X2C_ADDRESS)to))) {
      #line 1180
      i = 0ul;
      #line 1181
      for (;;) {
         #line 1182
         r = fr;
         #line 1183
         fr = (ADDR_REF)(X2C_ADDRESS)((char *)(X2C_ADDRESS)fr+(long)ADR_ALIGMENT);
         #line 1184
         if (!(X2C_SET_HINFO() X2C_adr_lss(*r, min0)) && !(X2C_SET_HINFO() X2C_adr_gtr(*r, max0))) {
            #line 1186
            buf[i] = *r;
            #line 1186
            ++i;
            #line 1187
            if (i>255ul) {
               #line 1187
               break;
            }
         }
         #line 1189
         if ((X2C_SET_HINFO() X2C_adr_gtr((X2C_ADDRESS)fr, (X2C_ADDRESS)to))) {
            #line 1189
            break;
         }
      }
      #line 1191
      if (i>0ul) {
         #line 1191
         (X2C_SET_HINFO() CheckPtrs(head, buf, 256ul, i));
      }
   }
   #line 1263
   X2C_PROC_OUT();
} /* end ScanStack() */

#line 1271

#line 1265
static void MarkStack(void)
{
   #line 1267
   X2C_ADDRESS max0;
   #line 1267
   X2C_ADDRESS min0;
   #line 1268
   ADDR_REF a;
   #line 1268
   ADDR_REF to;
   #line 1268
   ADDR_REF fr;
   #line 1269
   xrMM_Block head;
   #line 1270
   X2C_Coroutine e;
   #line 1270
   X2C_Coroutine c;
   #line 1271
   X2C_PROC_INP();
   #line 1272
   if (xrMM_anchorTracing) {
      #line 1273
      countingClosureInProgress = 1;
      #line 1274
      hasStackAnchors = 0;
   }
   #line 1277
   head = 0;
   #line 1277
   min0 = 0;
   #line 1277
   max0 = 0;
   #line 1278
   (X2C_SET_HINFO() SortBlocks(xrMM_f_blocks, 22ul, &head, &min0, &max0));
   #line 1279
   (X2C_SET_HINFO() SortBlocks(xrMM_b_blocks, 22ul, &head, &min0, &max0));
   #line 1281
   if (head) {
      #line 1282
      e = (X2C_SET_HINFO() X2C_GetCurrent());
      #line 1282
      c = e->fwd;
      #line 1284
      if (c==e) X2C_ASSERT(137ul);
      #line 1286
      for (;;) {
         #line 1289
         if (c==e) {
            #line 1290
            break;
         }
         #line 1293
         if (c==xrMM_GCInvoker) {
            #line 1294
            fr = (ADDR_REF)c->stk_start;
            #line 1295
            to = (ADDR_REF)xrMM_StackEnd4GC;
         }
         else {
            #line 1297
            fr = (ADDR_REF)c->stk_start;
            #line 1298
            to = (ADDR_REF)c->stk_end;
         }
         #line 1300
         if (to==0) {
            #line 1300
            to = fr;
         }
         #line 1301
         if ((X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)to, (X2C_ADDRESS)fr))) {
            #line 1301
            a = to;
            #line 1301
            to = fr;
            #line 1301
            fr = a;
         }
         #line 1302
         (X2C_SET_HINFO() ScanStack(head, min0, max0, fr, to));
         #line 1303
         if (c->reg_dsize>sizeof(X2C_ADDRESS) && c!=xrMM_GCInvoker) {
            #line 1304
            fr = (ADDR_REF)c->reg_dump;
            #line 1305
            to = (ADDR_REF)(X2C_ADDRESS)((char *)(X2C_ADDRESS)fr+(long)c->reg_dsize);
            #line 1306
            (X2C_SET_HINFO() ScanStack(head, min0, max0, fr, to));
         }
         #line 1313
         c = c->fwd;
      }
   }
   #line 1317
   if (xrMM_anchorTracing) {
      #line 1318
      countingClosureInProgress = 0;
   }
   #line 1320
   X2C_PROC_OUT();
} /* end MarkStack() */

#line 1324

#line 1322
static void MarkObject(X2C_LINK x, X2C_TD type)
{
   #line 1323
   unsigned long len;
   #line 1323
   unsigned long n;
   #line 1323
   X2C_ADDRESS a;
   #line 1323
   xrMM_Block b;
   #line 1324
   X2C_PROC_INP();
   #line 1325
   if (type->res!=0x093678150ul) X2C_ASSERT(138ul);
   #line 1327
   if ((x->_0.tags&0xFFE00000ul)==0ul) {
      #line 1328
      b = (X2C_SET_HINFO() xrMM_getLargeObjBlock(x));
      #line 1329
      if ((unsigned long)b->root!=21ul) X2C_ASSERT(0);
      #line 1330
      len = b->fsum;
   }
   else {
      #line 1332
      len = (X2C_SET_HINFO() getHpObjSize(x));
   }
   #line 1335
   len = (len-sizeof(struct X2C_LINK_STR))/type->size;
   #line 1336
   a = (X2C_ADDRESS)((char *)(X2C_ADDRESS)x+(long)sizeof(struct X2C_LINK_STR));
   #line 1337
   n = 0ul;
   #line 1338
   while (n<len) {
      #line 1341
      (X2C_SET_HINFO() ScanRecord(a, (OFFS)type->offs));
      #line 1342
      ++n;
      #line 1343
      a = (X2C_ADDRESS)((char *)a+(long)(long)type->size);
   }
   #line 1345
   X2C_PROC_OUT();
} /* end MarkObject() */

#line 1350

#line 1348
static void Closure(void)
{
   #line 1349
   X2C_LINK x;
   #line 1349
   X2C_LINK l;
   #line 1350
   X2C_PROC_INP();
   #line 1351
   while (marked) {
      #line 1352
      l = marked->link;
      #line 1353
      while (l) {
         #line 1354
         (X2C_SET_HINFO() MarkObject(l, marked));
         #line 1355
         x = l;
         #line 1356
         l = l->_.next;
         #line 1357
         x->_.td = marked;
      }
      #line 1359
      marked->link = 0;
      #line 1360
      marked = marked->succ;
   }
   #line 1362
   X2C_PROC_OUT();
} /* end Closure() */

#line 1373

#line 1365
static void MarkModules(void)
{
   #line 1367
   X2C_MD l;
   #line 1368
   OFFS desc;
   #line 1369
   X2C_TD type;
   #line 1370
   X2C_ADDRESS cur;
   #line 1370
   X2C_ADDRESS last;
   #line 1370
   X2C_ADDRESS x;
   #line 1371
   unsigned long i;
   #line 1372
   X2C_ADDRESS anchorBase;
   #line 1373
   X2C_PROC_INP();
   #line 1374
   if (xrMM_anchorTracing) {
      #line 1375
      (X2C_SET_HINFO() printAnchorTraceCaption());
      #line 1376
      countingClosureInProgress = 1;
   }
   #line 1379
   l = X2C_MODULES;
   #line 1380
   while (l) {
      #line 1381
      desc = (OFFS)l->offs;
      #line 1382
      x = desc[0u];
      #line 1382
      i = 1ul;
      #line 1383
      hasModuleAnchors = 0;
      #line 1385
      while (x!=TAG_END) {
         #line 1386
         if (x==TAG_REC) {
            #line 1387
            type = (X2C_TD)desc[i];
            #line 1387
            ++i;
            #line 1388
            if (type->res!=0x093678150ul) {
               #line 1388
               (X2C_SET_HINFO() X2C_ASSERT_F(114ul));
            }
            #line 1390
            anchorBase = desc[i];
            #line 1391
            anchorWeight = 0ul;
            #line 1392
            (X2C_SET_HINFO() ScanRecord(anchorBase, (OFFS)type->offs));
            #line 1392
            ++i;
            #line 1394
            if (xrMM_anchorTracing) {
               #line 1395
               (X2C_SET_HINFO() printModuleAnchorWeight("RECORD ", 8ul, anchorBase, l->name));
            }
         }
         else if (x==TAG_ARR) {
            #line 1398
            last = desc[i];
            #line 1398
            ++i;
            #line 1399
            x = desc[i];
            #line 1399
            ++i;
            #line 1400
            if (x==TAG_ARR) X2C_ASSERT(115ul);
            #line 1401
            if (x==TAG_REC) {
               #line 1402
               type = (X2C_TD)desc[i];
               #line 1402
               ++i;
               #line 1403
               if (type->res!=0x093678150ul) {
                  #line 1403
                  (X2C_SET_HINFO() X2C_ASSERT_F(116ul));
               }
               #line 1404
               cur = desc[i];
               #line 1404
               ++i;
               #line 1405
               anchorBase = cur;
               #line 1406
               anchorWeight = 0ul;
               #line 1407
               for (;;) {
                  #line 1409
                  (X2C_SET_HINFO() ScanRecord(cur, (OFFS)type->offs));
                  #line 1410
                  if (cur==last) {
                     #line 1410
                     break;
                  }
                  #line 1411
                  cur = (X2C_ADDRESS)((char *)cur+(long)type->size);
               }
               #line 1413
               if (xrMM_anchorTracing) {
                  #line 1414
                  (X2C_SET_HINFO() printModuleAnchorWeight("ARRAY OF RECORDs", 17ul, anchorBase, l->name));
               }
            }
            else {
               #line 1417
               cur = x;
               #line 1418
               anchorWeight = 0ul;
               #line 1419
               for (;;) {
                  #line 1420
                  if (cur==0) X2C_ASSERT(117ul);
                  #line 1421
                  (X2C_SET_HINFO() AppendObject((ADDR_REF)cur));
                  #line 1422
                  if (cur==last) {
                     #line 1422
                     break;
                  }
                  #line 1423
                  cur = (X2C_ADDRESS)((char *)cur+(long)sizeof(X2C_ADDRESS));
               }
               #line 1426
               if (xrMM_anchorTracing) {
                  #line 1427
                  (X2C_SET_HINFO() printModuleAnchorWeight("ARRAY OF POINTERs", 18ul, x, l->name));
               }
            }
         }
         else {
            #line 1432
            if (x==0) X2C_ASSERT(118ul);
            #line 1433
            anchorWeight = 0ul;
            #line 1434
            (X2C_SET_HINFO() AppendObject((ADDR_REF)x));
            #line 1436
            if (xrMM_anchorTracing) {
               #line 1437
               (X2C_SET_HINFO() printModuleAnchorWeight("POINTER", 8ul, x, l->name));
            }
         }
         #line 1440
         x = desc[i];
         #line 1441
         ++i;
      }
      #line 1443
      l = l->next;
   }
   #line 1446
   if (xrMM_anchorTracing) {
      #line 1447
      countingClosureInProgress = 0;
   }
   #line 1449
   X2C_PROC_OUT();
} /* end MarkModules() */

#line 1454
enum scanerStates {ss_noneFO, 
   ss_savedFO, 
   ss_accumFO};


#line 1468

#line 1452
static void normal_scan(xrMM_Block x, char defrag)
{
   #line 1458
   unsigned char state;
   #line 1459
   X2C_LINK savedFO;
   #line 1460
   char savedFO_inPool;
   #line 1461
   unsigned long mergedObjSize;
   #line 1463
   X2C_LINK l;
   #line 1464
   char l_inPool;
   #line 1466
   unsigned long size;
   #line 1467
   unsigned long sz;
   #line 1468
   X2C_PROC_INP();
   #line 1471
   #line 1471
   size = 0ul;
   #line 1472
   state = ss_noneFO;
   #line 1474
   l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
   #line 1475
   x->fixed = 0;
   #line 1476
   x->fsum = 16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR);
   #line 1477
   for (;;) {
      #line 1478
      if ((l->_0.tags&0xFFE00000ul)==0ul) X2C_ASSERT(1381ul);
      #line 1479
      sz = (X2C_SET_HINFO() getHpObjSize(l));
      #line 1480
      l_inPool = (0x20000ul & l->_0.tags)!=0;
      #line 1482
      if (!l_inPool) {
         #line 1485
         if (!((0x40000ul & l->_0.tags) || l->_.td->res==0x093678150ul)) X2C_ASSERT(140ul);
         #line 1487
         if ((l->_0.tags&0x1C000ul)==0ul) {
            #line 1488
            if ((0x80000ul & l->_0.tags)) X2C_ASSERT(141ul);
            #line 1491
            X2C_usedmem -= sz;
            #line 1492
            --X2C_objects;
            #line 1494
            (X2C_SET_HINFO() stampObjAsFree(l, sz));
         }
         else {
            #line 1496
            x->fsum -= sz;
            #line 1498
            if (defrag) {
               #line 1499
               if ((l->_0.tags&0x18C000ul)!=0ul) {
                  #line 1500
                  x->fixed = 1;
               }
               #line 1502
               l->_0.tags &= ~0x10000ul;
            }
            else {
               #line 1504
               l->_0.tags = l->_0.tags&~0x90000ul;
            }
            #line 1506
            X2C_normalused += sz;
         }
      }
      #line 1512
      if ((0x20000ul & l->_0.tags)) {
         #line 1513
         switch ((unsigned)state) {
         case ss_noneFO:
            #line 1514
            savedFO = l;
            #line 1515
            savedFO_inPool = l_inPool;
            #line 1516
            state = ss_savedFO;
            break;
         case ss_savedFO:
         case ss_accumFO:
            #line 1520
            if (state==ss_savedFO) {
               #line 1521
               if (savedFO_inPool) {
                  #line 1522
                  (X2C_SET_HINFO() xrMM_foManager_del(savedFO));
               }
            }
            #line 1526
            if (l_inPool) {
               #line 1527
               (X2C_SET_HINFO() xrMM_foManager_del(l));
            }
            #line 1530
            mergedObjSize = sz+(X2C_SET_HINFO() getHpObjSize(savedFO));
            #line 1532
            if (mergedObjSize==16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) {
               #line 1533
               (X2C_SET_HINFO() xrMM_free_block(x));
               #line 1534
               goto label;
            }
            #line 1537
            (X2C_SET_HINFO() stampObjAsFree(savedFO, mergedObjSize));
            #line 1538
            state = ss_accumFO;
            break;
         default:
            #line 1513
            X2C_TRAP(X2C_CASE_TRAP);
         } /* end switch */
      }
      else {
         #line 1541
         if (state==ss_accumFO || state==ss_savedFO && !savedFO_inPool) {
            #line 1543
            (X2C_SET_HINFO() xrMM_foManager_add(savedFO));
         }
         #line 1545
         state = ss_noneFO;
      }
      #line 1548
      size += sz;
      #line 1549
      if (size>=16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) {
         #line 1550
         if (size!=16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) X2C_ASSERT(142ul);
         #line 1552
         if (state==ss_accumFO || state==ss_savedFO && !savedFO_inPool) {
            #line 1554
            (X2C_SET_HINFO() xrMM_foManager_add(savedFO));
         }
         #line 1556
         X2C_normalbusy += 16384ul;
         #line 1558
         break;
      }
      #line 1560
      l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sz);
   }
   label:;
   #line 1562
   X2C_PROC_OUT();
} /* end normal_scan() */

#line 1565
static unsigned long smallBlocksTotal;

#line 1565
#line 1566
static unsigned long smallBlocksStackFixed;

#line 1566
#line 1567
static unsigned long smallBlocksSysbitFixed;

#line 1567
#line 1568
static unsigned long smallBlocksExpbitFixed;

#line 1568
#line 1573
#define BOFS_BIT 18

#line 1573
#line 1578

#line 1575
static xrMM_Block getObjBlock(X2C_LINK obj)
{
   #line 1577
   unsigned long ofs;
   xrMM_Block getObjBlock_ret;
   #line 1578
   X2C_PROC_INP();
   #line 1579
   #line 1579
   ofs = (unsigned long)X2C_LSH((unsigned long)obj->_0.size&0xFFE00000ul,32,-18);
   #line 1580
   getObjBlock_ret = (xrMM_Block)(X2C_LINK)((char *)obj-(long)(long)ofs);
   #line 1581
   X2C_PROC_OUT();
   return getObjBlock_ret;
} /* end getObjBlock() */

#line 1588

#line 1584
static void small_scan(xrMM_Block x, unsigned long root, char busy, char defrag)
{
   #line 1586
   X2C_LINK l;
   #line 1587
   unsigned long size;
   X2C_SEQ tmp[1];
   X2C_SEQ tmp0[2];
   X2C_SEQ tmp1[7];
   #line 1588
   X2C_PROC_INP();
   #line 1590
   #line 1590
   size = root*sizeof(struct X2C_LINK_STR);
   #line 1592
   l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
   #line 1593
   x->fixed = 0;
   #line 1594
   x->fsum = 16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR);
   #line 1595
   while ((X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)l, x->mem))) {
      #line 1596
      if ((X2C_SET_HINFO() getHpObjSize(l))!=size) X2C_ASSERT(1579ul);
      #line 1597
      if ((0x20000ul & l->_0.tags)==0) {
         #line 1598
         if ((l->_0.tags&0x1C000ul)==0ul) {
            #line 1600
            if ((0x80000ul & l->_0.tags)) X2C_ASSERT(143ul);
            #line 1603
            if ((0x40000ul & l->_0.tags)==0 && l->_.td->res!=0x093678150ul) {
               #line 1604
               (X2C_SET_HINFO() Printf_printf("\\nASSERT 144: l = %X\\n", 23ul, (tmp[0].adr = l, (char *)tmp), sizeof(X2C_SEQ)));
               #line 1605
               (X2C_SET_HINFO() Printf_printf("\\nASSERT 144: l^.tags = %X  l^.td = %X\\n", 41ul, (tmp0[0].val = (unsigned long)l->_0.tags, tmp0[1].adr = l->_.td, (char *)tmp0), 2ul*sizeof(X2C_SEQ)));
               #line 1606
               (X2C_SET_HINFO() Printf_printf("\\nASSERT 144: b(l)=%X  x=%X  x^.magic=%X x^.root=%X  x^.fixed=%X  x^.mem=%X x^.fsum=%X\\n", 89ul, (tmp1[0].adr = (X2C_SET_HINFO() getObjBlock(l)), tmp1[1].adr = x, tmp1[2].val = x->magic,
                tmp1[3].val = (unsigned long)x->root, tmp1[4].val = (unsigned long)x->fixed, tmp1[5].adr = x->mem, tmp1[6].val = x->fsum, (char *)tmp1), 7ul*sizeof(X2C_SEQ)));
               #line 1607
               (X2C_SET_HINFO() Printf_printf("\\nASSERT 144: l^.next^.tags = %X  l^.next^.td = %X l^.next^.td^.magic = %X\\n", 77ul, (tmp1[0].val = (unsigned long)l->_.next->_0.tags, tmp1[1].adr = l->_.next->_.td, tmp1[2].val = l->_.next->_.td->res,
                (char *)tmp1), 3ul*sizeof(X2C_SEQ)));
               #line 1608
               (X2C_SET_HINFO() Printf_printf("\\nASSERT 144: b(l^.next)=%X  root=%X  fixed=%X  mem=%X fsum=%X\\n", 65ul, (tmp1[0].adr = (X2C_SET_HINFO() getObjBlock(l->_.next)), tmp1[1].val = (unsigned long)(X2C_SET_HINFO() getObjBlock(l->_.next))->root,
                tmp1[2].val = (unsigned long)(X2C_SET_HINFO() getObjBlock(l->_.next))->fixed, tmp1[3].adr = (X2C_SET_HINFO() getObjBlock(l->_.next))->mem, tmp1[4].val = (X2C_SET_HINFO() getObjBlock(l->_.next))->fsum, (char *)tmp1), 5ul*sizeof(X2C_SEQ)));
            }
            #line 1611
            if (!((0x40000ul & l->_0.tags) || l->_.td->res==0x093678150ul)) X2C_ASSERT(144ul);
            #line 1614
            X2C_usedmem -= (X2C_SET_HINFO() getHpObjSize(l));
            #line 1615
            --X2C_objects;
            #line 1616
            l->_.next = x->list;
            #line 1617
            x->list = l;
            #line 1618
            (X2C_SET_HINFO() stampObjAsFree(l, size));
         }
         else {
            #line 1621
            if ((0x40000ul & l->_0.tags)) X2C_ASSERT(145ul);
            #line 1622
            if (l->_.td->res!=0x093678150ul) X2C_ASSERT(146ul);
            #line 1623
            if (defrag) {
               #line 1624
               if ((l->_0.tags&0x18C000ul)!=0ul) {
                  #line 1625
                  x->fixed = 1;
               }
               #line 1627
               l->_0.tags &= ~0x10000ul;
            }
            else {
               #line 1629
               l->_0.tags = l->_0.tags&~0x90000ul;
            }
            #line 1631
            x->fsum -= size;
            #line 1632
            X2C_smallused += size;
         }
      }
      #line 1635
      l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)size);
   }
   #line 1638
   if (x->fsum>16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) X2C_ASSERT(0);
   #line 1639
   if ((16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR))-x->fsum<size) {
      #line 1639
      (X2C_SET_HINFO() xrMM_free_block(x));
      #line 1639
      goto label;
   }
   #line 1641
   if (busy && x->list) {
      #line 1641
      (X2C_SET_HINFO() xrMM_MakeFree(x));
   }
   #line 1642
   X2C_smallbusy += 16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR);
   #line 1643
   ++smallBlocksTotal;
   label:;
   #line 1644
   X2C_PROC_OUT();
} /* end small_scan() */

#line 1648

#line 1646
static void large_scan(xrMM_Block x)
{
   #line 1647
   X2C_LINK l;
   #line 1648
   X2C_PROC_INP();
   #line 1650
   l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
   #line 1652
   if ((0x40000ul & l->_0.tags)) X2C_ASSERT(147ul);
   #line 1653
   if (l->_.td->res!=0x093678150ul) {
      #line 1653
      (X2C_SET_HINFO() X2C_ASSERT_F(148ul));
   }
   #line 1654
   if ((l->_0.tags&0x1C000ul)==0ul) {
      #line 1655
      if ((0x80000ul & l->_0.tags)) X2C_ASSERT(149ul);
      #line 1657
      X2C_usedmem -= x->fsum;
      #line 1658
      --X2C_objects;
      #line 1659
      (X2C_SET_HINFO() xrMM_free_block(x));
   }
   else {
      #line 1661
      l->_0.tags = l->_0.tags&~0x90000ul;
      #line 1662
      X2C_largebusy += x->fsum;
   }
   #line 1664
   X2C_PROC_OUT();
} /* end large_scan() */

#line 1668

#line 1666
static void Sweep(xrMM_Block blocks[], unsigned long blocks_len, char busy, char defrag)
{
   #line 1667
   unsigned long i;
   #line 1667
   xrMM_Block n;
   #line 1667
   xrMM_Block x;
   #line 1667
   xrMM_Block root;
   #line 1668
   X2C_PROC_INP();
   #line 1669
   root = blocks[0ul];
   #line 1669
   x = root->next;
   #line 1670
   while (x!=root) {
      #line 1670
      n = x;
      #line 1670
      x = x->next;
      #line 1670
      (X2C_SET_HINFO() normal_scan(n, defrag));
   }
   #line 1672
   for (i = 1ul; i<=20ul; i++) {
      #line 1673
      root = blocks[i];
      #line 1673
      x = root->next;
      #line 1674
      while (x!=root) {
         #line 1674
         n = x;
         #line 1674
         x = x->next;
         #line 1674
         (X2C_SET_HINFO() small_scan(n, i, busy, defrag));
      }
   } /* end for */
   #line 1677
   root = blocks[21ul];
   #line 1677
   x = root->next;
   #line 1678
   while (x!=root) {
      #line 1678
      n = x;
      #line 1678
      x = x->next;
      #line 1678
      (X2C_SET_HINFO() large_scan(n));
   }
   #line 1679
   X2C_PROC_OUT();
} /* end Sweep() */

#line 1683

#line 1682
static char lss(xrMM_Block x, xrMM_Block y)
{
   char lss_ret;
   #line 1683
   X2C_PROC_INP();
   #line 1684
   #line 1684
   if (y->fixed) {
      #line 1684
      lss_ret = 0;
      goto label;
   }
   #line 1685
   lss_ret = x->fsum<=y->fsum;
   label:;
   #line 1686
   X2C_PROC_OUT();
   return lss_ret;
} /* end lss() */

#line 1688

#line 1681
static void DefragSort(xrMM_Block b)
{
   #line 1687
   xrMM_Block j;
   #line 1687
   xrMM_Block i;
   #line 1687
   xrMM_Block s;
   #line 1688
   X2C_PROC_INP();
   #line 1689
   s = 0;
   #line 1690
   while (b->next!=b) {
      #line 1691
      i = b->next;
      #line 1691
      b->next = i->next;
      #line 1692
      if ((i->fixed || s==0) || (X2C_SET_HINFO() lss(i, s))) {
         #line 1693
         i->next = s;
         #line 1693
         s = i;
      }
      else {
         #line 1695
         j = s;
         #line 1696
         while (j->next && !(X2C_SET_HINFO() lss(i, j->next))) {
            #line 1696
            j = j->next;
         }
         #line 1697
         i->next = j->next;
         #line 1697
         j->next = i;
      }
   }
   #line 1700
   b->next = s;
   #line 1700
   j = b;
   #line 1701
   while (s) {
      #line 1701
      s->prev = j;
      #line 1701
      j = s;
      #line 1701
      s = s->next;
   }
   #line 1702
   b->prev = j;
   #line 1702
   j->next = b;
   #line 1703
   X2C_PROC_OUT();
} /* end DefragSort() */

#line 1705
static unsigned long SmallBlocksReleased;

#line 1705
#line 1706
static unsigned long SmallBlocksCompleted;

#line 1706
#line 1710

#line 1708
static void Defragment(xrMM_Block b)
{
   #line 1709
   xrMM_Block last;
   #line 1709
   xrMM_Block first;
   #line 1709
   X2C_LINK l;
   #line 1709
   X2C_LINK n;
   #line 1709
   unsigned long size;
   #line 1710
   X2C_PROC_INP();
   #line 1711
   #line 1711
   if (!X2C_IN((long)b->root,32,0x1FFFFEul)) X2C_ASSERT(0);
   #line 1712
   size = (unsigned long)b->root*sizeof(struct X2C_LINK_STR);
   #line 1713
   first = b->next;
   #line 1714
   last = b->prev;
   #line 1715
   ++SmallBlocksCompleted;
   #line 1716
   while (first!=last && !last->fixed) {
      #line 1717
      if (first->magic!=305419896ul) X2C_ASSERT(150ul);
      #line 1718
      if (last->magic!=305419896ul) X2C_ASSERT(151ul);
      #line 1719
      l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(last));
      #line 1721
      while ((X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)l, last->mem))) {
         #line 1722
         if ((l->_0.tags&0x20000ul)==0ul) {
            #line 1723
            if ((l->_0.tags&0xCC000ul)!=0ul) X2C_ASSERT(155ul);
            #line 1724
            if (l->_.td->res!=0x093678150ul) X2C_ASSERT(152ul);
            #line 1727
            if (first->fsum<size) X2C_ASSERT(0);
            #line 1728
            if (first->list==0) {
               #line 1729
               n = (X2C_LINK)first->mem;
               #line 1730
               first->mem = (X2C_ADDRESS)(X2C_LINK)((char *)n+(long)(long)size);
            }
            else {
               #line 1732
               n = first->list;
               #line 1733
               first->list = n->_.next;
            }
            #line 1735
            first->fsum -= size;
            #line 1737
            X2C_usedmem += (X2C_SET_HINFO() getHpObjSize(l));
            #line 1738
            ++X2C_objects;
            #line 1740
            X2C_MOVE((X2C_ADDRESS)l,(X2C_ADDRESS)n,size);
            #line 1741
            l->_0.tags |= 0x40000ul;
            #line 1742
            l->_0.tags &= ~0x10000ul;
            #line 1743
            l->_.next = n;
            #line 1744
            last->fsum += size;
            #line 1746
            if (first->fsum<size) {
               #line 1747
               if (first->list) X2C_ASSERT(0);
               #line 1748
               (X2C_SET_HINFO() xrMM_MakeBusy(first));
               #line 1749
               first = b->next;
               #line 1750
               ++SmallBlocksCompleted;
            }
            #line 1753
            if (first==last) {
               #line 1753
               goto label;
            }
            #line 1754
            if (first->magic!=305419896ul) X2C_ASSERT(154ul);
         }
         #line 1756
         l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)size);
      }
      #line 1759
      if (last->fsum>16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) X2C_ASSERT(0);
      #line 1760
      if ((16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR))-last->fsum>=size) X2C_ASSERT(190ul);
      #line 1761
      ++SmallBlocksReleased;
      #line 1762
      last = last->prev;
   }
   label:;
   #line 1764
   X2C_PROC_OUT();
} /* end Defragment() */

#line 1770

#line 1769
static void MoveObject(X2C_LINK from, X2C_LINK to, xrMM_Block fromB, xrMM_Block toB, unsigned long size)
{
   #line 1770
   X2C_PROC_INP();
   #line 1771
   if (fromB->fsum<=size) X2C_ASSERT(0);
   #line 1773
   X2C_MOVE((X2C_ADDRESS)from,(X2C_ADDRESS)to,size);
   #line 1774
   (X2C_SET_HINFO() xrMM_setObjOfsLen(&to, size, (X2C_ADDRESS)to-(X2C_ADDRESS)toB));
   #line 1776
   from->_.next = to;
   #line 1777
   from->_0.tags |= 0x40000ul;
   #line 1778
   from->_0.tags &= ~0x10000ul;
   #line 1780
   fromB->fsum += size;
   #line 1781
   toB->fsum -= size;
   #line 1783
   X2C_usedmem += size;
   #line 1784
   X2C_PROC_OUT();
} /* end MoveObject() */

#line 1789
static unsigned long normalBlocksRest;

#line 1789
#line 1790
static unsigned long normalBlocksReleased;

#line 1790
#line 1791
static unsigned long normalBlocksMoved;

#line 1791
#line 1796
#define xrO2MM_MOVING_RATE 50

#line 1813

#line 1812
static unsigned long getNormalBusyMem(xrMM_Block b)
{
   unsigned long getNormalBusyMem_ret;
   #line 1813
   X2C_PROC_INP();
   #line 1814
   #line 1814
   getNormalBusyMem_ret = (16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR))-b->fsum;
   #line 1815
   X2C_PROC_OUT();
   return getNormalBusyMem_ret;
} /* end getNormalBusyMem() */

#line 1822

#line 1818
static char obtainNewBlock(unsigned long * freemem, X2C_LINK * nl, xrMM_Block * newb)
{
   char obtainNewBlock_ret;
   #line 1822
   X2C_PROC_INP();
   #line 1823
   #line 1823
   (X2C_SET_HINFO() xrMM_NewBlock(0u, newb, 16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)));
   #line 1825
   if (*newb==0) {
      #line 1827
      obtainNewBlock_ret = 0;
      goto label;
   }
   #line 1830
   *nl = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(*newb));
   #line 1831
   *freemem = 16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR);
   #line 1832
   obtainNewBlock_ret = 1;
   label:;
   #line 1833
   X2C_PROC_OUT();
   return obtainNewBlock_ret;
} /* end obtainNewBlock() */

#line 1840

#line 1836
static void completeNewBlock(xrMM_Block * newb, X2C_LINK * nl, unsigned long freemem)
{
   #line 1840
   X2C_PROC_INP();
   #line 1841
   if (freemem>0ul) {
      #line 1842
      (X2C_SET_HINFO() xrMM_setObjOfsLen(nl, freemem, (X2C_ADDRESS)*nl-(X2C_ADDRESS)*newb));
      #line 1843
      (X2C_SET_HINFO() stampObjAsFree(*nl, freemem));
      #line 1844
      (X2C_SET_HINFO() xrMM_foManager_add(*nl));
   }
   #line 1847
   if ((*newb)->fsum!=freemem) X2C_ASSERT(14049ul);
   #line 1848
   X2C_PROC_OUT();
} /* end completeNewBlock() */

#line 1850

#line 1794
static void DefragmentNormalBlocks(xrMM_Block blockList)
{
   #line 1798
   xrMM_Block newb;
   #line 1798
   xrMM_Block b;
   #line 1799
   xrMM_Block ib;
   #line 1800
   unsigned long freemem;
   #line 1801
   unsigned long bmem;
   #line 1803
   unsigned long rate;
   #line 1805
   X2C_LINK nl;
   #line 1805
   X2C_LINK l;
   #line 1806
   unsigned long size;
   #line 1807
   unsigned long sz;
   #line 1809
   unsigned long X2C_maxmem_saved;
   #line 1850
   X2C_PROC_INP();
   #line 1851
   #line 1851
   X2C_maxmem_saved = X2C_maxmem;
   #line 1852
   X2C_maxmem = X2C_max_longcard;
   #line 1854
   b = blockList;
   #line 1856
   normalBlocksRest = 0ul;
   #line 1857
   normalBlocksReleased = 0ul;
   #line 1858
   normalBlocksMoved = 1ul;
   #line 1860
   if (!(X2C_SET_HINFO() obtainNewBlock(&freemem, &nl, &newb))) {
      #line 1861
      X2C_maxmem = X2C_maxmem_saved;
      #line 1862
      goto label;
   }
   #line 1865
   ib = b->next;
   #line 1867
   while (ib!=b) {
      #line 1869
      bmem = (X2C_SET_HINFO() getNormalBusyMem(ib));
      #line 1870
      if (bmem>16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) X2C_ASSERT(14050ul);
      #line 1872
      if (bmem==0ul) {
         #line 1873
         if (ib->fixed) X2C_ASSERT(14051ul);
      }
      else {
         #line 1875
         rate = (bmem*100ul)/(16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR));
         #line 1877
         if (!ib->fixed && rate<50ul) {
            #line 1878
            size = 0ul;
            #line 1879
            l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(ib));
            #line 1881
            do {
               #line 1882
               sz = (X2C_SET_HINFO() getHpObjSize(l));
               #line 1884
               if ((0x20000ul & l->_0.tags)==0) {
                  #line 1886
                  if ((l->_0.tags&0x18C000ul)!=0ul) X2C_ASSERT(14066ul);
                  #line 1888
                  if (sz>freemem) {
                     #line 1889
                     ++normalBlocksMoved;
                     #line 1891
                     (X2C_SET_HINFO() completeNewBlock(&newb, &nl, freemem));
                     #line 1893
                     if (!(X2C_SET_HINFO() obtainNewBlock(&freemem, &nl, &newb))) {
                        #line 1894
                        X2C_maxmem = X2C_maxmem_saved;
                        #line 1895
                        goto label;
                     }
                  }
                  #line 1899
                  (X2C_SET_HINFO() MoveObject(l, nl, ib, newb, sz));
                  #line 1900
                  nl = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)nl+(long)sz);
                  #line 1902
                  freemem -= sz;
               }
               #line 1905
               size += sz;
               #line 1906
               l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)sz);
            } while (size<16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR));
            #line 1909
            ++normalBlocksReleased;
         }
         else {
            #line 1911
            ++normalBlocksRest;
         }
      }
      #line 1914
      ib = ib->next;
   }
   #line 1917
   (X2C_SET_HINFO() completeNewBlock(&newb, &nl, freemem));
   #line 1919
   X2C_maxmem = X2C_maxmem_saved;
   label:;
   #line 1976
   X2C_PROC_OUT();
} /* end DefragmentNormalBlocks() */

#line 1979
#define FloatingHeaplimitFreeReserve 4194304

#line 1979
#line 1988

#line 1985
static void cleanBlocks(xrMM_Block blocks[], unsigned long blocks_len)
{
   #line 1986
   unsigned long i;
   #line 1986
   xrMM_Block x;
   #line 1986
   xrMM_Block root;
   #line 1987
   X2C_LINK l;
   #line 1987
   unsigned long size;
   #line 1987
   unsigned long sz;
   #line 1988
   X2C_PROC_INP();
   #line 1989
   root = blocks[0ul];
   #line 1989
   x = root->next;
   #line 1990
   while (x!=root) {
      #line 1991
      l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
      #line 1992
      sz = 0ul;
      #line 1993
      for (;;) {
         #line 1994
         l->_0.tags &= ~0x10000ul;
         #line 1995
         size = (X2C_SET_HINFO() getHpObjSize(l));
         #line 1996
         if (size==0ul) {
            #line 1996
            break;
         }
         #line 1998
         l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)size);
         #line 1999
         sz += size;
         #line 2000
         if (sz>=16384ul-(((sizeof(struct xrMM_BlockDesc)+sizeof(struct X2C_LINK_STR)+sizeof(struct X2C_LINK_STR))-1ul)/sizeof(struct X2C_LINK_STR))*sizeof(struct X2C_LINK_STR)) {
            #line 2000
            break;
         }
      }
      #line 2002
      x = x->next;
   }
   #line 2005
   for (i = 1ul; i<=20ul; i++) {
      #line 2006
      root = blocks[i];
      #line 2006
      x = root->next;
      #line 2007
      size = i*sizeof(struct X2C_LINK_STR);
      #line 2008
      while (x!=root) {
         #line 2009
         l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
         #line 2010
         while ((X2C_SET_HINFO() X2C_adr_lss((X2C_ADDRESS)l, x->mem))) {
            #line 2011
            l->_0.tags &= ~0x10000ul;
            #line 2012
            l = (X2C_LINK)(X2C_ADDRESS)((char *)(X2C_ADDRESS)l+(long)size);
         }
         #line 2014
         x = x->next;
      }
   } /* end for */
   #line 2018
   root = blocks[21ul];
   #line 2018
   x = root->next;
   #line 2019
   while (x!=root) {
      #line 2020
      l = (X2C_LINK)(X2C_SET_HINFO() xrMM_getFirstBlockAdr(x));
      #line 2021
      l->_0.tags &= ~0x10000ul;
      #line 2022
      x = x->next;
   }
   #line 2024
   X2C_PROC_OUT();
} /* end cleanBlocks() */

#line 2026

#line 1983
static void cleanMarkbits(void)
{
   #line 2026
   X2C_PROC_INP();
   #line 2027
   (X2C_SET_HINFO() cleanBlocks(xrMM_f_blocks, 22ul));
   #line 2028
   (X2C_SET_HINFO() cleanBlocks(xrMM_b_blocks, 22ul));
   #line 2029
   X2C_PROC_OUT();
} /* end cleanMarkbits() */

#line 2034
static unsigned long MutatorStartTime;

#line 2034
#line 2035
static unsigned long GCStartTime;

#line 2035
#line 2038
#define DefaultMaxGCTimePercent 100

#line 2038
#line 2042

#line 2041
static unsigned long TruncToCard(float x)
{
   unsigned long TruncToCard_ret;
   #line 2042
   X2C_PROC_INP();
   #line 2043
   #line 2043
   if (x<0.5f) {
      #line 2044
      TruncToCard_ret = 0ul;
   }
   else if (x>4.2949672945E+9f) {
      #line 2046
      TruncToCard_ret = X2C_max_longcard;
   }
   else {
      #line 2048
      TruncToCard_ret = (unsigned long)X2C_TRUNCC(x,0ul,X2C_max_longcard);
   }
   #line 2050
   X2C_PROC_OUT();
   return TruncToCard_ret;
} /* end TruncToCard() */

#line 2056

#line 2054
static void do0(char defrag)
{
   #line 2055
   Destruct l;
   #line 2055
   Destruct d;
   #line 2056
   X2C_PROC_INP();
   #line 2057
   marked = 0;
   #line 2058
   tail = 0;
   #line 2059
   (X2C_SET_HINFO() MarkModules());
   #line 2061
   if (xrMM_GCAUTO) {
      #line 2061
      (X2C_SET_HINFO() MarkStack());
   }
   #line 2062
   (X2C_SET_HINFO() Closure());
   #line 2063
   d = (X2C_SET_HINFO() MarkDestructors());
   #line 2064
   if (d) {
      #line 2064
      (X2C_SET_HINFO() Closure());
   }
   #line 2066
   X2C_smallused = 0ul;
   #line 2067
   X2C_smallbusy = 0ul;
   #line 2068
   X2C_normalused = 0ul;
   #line 2069
   X2C_normalbusy = 0ul;
   #line 2070
   X2C_largebusy = 0ul;
   #line 2072
   if (xrMM_anchorTracing) {
      #line 2073
      (X2C_SET_HINFO() printSmallAnchorsWeight());
   }
   #line 2076
   if (xrMM_heapTracing) {
      #line 2077
      (X2C_SET_HINFO() printHeapTrace());
   }
   #line 2080
   (X2C_SET_HINFO() Sweep(xrMM_f_blocks, 22ul, 0, defrag));
   #line 2081
   (X2C_SET_HINFO() Sweep(xrMM_b_blocks, 22ul, 1, defrag));
   #line 2083
   if (xrMM_anchorTracing) {
      #line 2084
      (X2C_SET_HINFO() printLargeObjects());
      #line 2085
      (X2C_SET_HINFO() cleanMarkbits());
   }
   #line 2088
   while (d) {
      #line 2089
      l = d;
      #line 2089
      d = d->next;
      #line 2090
      (X2C_SET_HINFO() l->proc(l->adr));
   }
   #line 2092
   X2C_PROC_OUT();
} /* end do() */

#line 2098

#line 2053
static void COLLECT(void)
{
   #line 2094
   char defrag;
   #line 2094
   long i;
   #line 2095
   unsigned long minmaxmem;
   #line 2095
   unsigned long freePhysMem;
   #line 2095
   unsigned long maxmaxmem;
   #line 2096
   unsigned long curTime;
   #line 2097
   char gcTrash;
   #line 2098
   X2C_PROC_INP();
   #line 2099
   (X2C_SET_HINFO() X2C_PrepareToGC());
   #line 2105
   curTime = (X2C_SET_HINFO() TimeConv_millisecs());
   #line 2106
   if (curTime>=MutatorStartTime) {
      #line 2107
      MutatorPeriod = curTime-MutatorStartTime;
   }
   #line 2109
   GCStartTime = curTime;
   #line 2111
   defrag = xrMM_DoDefrag || xrMM_X2C_AlwaysDefrag;
   #line 2112
   xrMM_DoDefrag = 0;
   #line 2113
   smallBlocksTotal = 0ul;
   #line 2114
   smallBlocksStackFixed = 0ul;
   #line 2115
   smallBlocksSysbitFixed = 0ul;
   #line 2116
   smallBlocksExpbitFixed = 0ul;
   #line 2117
   (X2C_SET_HINFO() do0(defrag));
   #line 2119
   if (defrag) {
      #line 2121
      SmallBlocksCompleted = 0ul;
      #line 2122
      SmallBlocksReleased = 0ul;
      #line 2123
      for (i = 1l; i<=20l; i++) {
         #line 2124
         (X2C_SET_HINFO() DefragSort(xrMM_f_blocks[i]));
         #line 2125
         (X2C_SET_HINFO() Defragment(xrMM_f_blocks[i]));
      } /* end for */
      #line 2127
      (X2C_SET_HINFO() DefragmentNormalBlocks(xrMM_f_blocks[0u]));
      #line 2129
      (X2C_SET_HINFO() AdjustRTStructures());
      #line 2131
      (X2C_SET_HINFO() do0(0));
   }
   #line 2138
   curTime = (X2C_SET_HINFO() TimeConv_millisecs());
   #line 2139
   if (curTime>=GCStartTime) {
      #line 2140
      GCPeriod = curTime-GCStartTime;
   }
   #line 2142
   MutatorStartTime = curTime;
   #line 2149
   if (MutatorPeriod && X2C_max_longcard/MutatorPeriod<X2C_MaxGCTimePercent) {
      #line 2151
      gcTrash = GCPeriod/X2C_MaxGCTimePercent>MutatorPeriod/100ul;
   }
   else {
      #line 2153
      gcTrash = GCPeriod>(X2C_MaxGCTimePercent*MutatorPeriod)/100ul;
   }
   #line 2156
   if (xrMM_FloatingHeaplimit) {
      #line 2160
      X2C_maxmem = (X2C_SET_HINFO() TruncToCard((float)(X2C_busymem+X2C_busylheap+xrMM_SizeToAlloc)*2.85f));
      #line 2164
      maxmaxmem = 1073741824ul+X2C_largebusy;
      #line 2165
      if (X2C_maxmem>maxmaxmem) {
         #line 2166
         X2C_maxmem = maxmaxmem;
      }
      #line 2170
      freePhysMem = (X2C_SET_HINFO() X2C_GetAvailablePhysicalMemory());
      #line 2172
      if (freePhysMem!=X2C_max_longcard) {
         #line 2174
         maxmaxmem = (X2C_SET_HINFO() TruncToCard(((float)freePhysMem+(float)X2C_busymem)*0.75f));
         #line 2178
         if (X2C_busymem+xrMM_SizeToAlloc>maxmaxmem) {
            #line 2180
            if (X2C_busymem<=X2C_max_longcard-freePhysMem) {
               #line 2181
               maxmaxmem = X2C_busymem+freePhysMem;
            }
            else {
               #line 2183
               maxmaxmem = X2C_max_longcard;
            }
            #line 2189
            if (maxmaxmem>8388608ul) {
               #line 2190
               maxmaxmem -= 4194304ul;
            }
         }
         #line 2194
         if (X2C_maxmem>maxmaxmem) {
            #line 2195
            X2C_maxmem = maxmaxmem;
         }
         #line 2199
         if (gcTrash) {
            #line 2200
            minmaxmem = (unsigned long)X2C_TRUNCC(((float)freePhysMem+(float)X2C_busymem)*0.6f,0ul,X2C_max_longcard);
            #line 2201
            if (X2C_maxmem<minmaxmem) {
               #line 2202
               X2C_maxmem = minmaxmem;
               #line 2203
               gcTrash = 0;
            }
         }
      }
      #line 2209
      if (X2C_maxmem<X2C_busymem) {
         #line 2210
         X2C_maxmem = X2C_busymem;
      }
      #line 2214
      if (X2C_maxmem<1048576ul) {
         #line 2215
         X2C_maxmem = 1048576ul;
      }
   }
   #line 2219
   X2C_GCThrashWarning = gcTrash;
   #line 2221
   if (X2C_threshold<X2C_maxmem) {
      #line 2222
      if (X2C_busymem<(X2C_threshold/3ul)*2ul) {
         #line 2223
         xrMM_GCTHRESCNT = (long)(X2C_threshold-X2C_busymem);
      }
      else {
         #line 2225
         xrMM_GCTHRESCNT = (long)(X2C_threshold/3ul);
      }
   }
   #line 2238
   (X2C_SET_HINFO() X2C_FreeAfterGC());
   #line 2241
   X2C_PROC_OUT();
} /* end COLLECT() */

#line 2243
static void COLLECT_LOOP(void);

#line 2244

#line 2243
static void COLLECT_LOOP(void)
{
   #line 2244
   X2C_PROC_INP();
   #line 2245
   for (;;) {
      #line 2246
      (X2C_SET_HINFO() COLLECT());
      #line 2247
      (X2C_SET_HINFO() COROUTINES_TRANSFER(&CollectPrs, CollectPrs));
   }
   #line 2251
   X2C_PROC_OUT();
} /* end COLLECT_LOOP() */

#line 2253
static void X2C_COLLECTOR_PROC(void);

#line 2254

#line 2253
static void X2C_COLLECTOR_PROC(void)
{
   #line 2254
   X2C_PROC_INP();
   #line 2261
   (X2C_SET_HINFO() COROUTINES_TRANSFER(&CollectPrs, CollectPrs));
   #line 2266
   X2C_PROC_OUT();
} /* end X2C_COLLECTOR_PROC() */

#line 2269
struct D;

#line 2269

struct D {
   X2C_ADDRESS a;
   size_t n[1];
};

#line 2271

#line 2268
static void init_dynarrs(void)
{
   #line 2270
   unsigned long i;
   #line 2271
   X2C_PROC_INP();
   #line 2272
   dyn_offs[0u] = X2C_BASE;
   #line 2273
   dyn_offs[1u] = X2C_OFS_END;
   #line 2274
   for (i = 0ul; i<=7ul; i++) {
      #line 2275
      (X2C_SET_HINFO() xrMM_ini_type_desc(&dynarrs[i], "$DYNARR", 8ul, sizeof(struct D)+i*2ul*4ul, (char *)dyn_offs));
   } /* end for */
   #line 2278
   X2C_PROC_OUT();
} /* end init_dynarrs() */

#line 2285
static X2C_ADDRESS EmptyName;

#line 2287
static void dllAssert(void);

#line 2288

#line 2287
static void dllAssert(void)
{
   #line 2288
   X2C_PROC_INP();
   #line 2289
   (X2C_SET_HINFO() X2C_TRAP_F((long)X2C_unreachDLL));
   #line 2296
   X2C_PROC_OUT();
} /* end dllAssert() */

#line 2299

#line 2298
static void X2C_INIT_O2MM(void)
{
   #line 2299
   X2C_PROC_INP();
   #line 2305
   destruct = 0;
   #line 2306
   ADR_ALIGMENT = (unsigned long)X2C_adr_aligment;
   #line 2307
   TAG_END = X2C_OFS_END;
   #line 2308
   TAG_ARR = X2C_OFS_ARR;
   #line 2309
   TAG_REC = X2C_OFS_REC;
   #line 2310
   (X2C_SET_HINFO() init_dynarrs());
   #line 2312
   (X2C_SET_HINFO() COROUTINES_NEWCOROUTINE(COLLECT_LOOP, (char *)prs_wsp, 21072ul, &CollectPrs, 0));
   #line 2315
   xrMM_COLLECTOR = X2C_COLLECTOR_PROC;
   #line 2317
   xrMM_O2MM_init = 1;
   #line 2318
   (X2C_SET_HINFO() X2C_FINALEXE(FinalAll));
   #line 2320
   EmptyName = 0;
   #line 2327
   X2C_MaxGCTimePercent = 100ul;
   #line 2328
   MutatorStartTime = (X2C_SET_HINFO() TimeConv_millisecs());
   #line 2357
   X2C_PROC_OUT();
} /* end X2C_INIT_O2MM() */

#line 2362

#line 2359
static void patchTD(X2C_ADDRESS * pTD)
{
   #line 2361
   X2C_TD p;
   #line 2362
   X2C_PROC_INP();
   #line 2371
   p = (X2C_TD)*pTD;
   #line 2373
   *pTD = (X2C_ADDRESS)p->self;
   #line 2374
   X2C_PROC_OUT();
} /* end patchTD() */

#line 2380

#line 2376
static void patchOffsScript(OFFS pOfs)
{
   #line 2378
   unsigned long i;
   #line 2379
   X2C_ADDRESS a;
   #line 2380
   X2C_PROC_INP();
   #line 2381
   i = 0ul;
   #line 2382
   for (;;) {
      #line 2383
      a = pOfs[i];
      #line 2384
      if (a==X2C_OFS_END) {
         #line 2385
         break;
      }
      #line 2386
      if (a==X2C_OFS_REC) {
         #line 2387
         ++i;
         #line 2388
         (X2C_SET_HINFO() patchTD(&pOfs[i]));
      }
      #line 2390
      ++i;
   }
   #line 2392
   X2C_PROC_OUT();
} /* end patchOffsScript() */

#line 2401

#line 2395
extern void X2C_MODULEXE(X2C_MD md, X2C_ADDRESS hmod)
{
   #line 2398
   X2C_TD curTD;
   #line 2399
   short i;
   #line 2421
   struct X2C_TD_STR * anonym;
   short tmp;
   #line 2401
   X2C_PROC_INP();
   #line 2402
   if (!xrMM_O2MM_init) {
      #line 2402
      (X2C_SET_HINFO() X2C_INIT_O2MM());
   }
   #line 2404
   md->next = X2C_MODULES;
   #line 2405
   X2C_MODULES = md;
   #line 2417
   (X2C_SET_HINFO() patchOffsScript((OFFS)md->offs));
   #line 2419
   curTD = md->types;
   #line 2420
   while (curTD) {
      #line 2421
      { /* with */
         struct X2C_TD_STR * anonym = curTD;
         #line 2423
         tmp = anonym->level;
         i = 0;
         if (i<=tmp) for (;; i++) {
            #line 2424
            (X2C_SET_HINFO() patchTD((X2C_ADDRESS *) &anonym->base[i]));
            if (i==tmp) break;
         } /* end for */
         #line 2427
         (X2C_SET_HINFO() patchOffsScript((OFFS)anonym->offs));
      }
      #line 2429
      curTD = curTD->next;
   }
   #line 2432
   X2C_PROC_OUT();
} /* end X2C_MODULEXE() */

#line 2439
typedef X2C_ADDRESS * p2A;

#line 2443

#line 2437
static unsigned long getOfsScriptLen(X2C_TD td)
{
   #line 2441
   unsigned long l;
   #line 2442
   p2A p;
   unsigned long getOfsScriptLen_ret;
   #line 2443
   X2C_PROC_INP();
   #line 2444
   #line 2444
   l = sizeof(X2C_ADDRESS);
   #line 2445
   p = (p2A)td->offs;
   #line 2446
   while (*p!=X2C_OFS_END) {
      #line 2447
      l += sizeof(X2C_ADDRESS);
      #line 2448
      p = (p2A)((char *)p+(long)(long)sizeof(X2C_ADDRESS));
   }
   #line 2450
   getOfsScriptLen_ret = l;
   #line 2451
   X2C_PROC_OUT();
   return getOfsScriptLen_ret;
} /* end getOfsScriptLen() */

#line 2470

#line 2469
static void heapCopy(X2C_ADDRESS * heapadr, X2C_ADDRESS from, unsigned long size)
{
   #line 2470
   X2C_PROC_INP();
   #line 2471
   X2C_MOVE(from,*heapadr,size);
   #line 2472
   *heapadr = (X2C_ADDRESS)((char *)*heapadr+(long)size);
   #line 2473
   X2C_PROC_OUT();
} /* end heapCopy() */

#line 2476

#line 2455
extern void X2C_MODULEDLL(X2C_MD * component, X2C_MD md, X2C_ADDRESS hmod)
{
   #line 2460
   unsigned long room;
   #line 2462
   X2C_MD hostM;
   #line 2463
   X2C_TD destTD;
   #line 2463
   X2C_TD curTD;
   #line 2467
   X2C_ADDRESS heapadr;
   #line 2503
   struct X2C_TD_STR * anonym;
   #line 2476
   X2C_PROC_INP();
   #line 2477
   if (!xrMM_O2MM_init) {
      #line 2477
      (X2C_SET_HINFO() X2C_INIT_O2MM());
   }
   #line 2478
   room = sizeof(struct X2C_MD_STR);
   #line 2479
   curTD = md->types;
   #line 2480
   while (curTD) {
      #line 2481
      room += sizeof(struct X2C_TD_STR)+(X2C_SET_HINFO() getOfsScriptLen(curTD))+(unsigned long)curTD->methods*sizeof(X2C_PROC);
      #line 2484
      curTD = curTD->next;
   }
   #line 2487
   heapadr = (X2C_SET_HINFO() X2C_gmalloc(room));
   #line 2490
   hostM = (X2C_MD)heapadr;
   #line 2491
   (X2C_SET_HINFO() heapCopy(&heapadr, (X2C_ADDRESS)md, sizeof(struct X2C_MD_STR)));
   #line 2493
   curTD = md->types;
   #line 2494
   destTD = 0;
   #line 2496
   while (curTD) {
      #line 2497
      if (destTD==0) {
         #line 2498
         hostM->types = (X2C_TD)heapadr;
      }
      else {
         #line 2500
         destTD->next = (X2C_TD)heapadr;
      }
      #line 2503
      { /* with */
         struct X2C_TD_STR * anonym = curTD;
         #line 2505
         destTD = (X2C_TD)heapadr;
         #line 2506
         anonym->self = destTD;
         #line 2507
         (X2C_SET_HINFO() heapCopy(&heapadr, (X2C_ADDRESS)curTD, sizeof(struct X2C_TD_STR)));
         #line 2508
         destTD->module = hostM;
         #line 2511
         destTD->offs = (X2C_ppVOID)heapadr;
         #line 2512
         (X2C_SET_HINFO() heapCopy(&heapadr, (X2C_ADDRESS)anonym->offs, (X2C_SET_HINFO() getOfsScriptLen(curTD))));
         #line 2515
         if (anonym->methods) {
            #line 2516
            destTD->proc = (X2C_PROC *)heapadr;
            #line 2517
            (X2C_SET_HINFO() heapCopy(&heapadr, (X2C_ADDRESS)anonym->proc, (unsigned long)anonym->methods*sizeof(X2C_PROC)));
         }
      }
      #line 2521
      curTD = curTD->next;
   }
   #line 2525
   hostM->cnext = *component;
   #line 2526
   *component = hostM;
   #line 2529
   (X2C_SET_HINFO() X2C_MODULEXE(hostM, hmod));
   #line 2530
   X2C_PROC_OUT();
} /* end X2C_MODULEDLL() */

#line 2540

#line 2534
extern void X2C_DISABLE_COMPONENT(X2C_MD component)
{
   #line 2536
   X2C_MD curMD;
   #line 2537
   X2C_TD curTD;
   #line 2538
   short i;
   #line 2539
   X2C_PROC * p;
   #line 2547
   struct X2C_MD_STR * anonym;
   #line 2557
   struct X2C_TD_STR * anonym0;
   short tmp;
   #line 2540
   X2C_PROC_INP();
   #line 2541
   if (!(X2C_SET_HINFO() TERMINATION_IsTerminating()) && !(X2C_SET_HINFO() TERMINATION_HasHalted())) {
      #line 2543
      curMD = component;
      #line 2544
      while (curMD) {
         #line 2547
         { /* with */
            struct X2C_MD_STR * anonym = curMD;
            #line 2548
            anonym->name = (X2C_pCHAR) &EmptyName;
            #line 2549
            anonym->offs = (X2C_ppVOID) &TAG_END;
            #line 2550
            anonym->cmds = 0;
            #line 2551
            anonym->cnms = (X2C_ppCHAR) &EmptyName;
            #line 2552
            curTD = anonym->types;
         }
         #line 2556
         while (curTD) {
            #line 2557
            { /* with */
               struct X2C_TD_STR * anonym0 = curTD;
               #line 2558
               anonym0->name = (X2C_pCHAR) &EmptyName;
               #line 2559
               p = (X2C_PROC *)anonym0->proc;
               #line 2560
               tmp = anonym0->methods;
               i = 1;
               if (i<=tmp) for (;; i++) {
                  #line 2561
                  *p = dllAssert;
                  #line 2562
                  p = (X2C_PROC *)((char *)p+(long)(long)sizeof(X2C_PROC));
                  if (i==tmp) break;
               } /* end for */
            }
            #line 2565
            curTD = curTD->next;
         }
         #line 2568
         curMD = curMD->cnext;
      }
   }
   #line 2571
   X2C_PROC_OUT();
} /* end X2C_DISABLE_COMPONENT() */

#line 2573
