/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosTimeOps.h"
#define xosTimeOps_C_
#include "xlibOS.h"

#line 7 "xosTimeOps.mod"
#line 9
#define y001days 365

#line 9
#line 10
#define y004days 1461

#line 10
#line 11
#define y100days 36524

#line 11
#line 12
#define y400days 146097

#line 12
#line 18
static unsigned long monthAdd[12] = {0ul,3ul,3ul,6ul,8ul,11ul,13ul,16ul,19ul,21ul,24ul,26ul};

#line 18
#line 19
static unsigned long monthLast[12] = {31ul,59ul,90ul,120ul,151ul,181ul,212ul,243ul,273ul,304ul,334ul,365ul};

#line 19
#line 22
#define FirstValidYear 1

#line 22
#line 23
static struct X2C_TimeStruct FirstDate = {1ul,1ul,1ul,0ul,0ul,0ul,0ul,0l,0};

#line 23
#line 27

#line 26
static char is_leap(unsigned long y)
{
   char is_leap_ret;
   #line 27
   X2C_PROC_INP();
   #line 28
   #line 28
   is_leap_ret = (y&3ul)==0ul && y%100ul || y%400ul==0ul;
   #line 29
   X2C_PROC_OUT();
   return is_leap_ret;
} /* end is_leap() */

#line 32
static unsigned long xosTimeOps_m30days = 0xA50ul;

#line 33

#line 31
static char is_valid_day(unsigned long y, unsigned long m, unsigned long d)
{
   char is_valid_day_ret;
   #line 33
   X2C_PROC_INP();
   #line 34
   #line 34
   if (d<1ul || d>31ul) {
      #line 34
      is_valid_day_ret = 0;
      goto label;
   }
   #line 35
   if (m<1ul || m>12ul) {
      #line 35
      is_valid_day_ret = 0;
      goto label;
   }
   #line 36
   if (y<1ul) {
      #line 36
      is_valid_day_ret = 0;
      goto label;
   }
   #line 37
   if (X2C_IN(m,32,0xA50ul) && d>30ul) {
      #line 37
      is_valid_day_ret = 0;
      goto label;
   }
   #line 38
   if (m==2ul && d>28ul+(unsigned long)(X2C_SET_HINFO() is_leap(y))) {
      #line 38
      is_valid_day_ret = 0;
      goto label;
   }
   #line 39
   is_valid_day_ret = 1;
   label:;
   #line 40
   X2C_PROC_OUT();
   return is_valid_day_ret;
} /* end is_valid_day() */

#line 44
static unsigned long xosTimeOps_m30days0 = 0xA50ul;

#line 45

#line 42
static char is_valid(struct X2C_TimeStruct d)
{
   char is_valid_ret;
   #line 45
   X2C_PROC_INP();
   #line 46
   #line 46
   if ((X2C_SET_HINFO() is_valid_day(d.year, d.month, d.day))) {
      #line 47
      if ((d.hour>23ul || d.min0>59ul) || d.sec>59ul) {
         #line 47
         is_valid_ret = 0;
         goto label;
      }
      #line 48
      is_valid_ret = 1;
      goto label;
   }
   #line 50
   is_valid_ret = 0;
   label:;
   #line 51
   X2C_PROC_OUT();
   return is_valid_ret;
} /* end is_valid() */

#line 57
static unsigned long _cnst0[12] = {0ul,3ul,3ul,6ul,8ul,11ul,13ul,16ul,19ul,21ul,24ul,26ul};
#line 55

#line 53
static unsigned long day_of_year(unsigned long y, unsigned long m, unsigned long d)
{
   #line 54
   unsigned long x;
   unsigned long day_of_year_ret;
   #line 55
   X2C_PROC_INP();
   #line 56
   #line 56
   X2C_DECU(&m,1ul,0ul,X2C_max_longcard);
   #line 57
   x = d+m*28ul+_cnst0[X2C_CHKINX(m,12u)];
   #line 58
   if (m>=2ul && (X2C_SET_HINFO() is_leap(y))) {
      #line 58
      X2C_INCU(&x,1ul,0ul,X2C_max_longcard);
   }
   #line 59
   day_of_year_ret = x;
   #line 60
   X2C_PROC_OUT();
   return day_of_year_ret;
} /* end day_of_year() */

#line 64

#line 62
static unsigned long the_day(unsigned long y, unsigned long m, unsigned long d)
{
   #line 63
   unsigned long year;
   #line 63
   unsigned long day;
   unsigned long the_day_ret;
   #line 64
   X2C_PROC_INP();
   #line 65
   #line 65
   year = y;
   #line 66
   X2C_DECU(&y,1ul,0ul,X2C_max_longcard);
   #line 67
   day = (y/400ul)*146097ul;
   #line 67
   y = y%400ul;
   #line 68
   X2C_INCU(&day,(y/100ul)*36524ul,0ul,X2C_max_longcard);
   #line 68
   y = y%100ul;
   #line 69
   X2C_INCU(&day,(y/4ul)*1461ul,0ul,X2C_max_longcard);
   #line 70
   X2C_INCU(&day,(y&3ul)*365ul,0ul,X2C_max_longcard);
   #line 71
   X2C_INCU(&day,(X2C_SET_HINFO() day_of_year(year, m, d)),0ul,X2C_max_longcard);
   #line 72
   the_day_ret = day;
   #line 73
   X2C_PROC_OUT();
   return the_day_ret;
} /* end the_day() */

#line 76

#line 75
extern unsigned long X2C_TimeDayNum(unsigned long y, unsigned long m, unsigned long d)
{
   unsigned long X2C_TimeDayNum_ret;
   #line 76
   X2C_PROC_INP();
   #line 77
   #line 77
   if ((X2C_SET_HINFO() is_valid_day(y, m, d))) {
      #line 77
      X2C_TimeDayNum_ret = (X2C_SET_HINFO() the_day(y, m, d));
      goto label;
   }
   #line 78
   X2C_TimeDayNum_ret = 0ul;
   label:;
   #line 79
   X2C_PROC_OUT();
   return X2C_TimeDayNum_ret;
} /* end X2C_TimeDayNum() */

#line 83

#line 81
static unsigned long sub_days(struct X2C_TimeStruct g, struct X2C_TimeStruct l)
{
   #line 82
   unsigned long c;
   unsigned long sub_days_ret;
   #line 83
   X2C_PROC_INP();
   #line 84
   #line 84
   c = ((l.year-1ul)/400ul)*400ul;
   #line 85
   g.year = g.year-c;
   #line 86
   l.year = l.year-c;
   #line 87
   sub_days_ret = (X2C_SET_HINFO() the_day(g.year, g.month, g.day))-(X2C_SET_HINFO() the_day(l.year, l.month, l.day));
   #line 89
   X2C_PROC_OUT();
   return sub_days_ret;
} /* end sub_days() */

#line 92

#line 91
static unsigned long day_sec(unsigned long h, unsigned long m, unsigned long s)
{
   unsigned long day_sec_ret;
   #line 92
   X2C_PROC_INP();
   #line 93
   #line 93
   day_sec_ret = s+m*60ul+h*3600ul;
   #line 94
   X2C_PROC_OUT();
   return day_sec_ret;
} /* end day_sec() */

#line 98

#line 96
static unsigned long sub_secs(struct X2C_TimeStruct g, struct X2C_TimeStruct l)
{
   #line 97
   unsigned long days;
   unsigned long sub_secs_ret;
   #line 98
   X2C_PROC_INP();
   #line 99
   #line 99
   days = (X2C_SET_HINFO() sub_days(g, l));
   #line 100
   sub_secs_ret = (days*86400ul+(X2C_SET_HINFO() day_sec(g.hour, g.min0, g.sec)))-(X2C_SET_HINFO() day_sec(l.hour, l.min0, l.sec));
   #line 103
   X2C_PROC_OUT();
   return sub_secs_ret;
} /* end sub_secs() */

#line 128
static unsigned long _cnst1[12] = {31ul,59ul,90ul,120ul,151ul,181ul,212ul,243ul,273ul,304ul,334ul,365ul};
#line 107

#line 105
static void unpack_day(unsigned long day, unsigned long * y, unsigned long * m, unsigned long * d)
{
   #line 106
   unsigned long i;
   #line 106
   char leap;
   #line 107
   X2C_PROC_INP();
   #line 108
   if (day<=0ul) X2C_ASSERT(100ul);
   #line 109
   X2C_DECU(&day,1ul,0ul,X2C_max_longcard);
   #line 110
   *y = 400ul*(day/146097ul);
   #line 110
   day = day%146097ul;
   #line 112
   i = day/36524ul;
   #line 113
   if (i==4ul) {
      #line 113
      i = 3ul;
   }
   #line 114
   X2C_INCU(y,i*100ul,0ul,X2C_max_longcard);
   #line 114
   X2C_DECU(&day,i*36524ul,0ul,X2C_max_longcard);
   #line 116
   i = day/1461ul;
   #line 117
   X2C_DECU(&day,i*1461ul,0ul,X2C_max_longcard);
   #line 117
   X2C_INCU(y,i*4ul,0ul,X2C_max_longcard);
   #line 119
   i = day/365ul;
   #line 120
   if (i==4ul) {
      #line 120
      i = 3ul;
   }
   #line 121
   X2C_INCU(y,i,0ul,X2C_max_longcard);
   #line 121
   X2C_DECU(&day,i*365ul,0ul,X2C_max_longcard);
   #line 122
   leap = (X2C_SET_HINFO() is_leap(*y+1ul));
   #line 124
   X2C_INCU(&day,1ul,0ul,X2C_max_longcard);
   #line 126
   *m = day/32ul;
   #line 127
   X2C_DECU(&day,(unsigned long)(leap && day>31ul),0ul,X2C_max_longcard);
   #line 128
   while (*m<=11ul && day>_cnst1[X2C_CHKINX(*m,12u)]) {
      #line 128
      X2C_INCU(m,1ul,0ul,X2C_max_longcard);
   }
   #line 129
   *d = day;
   #line 130
   if (*m>0ul) {
      #line 130
      X2C_DECU(d,_cnst1[X2C_CHKINX(*m-1ul,12u)],0ul,X2C_max_longcard);
   }
   #line 131
   X2C_INCU(m,1ul,0ul,X2C_max_longcard);
   #line 132
   X2C_INCU(d,(unsigned long)(leap && *m==2ul),0ul,X2C_max_longcard);
   #line 134
   X2C_PROC_OUT();
} /* end unpack_day() */

#line 138

#line 136
static void add_days(unsigned long * y, unsigned long * m, unsigned long * d, unsigned long days)
{
   #line 137
   unsigned long cy400s;
   #line 138
   X2C_PROC_INP();
   #line 139
   cy400s = (*y-1ul)/400ul;
   #line 140
   X2C_DECU(y,cy400s*400ul,0ul,X2C_max_longcard);
   #line 142
   X2C_INCU(&cy400s,days/146097ul,0ul,X2C_max_longcard);
   #line 143
   days = days%146097ul;
   #line 145
   (X2C_SET_HINFO() unpack_day(days+(X2C_SET_HINFO() the_day(*y, *m, *d)), y, m, d));
   #line 147
   *y = *y+cy400s*400ul+1ul;
   #line 149
   X2C_PROC_OUT();
} /* end add_days() */

#line 153

#line 151
static void add_secs(unsigned long * y, unsigned long * m, unsigned long * d, unsigned long * h, unsigned long * mi, unsigned long * s, unsigned long secs)
{
   #line 152
   unsigned long days;
   #line 153
   X2C_PROC_INP();
   #line 154
   X2C_INCU(&secs,(X2C_SET_HINFO() day_sec(*h, *mi, *s)),0ul,X2C_max_longcard);
   #line 155
   days = secs/86400ul;
   #line 155
   secs = secs%86400ul;
   #line 156
   (X2C_SET_HINFO() add_days(y, m, d, days));
   #line 157
   *h = secs/3600ul;
   #line 157
   secs = secs%3600ul;
   #line 158
   *mi = secs/60ul;
   #line 159
   *s = secs%60ul;
   #line 160
   X2C_PROC_OUT();
} /* end add_secs() */

#line 164

#line 162
extern long X2C_TimeCompare(struct X2C_TimeStruct dl, struct X2C_TimeStruct dr)
{
   #line 163
   long r;
   long X2C_TimeCompare_ret;
   #line 164
   X2C_PROC_INP();
   #line 165
   #line 165
   if (!((X2C_SET_HINFO() is_valid(dl)) && (X2C_SET_HINFO() is_valid(dr)))) {
      #line 165
      X2C_TimeCompare_ret = 0l;
      goto label;
   }
   #line 166
   r = (long)X2C_CHKUL(dl.year,0ul,2147483647ul)-(long)X2C_CHKUL(dr.year,0ul,2147483647ul);
   #line 166
   if (r) {
      #line 166
      X2C_TimeCompare_ret = r;
      goto label;
   }
   #line 167
   r = (long)X2C_CHKUL(dl.month,0ul,2147483647ul)-(long)X2C_CHKUL(dr.month,0ul,2147483647ul);
   #line 167
   if (r) {
      #line 167
      X2C_TimeCompare_ret = r;
      goto label;
   }
   #line 168
   r = (long)X2C_CHKUL(dl.day,0ul,2147483647ul)-(long)X2C_CHKUL(dr.day,0ul,2147483647ul);
   #line 168
   if (r) {
      #line 168
      X2C_TimeCompare_ret = r;
      goto label;
   }
   #line 169
   r = (long)X2C_CHKUL(dl.hour,0ul,2147483647ul)-(long)X2C_CHKUL(dr.hour,0ul,2147483647ul);
   #line 169
   if (r) {
      #line 169
      X2C_TimeCompare_ret = r;
      goto label;
   }
   #line 170
   r = (long)X2C_CHKUL(dl.min0,0ul,2147483647ul)-(long)X2C_CHKUL(dr.min0,0ul,2147483647ul);
   #line 170
   if (r) {
      #line 170
      X2C_TimeCompare_ret = r;
      goto label;
   }
   #line 171
   r = (long)X2C_CHKUL(dl.sec,0ul,2147483647ul)-(long)X2C_CHKUL(dr.sec,0ul,2147483647ul);
   #line 171
   if (r) {
      #line 171
      X2C_TimeCompare_ret = r;
      goto label;
   }
   #line 172
   X2C_TimeCompare_ret = (long)X2C_CHKUL(dl.fracs,0ul,2147483647ul)-(long)X2C_CHKUL(dr.fracs,0ul,2147483647ul);
   label:;
   #line 173
   X2C_PROC_OUT();
   return X2C_TimeCompare_ret;
} /* end X2C_TimeCompare() */

#line 176

#line 175
extern unsigned long X2C_TimeDayInt(struct X2C_TimeStruct dl, struct X2C_TimeStruct dr)
{
   unsigned long X2C_TimeDayInt_ret;
   #line 176
   X2C_PROC_INP();
   #line 177
   #line 177
   if (!((X2C_SET_HINFO() is_valid(dl)) && (X2C_SET_HINFO() is_valid(dr)))) {
      #line 177
      X2C_TimeDayInt_ret = 0ul;
      goto label;
   }
   #line 178
   if ((X2C_SET_HINFO() X2C_TimeCompare(dl, dr))<=0l) {
      #line 178
      X2C_TimeDayInt_ret = 0ul;
      goto label;
   }
   #line 179
   X2C_TimeDayInt_ret = (X2C_SET_HINFO() sub_days(dl, dr));
   label:;
   #line 180
   X2C_PROC_OUT();
   return X2C_TimeDayInt_ret;
} /* end X2C_TimeDayInt() */

#line 183

#line 182
extern unsigned long X2C_TimeSecInt(struct X2C_TimeStruct dl, struct X2C_TimeStruct dr)
{
   unsigned long X2C_TimeSecInt_ret;
   #line 183
   X2C_PROC_INP();
   #line 184
   #line 184
   if (!((X2C_SET_HINFO() is_valid(dl)) && (X2C_SET_HINFO() is_valid(dr)))) {
      #line 184
      X2C_TimeSecInt_ret = 0ul;
      goto label;
   }
   #line 185
   if ((X2C_SET_HINFO() X2C_TimeCompare(dl, dr))<=0l) {
      #line 185
      X2C_TimeSecInt_ret = 0ul;
      goto label;
   }
   #line 186
   X2C_TimeSecInt_ret = (X2C_SET_HINFO() sub_secs(dl, dr));
   label:;
   #line 187
   X2C_PROC_OUT();
   return X2C_TimeSecInt_ret;
} /* end X2C_TimeSecInt() */

#line 193
static struct X2C_TimeStruct _cnst = {1ul,1ul,1ul,0ul,0ul,0ul,0ul,0l,0};
#line 192

#line 189
extern void X2C_TimeDayAdd(struct X2C_TimeStruct D, unsigned long days, struct X2C_TimeStruct * res)
{
   #line 191
   unsigned long d;
   #line 191
   unsigned long m;
   #line 191
   unsigned long y;
   #line 192
   X2C_PROC_INP();
   #line 193
   #line 193
   *res = _cnst;
   #line 194
   if (!(X2C_SET_HINFO() is_valid(D))) {
      #line 194
      goto label;
   }
   #line 195
   y = D.year;
   #line 195
   m = D.month;
   #line 195
   d = D.day;
   #line 196
   (X2C_SET_HINFO() add_days(&y, &m, &d, days));
   #line 197
   *res = D;
   #line 198
   res->year = y;
   #line 199
   res->month = m;
   #line 200
   res->day = d;
   label:;
   #line 201
   X2C_PROC_OUT();
} /* end X2C_TimeDayAdd() */

#line 206

#line 203
extern void X2C_TimeSecAdd(struct X2C_TimeStruct D, unsigned long secs, struct X2C_TimeStruct * res)
{
   #line 205
   unsigned long s;
   #line 205
   unsigned long mi;
   #line 205
   unsigned long h;
   #line 205
   unsigned long d;
   #line 205
   unsigned long m;
   #line 205
   unsigned long y;
   #line 206
   X2C_PROC_INP();
   #line 207
   #line 207
   *res = _cnst;
   #line 208
   if (!(X2C_SET_HINFO() is_valid(D))) {
      #line 208
      goto label;
   }
   #line 209
   y = D.year;
   #line 209
   m = D.month;
   #line 209
   d = D.day;
   #line 210
   h = D.hour;
   #line 210
   mi = D.min0;
   #line 210
   s = D.sec;
   #line 211
   (X2C_SET_HINFO() add_secs(&y, &m, &d, &h, &mi, &s, secs));
   #line 212
   res->year = y;
   #line 213
   res->month = m;
   #line 214
   res->day = d;
   #line 215
   res->hour = h;
   #line 216
   res->min0 = mi;
   #line 217
   res->sec = s;
   #line 218
   res->fracs = D.fracs;
   #line 219
   res->zone = D.zone;
   #line 220
   res->stf = D.stf;
   label:;
   #line 221
   X2C_PROC_OUT();
} /* end X2C_TimeSecAdd() */

#line 223
