/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "XDSRTL.h"
#define XDSRTL_C_
#include "xmRTS.h"

#line 14 "XDSRTL.mod"

#line 9
extern void XDSRTL_Init(PINT argc, PPCHAR argv, long gcauto, long gcthreshold, long heaplimit)
{
   #line 14
   X2C_PROC_INP();
   #line 15
   (X2C_SET_HINFO() X2C_BEGIN(X2C_CHKNIL(PINT,argc), (X2C_ppCHAR)argv, gcauto, gcthreshold, heaplimit));
   #line 16
   X2C_PROC_OUT();
} /* end XDSRTL_Init() */

#line 19

#line 18
extern void XDSRTL_Exit(void)
{
   #line 19
   X2C_PROC_INP();
   #line 20
   (X2C_SET_HINFO() X2C_EXIT());
   #line 21
   X2C_PROC_OUT();
} /* end XDSRTL_Exit() */

#line 23
