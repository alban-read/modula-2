/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcAri64.h"
#define xrcAri64_C_
#include "X2C.h"
#include "M2EXCEPTION.h"

#line 16 "xrcAri64.mod"

#line 15
extern X2C_INT64 X2C_REM64_F(X2C_INT64 a, X2C_INT64 b)
{
   #line 17
   #line 17
   if (b==0l) {
      #line 17
      X2C_TRAP(6l);
   }
   #line 18
   if (a>=0l) {
      #line 19
      if (b>0l) {
         #line 20
         return (a%b);
      }
      else {
         #line 22
         return (a%(-b));
      }
   }
   else if (b>0l) {
      #line 26
      return (-((-a)%b));
   }
   else {
      #line 28
      return (-(-a)%(-b));
   }
   #line 31
   return 0l;
} /* end X2C_REM64_F() */

#line 35

#line 34
extern X2C_INT64 X2C_QUO64_F(X2C_INT64 a, X2C_INT64 b)
{
   #line 36
   #line 36
   if (b==0l) {
      #line 36
      X2C_TRAP(6l);
   }
   #line 37
   if (a>=0l) {
      #line 38
      if (b>0l) {
         #line 39
         return (a/b);
      }
      else {
         #line 41
         return (-(a/(-b)));
      }
   }
   else if (b>0l) {
      #line 45
      return (-((-a)/b));
   }
   else {
      #line 47
      return ((-a)/(-b));
   }
   #line 50
   return 0l;
} /* end X2C_QUO64_F() */

#line 55

#line 53
extern X2C_INT64 X2C_MOD64_F(X2C_INT64 a, X2C_INT64 b)
{
   #line 54
   X2C_INT64 c;
   #line 56
   #line 56
   if (b<=0l) {
      #line 56
      X2C_TRAP(6l);
   }
   #line 57
   c = (a % b);
   #line 58
   if (a<0l && c<0l) {
      #line 59
      c += b;
   }
   #line 61
   return c;
} /* end X2C_MOD64_F() */

#line 66

#line 64
extern X2C_INT64 X2C_DIV64_F(X2C_INT64 a, X2C_INT64 b)
{
   #line 65
   X2C_INT64 c;
   #line 67
   #line 67
   if (b<=0l) {
      #line 67
      X2C_TRAP(6l);
   }
   #line 68
   c = (a/b);
   #line 69
   if (a<0l && c*b>a) {
      #line 69
      --c;
   }
   #line 70
   return c;
} /* end X2C_DIV64_F() */

#line 74

#line 73
extern X2C_INT64 X2C_ABS_INT64(X2C_INT64 x)
{
   #line 75
   #line 75
   if (x>=0l) {
      #line 75
      return x;
   }
   #line 76
   if (x==-0x08000000000000000l) {
      #line 76
      X2C_TRAP(1l);
   }
   #line 77
   return -x;
} /* end X2C_ABS_INT64() */

#line 80
