/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xrcIncDec64.h"
#define xrcIncDec64_C_
#include "X2C.h"
#include "M2EXCEPTION.h"

#line 18 "xrcIncDec64.mod"

#line 16
extern X2C_INT64 X2C_INC64(X2C_INT64 * x, X2C_INT64 y, X2C_INT64 min0, X2C_INT64 max0)
{
   #line 17
   X2C_INT64 i;
   #line 19
   #line 19
   if (y>0l) {
      #line 20
      if (0x07FFFFFFFFFFFFFFFl-y<*x) {
         #line 20
         X2C_TRAP(1l);
      }
   }
   else if ((-0x08000000000000000l)-y>*x) {
      #line 22
      X2C_TRAP(1l);
   }
   #line 24
   i = *x+y;
   #line 25
   if (i<min0 || i>max0) {
      #line 25
      X2C_TRAP(1l);
   }
   #line 26
   *x = i;
   #line 27
   return *x;
} /* end X2C_INC64() */

#line 32

#line 30
extern X2C_CARD64 X2C_INCU64(X2C_CARD64 * x, X2C_CARD64 y, X2C_CARD64 min0, X2C_CARD64 max0)
{
   #line 31
   X2C_CARD64 i;
   #line 33
   #line 33
   if (0x0FFFFFFFFFFFFFFFFul-y<*x) {
      #line 33
      X2C_TRAP(1l);
   }
   #line 34
   i = *x+y;
   #line 35
   if (i<min0 || i>max0) {
      #line 35
      X2C_TRAP(1l);
   }
   #line 36
   *x = i;
   #line 37
   return *x;
} /* end X2C_INCU64() */

#line 42

#line 41
extern X2C_INT64 X2C_DEC64(X2C_INT64 * x, X2C_INT64 y, X2C_INT64 min0, X2C_INT64 max0)
{
   #line 43
   #line 43
   if (y<0l) {
      #line 44
      if (0x07FFFFFFFFFFFFFFFl+y<*x) {
         #line 44
         X2C_TRAP(1l);
      }
   }
   else if ((-0x08000000000000000l)+y>*x) {
      #line 46
      X2C_TRAP(1l);
   }
   #line 48
   *x -= y;
   #line 49
   if (*x<min0 || *x>max0) {
      #line 49
      X2C_TRAP(1l);
   }
   #line 50
   return *x;
} /* end X2C_DEC64() */

#line 56

#line 54
extern X2C_CARD64 X2C_DECU64(X2C_CARD64 * x, X2C_CARD64 y, X2C_CARD64 min0, X2C_CARD64 max0)
{
   #line 55
   X2C_CARD64 i;
   #line 57
   #line 57
   if (y>*x) {
      #line 57
      X2C_TRAP(1l);
   }
   #line 58
   i = *x-y;
   #line 59
   if (i<min0 || i>max0) {
      #line 59
      X2C_TRAP(1l);
   }
   #line 60
   *x = i;
   #line 61
   return *x;
} /* end X2C_DECU64() */

#line 64
