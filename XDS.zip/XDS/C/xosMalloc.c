/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosMalloc.h"
#define xosMalloc_C_
#include "xPOSIX.h"

#line 9 "xosMalloc.mod"

#line 8
extern X2C_ADDRESS X2C_malloc(unsigned long size)
{
   X2C_ADDRESS X2C_malloc_ret;
   #line 9
   X2C_PROC_INP();
   #line 10
   #line 10
   X2C_malloc_ret = (X2C_SET_HINFO() malloc(size));
   #line 11
   X2C_PROC_OUT();
   return X2C_malloc_ret;
} /* end X2C_malloc() */

#line 14

#line 13
extern void X2C_free(X2C_ADDRESS adr, unsigned long size)
{
   #line 14
   X2C_PROC_INP();
   #line 15
   (X2C_SET_HINFO() free(adr));
   #line 16
   X2C_PROC_OUT();
} /* end X2C_free() */

#line 19

#line 18
extern X2C_ADDRESS X2C_gmalloc(unsigned long size)
{
   X2C_ADDRESS X2C_gmalloc_ret;
   #line 19
   X2C_PROC_INP();
   #line 20
   #line 20
   X2C_gmalloc_ret = (X2C_SET_HINFO() malloc(size));
   #line 21
   X2C_PROC_OUT();
   return X2C_gmalloc_ret;
} /* end X2C_gmalloc() */

#line 24

#line 23
extern void X2C_gfree(X2C_ADDRESS p)
{
   #line 24
   X2C_PROC_INP();
   #line 25
   (X2C_SET_HINFO() free(p));
   #line 26
   X2C_PROC_OUT();
} /* end X2C_gfree() */

#line 30

#line 29
extern void X2C_InitHeap(unsigned long limit, char isIncr)
{
   #line 30
   X2C_PROC_INP();
   #line 31
   X2C_PROC_OUT();
} /* end X2C_InitHeap() */

#line 35

#line 33
extern void X2C_ZEROMEM(X2C_ADDRESS adr, unsigned long qsize)
{
   #line 35
   X2C_PROC_INP();
   #line 36
   (X2C_SET_HINFO() memset(adr, 0, qsize*4ul));
   #line 37
   X2C_PROC_OUT();
} /* end X2C_ZEROMEM() */

#line 40

#line 39
extern void X2C_DestroyHeap(void)
{
   #line 40
   X2C_PROC_INP();
   #line 42
   X2C_PROC_OUT();
} /* end X2C_DestroyHeap() */

#line 44
