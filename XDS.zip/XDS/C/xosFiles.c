/* XDS v2.51: Copyright (c) 1999-2015 Excelsior, LLC. All Rights Reserved. */
#include "xosFiles.h"
#define xosFiles_C_
#include "xlibOS.h"
#include "ChanConsts.h"
#include "xrInt64.h"
#include "xPOSIX.h"

#line 14 "xosFiles.def"
unsigned long X2C_fAccessRead = 0x1ul;
#line 15
unsigned long X2C_fAccessWrite = 0x2ul;
#line 16
unsigned long X2C_fModeNew = 0x4ul;
#line 17
unsigned long X2C_fModeText = 0x8ul;
#line 18
unsigned long X2C_fModeRaw = 0x10ul;
#line 24 "xosFiles.mod"
#line 25
typedef FILE * File;

#line 26
#line 27
#line 29
#line 30
#line 31
#line 42

#line 41
extern char X2C_IsMixAllowed(void)
{
   #line 43
   #line 43
   #ifdef _unix
   #line 44
   return (X2C_BOOLEAN)1;
   #line 45
   #endif
   #line 46
   return 0;
} /* end X2C_IsMixAllowed() */

#line 50

#line 49
extern void X2C_fGetXAttrs(X2C_FXATTRS data)
{
} /* end X2C_fGetXAttrs() */

#line 55

#line 54
extern void X2C_fSetXAttrs(X2C_FXATTRS data)
{
} /* end X2C_fSetXAttrs() */

#line 61
static unsigned long mix = 0x18ul;

#line 64

#line 59
extern unsigned char X2C_fOpen(X2C_OSFHANDLE * f, char name[], unsigned long tags)
{
   #line 63
   char mode[4];
   #line 63
   unsigned long c;
   #line 63
   File cf;
   #line 65
   #line 65
   if ((tags&0x18ul)==0x18ul && !X2C_IsMixAllowed()) {
      #line 66
      return ChanConsts_noMixedOperations;
   }
   #line 68
   c = (unsigned long)((tags&0x8ul)!=0ul)+(unsigned long)((tags&0x1ul)!=0ul)*2ul+(unsigned long)((tags&0x2ul)!=0ul)*4ul+(unsigned long)((tags&0x4ul)!=0ul)*8ul;
   #line 72
   switch (c) {
   case 0ul:
   case 2ul:
      #line 73
      strncpy(mode,"rb",4u);
      break;
   case 1ul:
   case 3ul:
      #line 74
      strncpy(mode,"r",4u);
      break;
   case 4ul:
   case 6ul:
      #line 75
      strncpy(mode,"r+b",4u);
      break;
   case 5ul:
   case 7ul:
      #line 76
      strncpy(mode,"r+",4u);
      break;
   case 8ul:
   case 12ul:
      #line 77
      strncpy(mode,"wb",4u);
      break;
   case 9ul:
   case 13ul:
      #line 78
      strncpy(mode,"w",4u);
      break;
   case 10ul:
   case 14ul:
      #line 79
      strncpy(mode,"w+b",4u);
      break;
   case 11ul:
   case 15ul:
      #line 80
      strncpy(mode,"w+",4u);
      break;
   default:
      #line 72
      X2C_TRAP(X2C_CASE_TRAP);
   } /* end switch */
   #line 82
   cf = (File)fopen(name, mode);
   #line 83
   if (cf==0) {
      #line 84
      #ifdef ENOENT
      #line 85
      if (errno==ENOENT) {
         #line 85
         return ChanConsts_noSuchFile;
      }
      #line 86
      #endif
      #line 88
      #ifdef ENOENT
      #line 89
      if (errno==ENOENT) {
         #line 89
         return ChanConsts_noSuchFile;
      }
      #line 90
      #endif
      #line 92
      #ifdef EMFILE
      #line 93
      if (errno==EMFILE) {
         #line 93
         return ChanConsts_tooManyOpen;
      }
      #line 94
      #endif
      #line 96
      #ifdef EACCES
      #line 97
      if (errno==EACCES) {
         #line 97
         return ChanConsts_wrongPermissions;
      }
      #line 98
      #endif
      #line 100
      #ifdef ENOSPC
      #line 101
      if (errno==ENOSPC) {
         #line 101
         return ChanConsts_noRoomOnDevice;
      }
      #line 102
      #endif
      #line 104
      #ifdef EISDIR
      #line 105
      if (errno==EISDIR) {
         #line 105
         return ChanConsts_wrongFileType;
      }
      #line 106
      #endif
      #line 108
      return ChanConsts_otherProblem;
   }
   #line 111
   *f = (X2C_OSFHANDLE)cf;
   #line 112
   return ChanConsts_opened;
} /* end X2C_fOpen() */

#line 118

#line 116
extern int X2C_fClose(X2C_OSFHANDLE * f)
{
   #line 117
   File cf;
   #line 119
   #line 119
   cf = (File)*f;
   #line 120
   return fclose(X2C_CHKNIL(File,cf));
} /* end X2C_fClose() */

#line 125

#line 123
extern int X2C_fRead(X2C_OSFHANDLE f, X2C_ADDRESS buf, unsigned long size, unsigned long * rd)
{
   #line 124
   File cf;
   #line 126
   #line 126
   cf = (File)f;
   #line 127
   *rd = fread(buf, 1u, size, X2C_CHKNIL(File,cf));
   #line 128
   if (*rd<size && feof(cf)==0) {
      #line 128
      return errno;
   }
   #line 129
   return 0;
} /* end X2C_fRead() */

#line 134

#line 132
extern int X2C_fWrite(X2C_OSFHANDLE f, X2C_ADDRESS buf, unsigned long size, unsigned long * wr)
{
   #line 133
   File cf;
   #line 135
   #line 135
   cf = (File)f;
   #line 136
   *wr = fwrite(buf, 1u, size, X2C_CHKNIL(File,cf));
   #line 137
   if (*wr<size) {
      #line 137
      return errno;
   }
   #line 138
   return 0;
} /* end X2C_fWrite() */

#line 144

#line 141
extern int X2C_fSeek(X2C_OSFHANDLE f, struct X2C_int64 * ofs, int how)
{
   #line 142
   long pos;
   #line 143
   File cf;
   #line 145
   #line 145
   cf = (File)f;
   #line 146
   if (X2C_64TOINT(&pos, *ofs)) {
      #line 146
      return 1;
   }
   #line 147
   if (fseek(X2C_CHKNIL(File,cf), pos, how)) {
      #line 147
      return errno;
   }
   #line 148
   pos = ftell(cf);
   #line 149
   if (pos==-1l) {
      #line 149
      return errno;
   }
   #line 150
   X2C_INTTO64(ofs, pos);
   #line 151
   return 0;
} /* end X2C_fSeek() */

#line 156

#line 154
extern int X2C_fTell(X2C_OSFHANDLE f, struct X2C_int64 * ofs)
{
   #line 155
   long pos;
   #line 155
   File cf;
   #line 157
   #line 157
   cf = (File)f;
   #line 158
   pos = ftell(X2C_CHKNIL(File,cf));
   #line 159
   if (pos==-1l) {
      #line 159
      return errno;
   }
   #line 160
   X2C_INTTO64(ofs, pos);
   #line 161
   return 0;
} /* end X2C_fTell() */

#line 166

#line 164
extern int X2C_fSize(X2C_OSFHANDLE f, struct X2C_int64 * siz)
{
   #line 165
   long eof;
   #line 165
   long cp;
   #line 165
   File cf;
   #line 167
   #line 167
   cf = (File)f;
   #line 168
   cp = ftell(X2C_CHKNIL(File,cf));
   #line 169
   if (cp==-1l) {
      #line 169
      return errno;
   }
   #line 170
   if (fseek(cf, 0l, SEEK_END)) {
      #line 170
      return errno;
   }
   #line 171
   eof = ftell(cf);
   #line 172
   if (eof==-1l) {
      #line 172
      return errno;
   }
   #line 173
   if (fseek(cf, cp, SEEK_SET)) {
      #line 173
      return errno;
   }
   #line 174
   X2C_INTTO64(siz, eof);
   #line 175
   return 0;
} /* end X2C_fSize() */

#line 180

#line 178
extern int X2C_fFlush(X2C_OSFHANDLE f)
{
   #line 179
   File cf;
   #line 181
   #line 181
   cf = (File)f;
   #line 182
   if (fflush(X2C_CHKNIL(File,cf))==0) {
      #line 182
      return 0;
   }
   #line 183
   return errno;
} /* end X2C_fFlush() */

#line 186
extern int X2C_ChSize(File, long);

#line 186
#line 191

#line 189
extern int X2C_fChSize(X2C_OSFHANDLE f)
{
   #line 190
   File cf;
   #line 190
   long pos;
   #line 192
   #line 192
   cf = (File)f;
   #line 193
   if (fflush(X2C_CHKNIL(File,cf))) {
      #line 193
      return errno;
   }
   #line 194
   pos = ftell(cf);
   #line 195
   if (pos==-1l) {
      #line 195
      return errno;
   }
   #line 196
   if (X2C_ChSize(cf, pos)==0) {
      #line 196
      return 0;
   }
   #line 197
   return errno;
} /* end X2C_fChSize() */

#line 201

#line 200
extern int X2C_fGetStd(X2C_OSFHANDLE * f, int what)
{
   #line 202
   #line 202
   switch (what) {
   case 0:
      #line 203
      *f = (X2C_OSFHANDLE)stdin;
      break;
   case 1:
      #line 204
      *f = (X2C_OSFHANDLE)stdout;
      break;
   default:;
      #line 206
      *f = (X2C_OSFHANDLE)stderr;
      break;
   } /* end switch */
   #line 208
   return 0;
} /* end X2C_fGetStd() */

#line 212

#line 211
static int X2C_dup2(FILE * f1, X2C_ADDRESS * f2)
{
   #line 213
   #line 213
   #if defined(_unix) || defined(_msdos)
   #line 214
     return dup2(fileno(f1),fileno(*(FILE**)f2));
   #line 215
   #else
   #line 216
   (*f2)=(X2C_ADDRESS)f1;
   #line 217
   return 0;
   #line 218
   #endif
   #line 219
   X2C_TRAP(X2C_RETURN_TRAP);
   return 0;
} /* end X2C_dup2() */

#line 223

#line 221
extern int X2C_fSetStd(X2C_OSFHANDLE new, int which)
{
   #line 222
   File cf;
   #line 222
   File yf;
   #line 224
   #line 224
   cf = (File)new;
   #line 225
   switch (which) {
   case 0:
      #line 226
      yf = (File)stdin;
      break;
   case 1:
      #line 227
      yf = (File)stdout;
      break;
   default:;
      #line 229
      yf = (File)stderr;
      break;
   } /* end switch */
   #line 231
   return X2C_dup2(X2C_CHKNIL(File,cf), (X2C_ADDRESS *) &yf);
} /* end X2C_fSetStd() */

#line 241
extern int X2C_GetFileType(X2C_OSFHANDLE);

#line 241
#line 245

#line 244
extern int X2C_fGetFileType(X2C_OSFHANDLE f)
{
   #line 246
   #line 246
   return X2C_GetFileType(f);
} /* end X2C_fGetFileType() */

#line 256
